create trigger TAR2_2ID_PREINS
  before insert
  on TARIFA2_2
  for each row
  begin
 select tar2_2seq.nextval into :new.id from dual;
end;



/

