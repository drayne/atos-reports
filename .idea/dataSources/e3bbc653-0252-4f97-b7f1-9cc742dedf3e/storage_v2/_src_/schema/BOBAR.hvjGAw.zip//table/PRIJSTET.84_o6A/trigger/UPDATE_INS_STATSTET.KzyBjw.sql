create trigger UPDATE_INS_STATSTET
  after update of ID, STATUS_STETE, SIFOPERAT, DATUM_STATUSA
  on PRIJSTET
  for each row
  declare
  rbr_status number;
begin


  if :new.status_stete <> :old.status_stete then
    select nvl ( max ( sta_rednibroj ), 0 ) + 1 into rbr_status
      from statstet where prijstet_id = :new.id;

    insert into statstet ( prijstet_id, sta_datum_od,
                           sta_rednibroj, status_stete,
                           datumobrade, sifoperat, sta_datum )
                  values ( :new.id, :old.datum_statusa,
                           rbr_status, :old.status_stete,
                           sysdate, :old.sifoperat, :new.datum_statusa );
  end if;

end;


/

