create FUNCTION PL_OBRACUN_PLATE (p_firma in number, p_mjesec in number,p_godina in number) RETURN VARCHAR2 AS 
BEGIN
/*

PRAGMA AUTONOMOUS_TRANSACTION;
  insert into pl_obracun
(
select r.firma, r.id, 1 as rbob, p_mjesec mjesec, p_godina godina, 15 as vrsta_sati, 
nvl(s.brojs_sati,nvl(izracunaj_sate_radnika(r.id,m.godina,m.mjesec),m.sati)) sati,
nvl(s.iznos,(case when izracunaj_sate_radnika(r.id,m.godina,m.mjesec) is not null 
then m.cena_rada*r.koeficijent/m.sati*izracunaj_sate_radnika(r.id,m.godina,m.mjesec) when izracunaj_sate_radnika(r.id,m.godina,m.mjesec) is null and r.ukupan_iznos is null 
then m.cena_rada*r.koeficijent else r.ukupan_iznos end)) iznos,
/*nvl(nvl(s.iznos,r.ukupan_iznos),m.cena_rada*r.koeficijent/m.sati*nvl(izracunaj_sate_radnika(r.id,m.godina,m.mjesec),m.sati)) iznos,*/

/*

round(nvl(s.iznos,(case when izracunaj_sate_radnika(r.id,m.godina,m.mjesec) is not null 
then m.cena_rada*r.koeficijent/m.sati*izracunaj_sate_radnika(r.id,m.godina,m.mjesec) when izracunaj_sate_radnika(r.id,m.godina,m.mjesec) is null and r.ukupan_iznos is null 
then m.cena_rada*r.koeficijent else r.ukupan_iznos end))/plate_daj_procenat_bruto(m.godina,m.mjesec),2) bruto
from pl_radnici r, pl_mjeseci m, pl_sati s
where (r.firma=s.firma(+) and r.id=s.radnik(+) and s.mjesec(+)=p_mjesec and s.godina(+)=p_godina) and r.firma=p_firma and m.firma=r.firma and m.godina=p_godina and m.mjesec=p_mjesec and 
to_char(r.datum_zapocinjanja,'rrrrmm')<=p_godina||p_mjesec
and (to_char(r.datum_otpusta,'rrrrmm') is null or to_char(r.datum_otpusta,'rrrrmm')>=p_godina||p_mjesec)
);

*/
null;
exception
when others then
  return sqlerrm;
END PL_OBRACUN_PLATE;

/

