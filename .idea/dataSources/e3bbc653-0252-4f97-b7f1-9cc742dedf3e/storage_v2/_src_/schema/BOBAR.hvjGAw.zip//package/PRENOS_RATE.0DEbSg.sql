create PACKAGE prenos_rate IS

  logfl utl_file.FILE_TYPE;
  EOF boolean;
  greska varchar2(1024);
  linija number;

  procedure prenos (put_do_fajla varchar2);
  PROCEDURE logit(ms varchar2);

END;


/

