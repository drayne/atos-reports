create trigger SIFARNIK_TRIGGER
  before insert
  on SIFARNIK
  for each row
  BEGIN
  SELECT sifarnik_seq.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;


/

