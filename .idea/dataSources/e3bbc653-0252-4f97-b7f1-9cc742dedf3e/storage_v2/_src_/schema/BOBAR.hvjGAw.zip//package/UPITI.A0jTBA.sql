create PACKAGE       UPITI IS
  type spisak_nerealizovanih is record (
       STR_VSDOK number(5),
       STR_BROJDOK varchar2(13),
       STR_DATUMPROMENE date,
       MBRZASTUPDAJE number(13),
       MBRZASTUPPRIMA number(13),
       ZASTUPNIK varchar2(50),
       SVSPROM number(3),
       NAZIV_PROMENE varchar2(50),
       BROJREVERSA number(18),
       OPISREVERSA varchar2(25),
       NAZIVDOK varchar2(50),
       fil_sifra number,
       filijala varchar2(50));
  type spisak_nerealizovanih_ref_cur is ref cursor return spisak_nerealizovanih;
  function query_spisak_nerealizovanih
                   ( p_datum_ulaz_od date, p_datum_ulaz_do date, p_datum_zaduzen_od date, p_datum_zaduzen_do date, 
                     p_datum_razduzenja date, p_zastupnik_od number, p_zastupnik_do number, p_vsdok_od number,
                     p_vsdok_do number, p_filijala number ) return spisak_nerealizovanih_ref_cur;
  type spisak_zaduzenih is record (
       STR_VSDOK number(5),
       STR_BROJDOK varchar2(13),
       STR_DATUMPROMENE date,
       MBRZASTUPDAJE number(13),
       MBRZASTUPPRIMA number(13),
       ZASTUPNIK varchar2(50),
       SVSPROM number(3),
       NAZIV_PROMENE varchar2(50),
       BROJREVERSA number(18),
       OPISREVERSA varchar2(25),
       NAZIVDOK varchar2(50),
       fil_sifra number,
       filijala varchar2(50));
  type spisak_zaduzenih_ref_cur is ref cursor return spisak_zaduzenih;
  function query_spisak_zaduzenih
                   ( p_datumpromene_od date, p_datumpromene_do date, p_zastupnik_od number, p_zastupnik_do number, p_vsdok_od number,
                    p_vsdok_do number, p_filijala number ) return spisak_zaduzenih_ref_cur;

  type spisak_razduzenih is record (
       STR_VSDOK number(5),
       STR_BROJDOK varchar2(13),
       STR_DATUMPROMENE date,
       MBRZASTUPDAJE number(13),
       MBRZASTUPPRIMA number(13),
       ZASTUPNIK varchar2(50),
       SVSPROM number(3),
       NAZIV_PROMENE varchar2(50),
       BROJREVERSA number(18),
       OPISREVERSA varchar2(25),
       NAZIVDOK varchar2(50),
       fil_sifra number,
       filijala varchar2(50));
  type spisak_razduzenih_ref_cur is ref cursor return spisak_razduzenih;
  function query_spisak_razduzenih
                   ( p_datumpromene_od date, p_datumpromene_do date, p_zastupnik_od number, p_zastupnik_do number, p_vsdok_od number,
                    p_vsdok_do number, p_filijala number ) return spisak_razduzenih_ref_cur;
  type spisak_polisa is record (
       sifra number,
       naziv varchar2(512),
       POL_BRPOL number,
       NAZIVUGOV varchar2(512),
       UKPREMIJA number,
       DATPOC date,
       DATIST date,
       DATDOK date,
       DATPRIP date,
       TARGRUPA number,
       TARPODGRUPA number,
       BROJSASIJE varchar2(50),
       BROJMOTORA varchar2(50),
       MARKA varchar2(128),
       REGBROJ varchar2(50),
       vsdok number,
       vsdok_naziv varchar2(50));
  type spisak_polisa_ref_cur is ref cursor return spisak_polisa;
  function query_spisak_polisa
                   ( p_from varchar2, p_where varchar2 ) return spisak_polisa_ref_cur;
  function ukupna_premija_period_vros(datum_od POLISA.DATDOK%type, datum_do POLISA.DATDOK%type, p_vros POLISA.VROS%type default null) 
    return polisa.premija%type;
    
  function anl_za_konto_dug(datum_od ANLANL.DATDOK%type, datum_do ANLANL.DATDOK%type, konto ANLANL.KONTO%type, polisa ANLANL.POL_BRPOL%type, vsdok ANLANL.ANL_VSDOK%type)
    return ANLANL.DEV_DUGUJE%type;
    
    function anl_za_konto_pot(datum_od ANLANL.DATDOK%type, datum_do ANLANL.DATDOK%type, konto ANLANL.KONTO%type, polisa ANLANL.POL_BRPOL%type, vsdok ANLANL.ANL_VSDOK%type)
        return ANLANL.DEV_POTRAZUJE%type;    
        
function vrati_opstinu(ptt MESTO.MES_SIFRA%type)
    return OPSTINA.NAZIV%type;
END;

/

