create trigger POPDOPI_PRE_INS
  before insert
  on POPDOPI
  for each row
  begin
select popdopi_id_seq.nextval into :new.id from dual;
end;



/

