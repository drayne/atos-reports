create view PRIJSTET_BRCKO_VW as
  SELECT "ID",
          "PRST_VRSTA",
          "PRST_GODINA",
          "PRST_BRSTETE",
          "OJ",
          "MBRRADNIKA",
          "DATUMPRIJAVE",
          "STATUS_STETE",
          "BRPOLISE",
          "NAZIVPODNOSIOCA",
          "BRLKPODNOSIOCA",
          "DATUMNASTANKA",
          "MESTONEZGODE",
          "IZNOS_PRIJAVLJEN",
          "IZNOS_REZERVISAN",
          "DATUMOBRADE",
          "SIFOPERAT",
          "VROS",
          "TARIFA",
          "DATUMOBRACUNA",
          "ADRESAPODNOS",
          "TELEFONPODNOS",
          "IMEOVLASCENI",
          "ADRESAOVLASCENI",
          "TELEFONOVLASCENI",
          "IMEISPLATA",
          "ADRESAISPLATA",
          "TELEFONISPLATA",
          "RACUNISPLATA",
          "NAPOMENA70",
          "NAPOMENA_STATUS",
          "DATUM_STATUSA",
          "DATUM_VRACANJA",
          "BIRO_DATUM",
          "VSDOK",
          "AZORS_SLANJE_ID",
          "SWIFTISPLATA",
          "ADRESABANKAISPLATA",
          "RACUNBANKAISPLATA",
          "BANKAISPLATA",
          "UDOFBIH_ID",
          "KORESPODENT",
          "KORESPODENT_DRZAVA",
          "MBRZASTUP",
          "RENTA",
          "REGRES",
          "OTKUP"
     FROM prijstet
    WHERE PRIJSTET.BRPOLISE IN
             (SELECT p.pol_brpol
                FROM polisa p, mesto mm, opstina o
               WHERE     p.PTTM = mm.mes_sifra
                     AND mm.opst = o.ops_sifra
                     AND o.porreg = 2)

/

