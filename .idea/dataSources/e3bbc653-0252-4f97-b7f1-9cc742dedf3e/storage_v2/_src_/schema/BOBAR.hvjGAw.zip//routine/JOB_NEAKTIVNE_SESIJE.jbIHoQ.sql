create PROCEDURE       "JOB_NEAKTIVNE_SESIJE" AS 

    sql_stmnt varchar2(400);
begin

    

for i in (SELECT sid, serial#, status, LAST_CALL_ET, PROCESS FROM v$session
            where last_call_et >=2400
            and status='INACTIVE')
loop
    
    sql_stmnt := 'ALTER SYSTEM KILL SESSION ' || ''''  || i.sid ||  ', ' || i.serial# ||'''' || ' immediate';
    update tehnicki_sesije t set t.kraj_konekcije = current_timestamp where t.proces=i.process;
    commit;
    Execute immediate sql_stmnt;   
    
    
end loop;
end;

/

