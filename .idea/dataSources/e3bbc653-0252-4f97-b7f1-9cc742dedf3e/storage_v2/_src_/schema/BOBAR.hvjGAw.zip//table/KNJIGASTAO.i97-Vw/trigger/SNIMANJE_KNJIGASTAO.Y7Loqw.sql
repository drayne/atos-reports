create trigger SNIMANJE_KNJIGASTAO
  before insert or update
  on KNJIGASTAO
  for each row
  BEGIN
  -- Zbog AZORS-a
  update prijstet set azors_slanje_id=null where id=:new.prijstet_id; 
END;


/

