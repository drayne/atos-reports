create FUNCTION       "VRATI_NAZIV_KOMITENTA" (p_sifra in number default 0) RETURN VARCHAR2 AS 
r_naziv varchar2(64);
BEGIN
  select naziv into r_naziv from komitent where kom_sifra = p_sifra ;
  return r_naziv;
 exception
        when NO_DATA_FOUND    then return ' ';     
  
END;

/

