create PROCEDURE "DAJ_PROBA_TAB"  (
                        p_datum    in     date,
                        p_targru   in     number,
                        p_brojdana in     number,
                        p_zonr     in     number,
                        p_PREMIJA  in out number,
                        p_rezultat in out number
                                             ) IS
w_proba     proba_tab%rowtype;
osnovni number;
visak number;
iznos number(17,2);
medjuzbir number(17,2);

BEGIN
   p_rezultat := 99;
   iznos := 0;
   medjuzbir := 0;

   select
              iznprem
   into
              iznos
   from
              cenao
   where
              cao_zonr   = p_zonr
          and cao_targru = 1
          and cao_tarpgr = 3
          and cao_datum  = (
                             select
                                         max(cao_datum)
                             from
                                         cenao
                             where
                                         to_char(cao_datum,'yyyymmdd') <=
                                                 to_char(p_datum,'yyyymmdd')
                                     and cao_zonr = p_zonr
                                     and cao_targru = 1
                                     and cao_tarpgr = 3
                           );
   if iznos = 0 then
      p_rezultat := 61;
/*
                                    nije prona?ena premija za reperno vozilo
*/
   else
      if p_datum is null then
         p_rezultat := 51;
/*
                                    prazan datum važenja cenovnika za probne tablice
*/
         p_premija  := 0;
      else

         select
                     *
         into
                     w_proba
         from
                     proba_tab
         where
                     proba_tab.targru = p_targru and proba_tab.zonr=p_zonr
                 and proba_tab.datum  = (
                                     select
                                                max(proba_tab.datum)
                                     from
                                                proba_tab
                                     where
                                                to_char(proba_tab.datum,'yyyymmdd') <=
                                                        to_char(p_datum,'yyyymmdd')
                                            and proba_tab.targru = p_targru and proba_tab.zonr=p_zonr
                                        );
         if nvl(w_proba.procenat_osnovni, 0) = 0 then
            p_rezultat := 71;
            p_premija := 0;
/*
                                      nije prona?ena cena za proba tablice
*/
         else
            if p_brojdana > w_proba.krajnji_dan then
               p_rezultat := 11;
               p_premija := 0;
/*
                 proba tablice se izdaju za najviše w_proba.krajnji_dan dana
*/
            else
               osnovni := w_proba.brdana_osnovni;
               if p_brojdana > w_proba.brdana_osnovni then
                  visak := p_brojdana - w_proba.brdana_osnovni;
               else
                  visak := 0;
               end if;
               p_rezultat := 0;
/*               
               medjuzbir := (osnovni * w_proba.procenat_osnovni / 100) * iznos;
*/
               medjuzbir := (w_proba.procenat_osnovni / 100) * iznos;
                                 
               p_premija :=     round( 
                     (medjuzbir +
                          ((visak * w_proba.procenat_dodatni / 100) * medjuzbir)
                     ), 2     
                                     );
            end if;
        end if;
      end if;
   end if;
END;

/

