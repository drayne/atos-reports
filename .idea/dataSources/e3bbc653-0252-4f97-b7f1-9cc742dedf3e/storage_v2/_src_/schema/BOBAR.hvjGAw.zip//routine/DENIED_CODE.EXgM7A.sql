create FUNCTION       DENIED_CODE (p_text VARCHAR2,p_item varchar2,p_form varchar2) RETURN VARCHAR2 AS
BEGIN
for red in (select * from denied_character where lower(item)=lower(p_item) and lower(form)=lower(p_form)) loop
  if instr ( p_text, chr(red.code) )>0 then
    if instr ( p_text, chr(red.code) ) = nvl(red.position,instr ( p_text, chr(red.code) ) 
    ) then
        return red.message;
      end if;
      return '0';
      end if;
end loop;
for red1 in (select * from denied_character where item is null and lower(form)=lower(p_form)) loop
  if instr ( p_text, chr(red1.code) )>0 then
    if instr ( p_text, chr(red1.code) ) = nvl(red1.position,instr ( p_text, chr(red1.code) ) 
    ) then
        return red1.message;
      end if;
      return '0';
      end if;
end loop;
  return '0';
END DENIED_CODE;


/

