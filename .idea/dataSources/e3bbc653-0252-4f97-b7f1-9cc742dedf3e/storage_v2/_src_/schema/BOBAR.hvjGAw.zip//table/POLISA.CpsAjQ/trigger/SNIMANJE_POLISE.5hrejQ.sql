create trigger SNIMANJE_POLISE
  before insert or update
  on POLISA
  for each row
  declare 
privilegija   number:=0;
nesto         number:=0;
datum         date;
zastupnik     number:=0;
zadnja_polisa number:=0;
postoji number:=0;
naziv_komitenta varchar2(64);
iznos number(16);
begin
 -- Zbog AZORS-a 
  if :old.azors_slanje_id is not null then
    :new.azors_slanje_id:=null;
  end if;
 -- U slucaju da je slucajno unesen broj OSK obrasca
  if INSERTING then
    :new.brosk:=null;  
  end if;
-- za istog zastupnika polise se unose hronološki
    for red5 in ( select * from parametri
                  where lower(trim(naziv))='hronoloski_unos_dse' and trim(lower(vrijednost))='1'
                  and not exists (select * from dse_izuzetci where vsdok=:new.vsdok and brojdok=:new.pol_brpol )
                  ) loop
      if INSERTING then
        select nvl(max(to_number(pol_brpol)),0) into zadnja_polisa
        from polisa
        where mbrzastup=:new.mbrzastup and vsdok=:new.vsdok and upper(trim(nap1))<>'BOBAR-PRENOS STARIH POLISA'
        and (vsdok,pol_brpol) not in (select vsdok,brojdok from dse_izuzetci);
        if zadnja_polisa>=:new.pol_brpol then
          RAISE_APPLICATION_ERROR(-20000, 'Postoji POLISA '||zadnja_polisa||' koja je veća nego '||:new.pol_brpol||' koju pokušavate da snimite!');
        end if;
      end if;    
    end loop;
    
-- promjene koje nastaju u strogoj moraju biti datumski hronološki redane, ako se ne update-uje kolona biro_datum
  --if INSERTING then
    for r in (select column_name from all_tab_columns where table_name = 'POLISA' and owner = 'BOBAR' and column_name = 'BIRO_DATUM') loop
                 if not updating(r.column_name) then
                    select nvl(max (str_datumpromene),sysdate) into datum
                    from stroga 
                    where str_vsdok=:new.vsdok and str_brojdok=:new.pol_brpol;
                    if to_char(datum,'rrrrmmdd')>to_char(:new.datdok,'rrrrmmdd') then
                      RAISE_APPLICATION_ERROR(-20000, 'Prethodna promjena za dokument '||:new.vsdok||'/'||:new.pol_brpol
                      ||' je sa vecim datumom nego ovaj '||to_char(:new.datdok,'dd.mm.rrrr'));
                    end if;
                  --end if;
                 end if;
    end loop;
  
-- promjene koje nastaju u strogoj moraju biti hronološki redane po zastupnicima
  --if INSERTING then
    select mbrzastupprima into zastupnik from stroga s
    where s.id=(select max(ss.id) from stroga ss where s.str_vsdok=ss.str_vsdok and s.str_brojdok=ss.str_brojdok)
    and str_vsdok=:new.vsdok and str_brojdok=:new.pol_brpol;
    if zastupnik<>:new.mbrzastup then
      RAISE_APPLICATION_ERROR(-20000, 'Prethodna promjena za dokument '||:new.vsdok||'/'||:new.pol_brpol
      ||' je na drugom zastupniku!');
    end if;
  --end if;
  
  -- provjera da li je zastupnik aktivan ili ne, ako se ne update-uje kolona biro_datum
  for red in (select * from zastup where zas_sifra in (:new.mbrzastup)) loop
    for r in (select column_name from all_tab_columns where table_name = 'POLISA' and owner = 'BOBAR' and column_name = 'BIRO_DATUM') loop
                 if not updating(r.column_name) then
                       if red.aktivan=0 then
                        RAISE_APPLICATION_ERROR(-20000, 'Zastupnik '|| :new.mbrzastup||'-'||red.naziv||' je neaktivan!'); 
                       end if;
                 end if;
    end loop;
  end loop;
  
  -- provjera da li je šifra privilegije = 1, ako jeste to znači da ne može snimati promjene, ako se ne update-uje kolona biro_datum
    for r in (select column_name from all_tab_columns where table_name = 'POLISA' and owner = 'BOBAR' and column_name = 'BIRO_DATUM') loop
                 if not updating(r.column_name) then
                      select count(zastupnik) into privilegija from operater o where trim(o.korisnik)=trim(:new.sifoperat)
                      and nvl(o.zastupnik,0)=1;
                      if privilegija = 1 then
                        raise_application_error(-20000, 'Za operatera '||:new.sifoperat||' nije dozvoljeno razduzivanje zastupnika '||:new.mbrzastup||' !');
                      end if;
                      privilegija:=0;
                   end if;
    end loop;
  
  -- provjera da li operater može da razduži zastupnika, ako se ne update-uje kolona biro_datum
    for r in (select column_name from all_tab_columns where table_name = 'POLISA' and owner = 'BOBAR' and column_name = 'BIRO_DATUM') loop
                 if not updating(r.column_name) then
                      select count(zastupnik) into privilegija from operater o where trim(o.korisnik)=trim(:new.sifoperat)
                      and nvl(o.zastupnik,0)<>0;
                      if --:new.svsprom in (1,11,21,22,23,24) and
                      privilegija>0 then  
                        select count(*) into nesto from operater o, zastup_grupe zg
                        where o.zastupnik=zg.grp_zastup 
                        and trim(o.korisnik)=trim(:new.sifoperat) 
                        and decode(nvl(zg.koga,0),99999,nvl(:new.mbrzastup,0),nvl(zg.koga,0))=nvl(:new.mbrzastup,0) 
                        and 21 = zg.sta;
                        if nesto=0 then
                          raise_application_error(-20000, 'Za operatera '||:new.sifoperat||' nije dozvoljeno razduzivanje zastupnika '||:new.mbrzastup||' !'); 
                        end if;
                      end if;
                   end if;
    end loop;
  
    for r in (select column_name from all_tab_columns where table_name = 'POLISA' and owner = 'BOBAR' and column_name = 'BIRO_DATUM') loop
                 if not updating(r.column_name) then
                      if :new.premija is null then
                        raise_application_error(-20000, 'Nije dobro obracunao premiju! Pokusajte ponovo unijeti polisu'); 
                      end if;
                   end if;
    end loop;
    
--    for r in (select column_name from all_tab_columns where table_name = 'POLISA' and owner = 'BOBAR' and column_name = 'JMBG') loop
--                 if not updating(r.column_name) then
--                    if(:new.vros!=800) then
--                        select sum(pot.iznos) into postoji from bobar.KOMITENTI_POTRAZIVANJE pot where trim(pot.komitent)=trim(:new.jmbg) and pot.komitent not in (select komitent from komitent_potrazivanja_izuzeci);
--                          if (postoji > 0 ) then
--                            naziv_komitenta:= bobar.vrati_naziv_komitenta(:new.jmbg);
--                            raise_application_error(-20000, 'Za: '|| naziv_komitenta  ||' postoji potraživanje u iznosu od: '||postoji ||'KM !');                      
--                          end if;
--                    end if;
--                 end if;
--
--    end loop;

  /*exception
  when others then
  RAISE_APPLICATION_ERROR(-20000, 'Greška prilikom određivanja privilegije za operatera '||:new.sifoperat);*/
end;
/

