create function FileExists(
  p_DirName in varchar2,     -- schema object name
  p_FileName in varchar2
) return number
is
  l_fexists boolean;
  l_flen   number;
  l_bsize  number;
  l_res    number(1);
begin
  l_res := 0;
  utl_file.fgetattr(upper(p_DirName), p_FileName, l_fexists, l_flen, l_bsize);
  if l_fexists
  then
    l_res := 1;
  end if;  
  return l_res;
end;

/

