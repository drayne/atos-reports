create FUNCTION MAKE_XML  RETURN VARCHAR2 is  
  result XMLTYPE; 
  v_clob clob; 
  izlaz utl_file.FILE_TYPE;
  logfl utl_file.FILE_TYPE;
  l_broj number;
  l_kod_osig varchar2(128) := 'RD-7';
  l_rbr number;
  l_UniqueID varchar2(128):='test';
  p_broj_redova number;
begin 
  execute immediate 'alter session set nls_numeric_characters=''.,''';
  begin
    izlaz := utl_file.fopen ( 'PISI', l_UniqueID || '.xml', 'w' );
    logfl:= utl_file.fopen ( 'PISI', l_UniqueID || '.log', 'w' );
    utl_file.put_line ( logfl, 'Otvoren...' );
  exception 
    when utl_file.invalid_path then
      utl_file.put_line ( logfl, 'FOPEN:invalid_path' );
    when utl_file.invalid_mode then
      utl_file.put_line ( logfl, 'FOPEN:invalid_mode' );
    when utl_file.invalid_operation then
      utl_file.put_line ( logfl, 'FOPEN:invalid_operation' );
  end;
  utl_file.put_line ( logfl, p_broj_redova );

  if ( utl_file.is_open ( izlaz ) ) then
  
    for cur_rec in (
    
    
select xmlelement("Police",xmlagg(xmlelement("Polica",xmlelement("BrojPolice",'51/'||p.pol_brpol)
                                                      ,xmlelement("FKRanijeDrustvo",to_char(nvl(nvl((case when numericno(p.zampol)=1 and nvl(to_number(p.zampol),0)>0 then 15 end),d.sifra_udofbih),26)))
                                                      ,xmlelement("BrojRanijePolice",to_char(case when (nvl(nvl((case when numericno(p.zampol)=1 and nvl(to_number(p.zampol),0)>0 then 15 end),d.sifra_udofbih),26))=15 then p.zampol else p.BRPOL_OSTALI end))
                                                      ,xmlelement("NazivOsiguranika",nvl(nvl(trim(p.nazivosig),trim(p.nazivugov)),'Nepoznato'))
                                                      ,xmlelement("JMB_IDOsiguranika",lpad(to_char(nvl(nvl(trim(p.sifosig),trim(p.jmbg)),'Nepoznato')),13,'0'))
                                                      ,xmlelement("NazivUgovaraca", nazivugov)
                                                      ,xmlelement("JMB_IDUgovaraca",lpad(to_char(p.jmbg),13,'0'))
                                                      ,xmlelement("DatumPocetkaTrajanjaOsiguranja",to_char(p.datpoc,'dd.mm.rrrr'))
                                                      ,xmlelement("DatumZavrsetkaTrajanjaOsig",to_char(datist,'dd.mm.rrrr'))
                                                      ,xmlelement("DatumIVrijemeIzdavanjaPolice",to_char(p.datdok,'dd.mm.rrrr'))
                                                      ,xmlelement("IznosBonusa",trim(to_char ( nvl(p3.iznosbonmal,0), '999999990D99' )))
                                                      ,xmlelement("FKBonus",lpad(to_char(bm.udofbih),2,'0'))
                                                      ,xmlelement("UkupnaPremijaAutoOdgovornosti",trim(to_char ( p3.uk_prem_ao, '999999990D99' )))
                                                      ,xmlelement("RegistarskaOznaka",trim(p2.regbroj))
                                                      ,xmlelement("MarkaVozila",trim(p2.marka))
                                                      ,xmlelement("TipVozila",trim(p2.tip))
                                                      ,xmlelement("VIN",nvl(trim(p2.brojsasije),'Nepoznato'))
                                                      ,xmlelement("FKTarifa",ca.sifra_udofbih)
                                                      ,xmlelement("SifraZastupnika",trim(p.mbrzastup))
                                                      ,xmlelement("MjestoIzdavanja",trim(m.mesto))
                                                      ,xmlelement("GodinaProizvodnje",trim(p2.godproizv))
                                                      ,xmlelement("BrojPoliceIskoristenogBonusa",null)
                                                      ,xmlelement("SnagaMotora",trim(p2.snagakw))
                                                      ,xmlelement("BrojMotora",trim(p2.brojmotora))
                                                      ,xmlelement("Stornirana",case when (select to_char(str_datumpromene,'dd.mm.rrrr') from stroga where str_vsdok=p.vsdok and str_brojdok=p.pol_brpol and svsprom in (22,24)) is null then '0' else '1' end)
                                                      ,xmlelement("DatumIVrijemeStorniranja",(select to_char(str_datumpromene,'dd.mm.rrrr') from stroga where str_vsdok=p.vsdok and str_brojdok=p.pol_brpol and svsprom in (22,24)))
                                                      ,xmlelement("Prekinuta",case when p.datum_prestanka_vazenja is null then '0' else '1' end)
                                                      ,xmlelement("PrekinutaDatum",to_char(p.datum_prestanka_vazenja))
                                                      ,xmlelement("DaLiJeOsiguranikFizickoLice",null)
                                                      ,xmlelement("FKVrstaVozilaOsiguranika",nvl(trim(vv.udofbih),'Nepoznato'))
                                            )
                                 )
                  ).extract('/*') as result
from polisa p,tep.ddor d, polao3 p3, bonus_malus bm, polao2 p2 ,mesto m,vrstavoz vv,cenao ca
where p.osig_ostali=d.sifra(+) and p.vsdok in (1,5) and p.pol_brpol=p3.ao3_brpol and p.vsdok=p3.vsdok and bm.sifra=p3.bonusmalus 
and p2.ao2_brpol=p.pol_brpol and p2.vsdok=p.vsdok and m.mes_sifra(+)=p.pttm and p3.targrupa=vv.vsv_sifra(+) 
and (p3.zonr=ca.cao_zonr and p3.targrupa=ca.cao_targru and p3.tarpodgrupa=ca.cao_tarpgr)
and exists 
(
select * 
FROM PRIJSTET, KNJIGASTAO 
WHERE datumprijave between '01-jan-10'  and '31-jan-10' and (KNJIGASTAO.PRIJSTET_ID = PRIJSTET.ID)  
and prijstet.vros in (800)  and (PRIJSTET.BRPOLISE <> '9999999999')
and prijstet.brpolise = p.pol_brpol
) 
--and pol_brpol=884098
    
    
    
    ) loop
      l_broj := trunc ( dbms_lob.getlength(cur_rec.result.getclobval()) / 32000 );
      utl_file.put_line ( izlaz, '<?xml version="1.0" encoding="utf-8"?>' );
        for i in 1..l_broj loop
          utl_file.put ( izlaz, substr ( xmltype.getClobval(cur_rec.result), 32000 * ( i - 1 ) + 1, 32000) );
          utl_file.fflush ( izlaz );
        end loop;  
        if l_broj > 0 then
          utl_file.put ( izlaz, substr ( xmltype.getClobval(cur_rec.result), 32000 * ( l_broj ) + 1 ) );
          utl_file.fflush ( izlaz );
        else
          utl_file.put ( izlaz, substr ( xmltype.getClobval(cur_rec.result), 1) );
        end if; 
    end loop;    
  end if;
  
  utl_file.put_line ( logfl, 'Uspešno završeno.');
  utl_file.fclose_all;
  return l_UniqueID;
exception when others then
  utl_file.put_line ( logfl, 'Greška: ' || sqlerrm );
  utl_file.fclose_all;
  rollback;
  return 'FALSE';
END MAKE_XML;

/

