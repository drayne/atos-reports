create trigger RACUNAJ_PREMIJE
  before insert or update of OSNPREMAO, IZNOSBONMAL, PREMVOZAC, PREMPUTNICI, IZN_DOPLATKA, IZN_POPUSTA
  on POLAO3
  for each row
  declare
decimale number:=2;
begin
for red in (select to_number(vrijednost) as decim from bobar.parametri where lower(naziv)='decimale') loop
    decimale := red.decim;
end loop;
  if :new.vsdok <> 8 then
    :new.uk_prem_ano := round ( nvl ( :new.osnpremao, 0 ) +
                       nvl ( :new.iznosbonmal, 0 ) +
                       nvl ( :new.izn_doplatka, 0 ) +
                       nvl ( :new.izn_doplatka2, 0 ) +
                       nvl ( :new.izn_popusta, 0 ), decimale);
    :new.uk_prem_and := round ( nvl ( :new.premvozac, 0 ) +
                        nvl ( :new.premputnici, 0 ), decimale);
    :new.uk_prem_ao := round ( nvl ( :new.uk_prem_ano, 0 ) +
                       nvl ( :new.uk_prem_and, 0 ) +
                       nvl ( :new.uk_prem_akd, 0 ) +
                       nvl ( :new.uk_prem_lom, 0 ), decimale);
  end if;
end;
/

