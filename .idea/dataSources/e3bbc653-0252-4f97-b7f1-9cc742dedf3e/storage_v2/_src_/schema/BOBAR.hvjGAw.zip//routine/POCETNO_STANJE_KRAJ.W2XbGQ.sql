create PROCEDURE POCETNO_STANJE_KRAJ ( p_radnja number, p_vlasnik number ) IS
BEGIN

	for cur_rec in ( select konto, sum ( dev_duguje ) - sum ( dev_potrazuje ) saldo
										 from anlanl
										where anl_vlasnik = p_vlasnik and
										   		anl_radnja = p_radnja and
										   		ANL_VSDOK = 301 AND
           								DATNAL = TO_DATE ( '01.01.' || TO_CHAR ( SYSDATE, 'RRRR' ), 'DD.MM.RRRR')
           			 group by konto ) loop
		DELETE FROM ANLANL 
		   		WHERE anl_vlasnik = p_vlasnik and
								anl_radnja = p_radnja and
								konto = cur_rec.konto and
								cur_rec.saldo = 0 and
		   					ANL_VSDOK = 301 AND
 								DATNAL = TO_DATE ( '01.01.' || TO_CHAR ( SYSDATE, 'RRRR' ), 'DD.MM.RRRR');
 		end loop;

		update nalog set total_duguje = ( select nvl ( sum ( dev_duguje ), 0 )
																							from anlanl
																						 where nal_vlasnik = anl_vlasnik
																						 	 and nal_radnja = anl_radnja
																							 and nal_vsdok = anl_vsdok
																							 and nal_nalog = anl_nalog );

		update nalog set total_potrazuje = ( select nvl ( sum(dev_potrazuje), 0 )
																								 from anlanl
																								where nal_vlasnik = anl_vlasnik
																								  and nal_radnja = anl_radnja
																								  and nal_vsdok = anl_vsdok
																								  and nal_nalog = anl_nalog );

		update nalog set saldo_duguje = 0;

		update nalog set saldo_potrazuje = 0;

		update nalog set saldo_duguje = total_duguje - total_potrazuje
		 where total_duguje > total_potrazuje;
	
		update nalog set saldo_potrazuje = total_potrazuje - total_duguje
		 where total_potrazuje > total_duguje;

		commit;

END;

/

