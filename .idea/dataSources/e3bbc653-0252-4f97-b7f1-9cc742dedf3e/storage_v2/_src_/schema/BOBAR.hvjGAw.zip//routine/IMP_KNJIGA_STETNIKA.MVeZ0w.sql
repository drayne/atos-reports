create PROCEDURE "IMP_KNJIGA_STETNIKA" ( p_ime_fajla varchar2, p_put_do_fajla varchar2, p_delimiter varchar2 default ';', p_upisano out number, p_poruka out varchar2 ) AS
  ulaz utl_file.FILE_TYPE;
  izlaz utl_file.FILE_TYPE;
  EOF boolean;
  br_upisanih number;
  br_procitanih number;
  komad varchar(1024);
  l_komad varchar2(1024);
  l_knjiga knjiga_stetnika_svi%rowtype;
BEGIN
  EOF := FALSE;
  dbms_output.enable(100000);
  begin
    izlaz := utl_file.fopen ( p_put_do_fajla, p_ime_fajla || '.log', 'w' );
    ulaz  := utl_file.fopen ( p_put_do_fajla, p_ime_fajla || '.csv',  'r' );
    utl_file.put_line ( izlaz, 'otvoren.' );
  exception when utl_file.invalid_path then
    p_poruka := 'FOPEN:invalid_path';
    utl_file.put_line ( izlaz, 'FOPEN:invalid_path' );
    return;
  when utl_file.invalid_mode then
    p_poruka := 'FOPEN:invalid_mode';
    utl_file.put_line ( izlaz, 'FOPEN:invalid_mode' );
    return;
  when utl_file.invalid_operation then
    p_poruka := 'FOPEN:invalid_operation';
    utl_file.put_line ( izlaz, 'FOPEN:invalid_operation' );
    return;
  when others then
    p_poruka := 'Greška: ' || sqlerrm;
    return;
  end;

  if ( utl_file.is_open ( ulaz ) ) then
    utl_file.put_line ( izlaz, 'citam...' );
    br_upisanih := 0;
    br_procitanih := 0;
    loop
      begin
       	utl_file.get_line ( ulaz, komad );
        br_procitanih := br_procitanih + 1;
        if instr ( komad, p_delimiter, 1, 11 ) = 0 then
          utl_file.put_line ( izlaz, 'Ne postoji dovoljan broj kolona:' || komad);
        else
          l_knjiga.broj_stete           := ltrim ( rtrim ( substr ( komad, 1, instr ( komad, p_delimiter, 1, 1 ) - 1 ) ) );
          l_knjiga.datum_prijave        := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 1 ) + 1, instr ( komad, p_delimiter, 1, 2 ) - instr ( komad, p_delimiter, 1, 1 ) - 1 ) ) );
          l_knjiga.datum_nastanka       := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 2 ) + 1, instr ( komad, p_delimiter, 1, 3 ) - instr ( komad, p_delimiter, 1, 2 ) - 1 ) ) );
          l_knjiga.osiguranik           := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 3 ) + 1, instr ( komad, p_delimiter, 1, 4 ) - instr ( komad, p_delimiter, 1, 3 ) - 1 ) ) );
          l_knjiga.jmbg                 := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 4 ) + 1, instr ( komad, p_delimiter, 1, 5 ) - instr ( komad, p_delimiter, 1, 4 ) - 1 ) ) );
          l_knjiga.tip_vozila           := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 5 ) + 1, instr ( komad, p_delimiter, 1, 6 ) - instr ( komad, p_delimiter, 1, 5 ) - 1 ) ) );
          l_knjiga.registarska_oznaka   := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 6 ) + 1, instr ( komad, p_delimiter, 1, 7 ) - instr ( komad, p_delimiter, 1, 6 ) - 1 ) ) );
          l_knjiga.broj_polise          := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 7 ) + 1, instr ( komad, p_delimiter, 1, 8 ) - instr ( komad, p_delimiter, 1, 7 ) - 1 ) ) );
          l_knjiga.iznos_stete          := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 8 ) + 1, instr ( komad, p_delimiter, 1, 9 ) - instr ( komad, p_delimiter, 1, 8 ) - 1 ) ) );
          l_knjiga.datum_likvidacije    := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 9 ) + 1, instr ( komad, p_delimiter, 1, 10 ) - instr ( komad, p_delimiter, 1, 9 ) - 1 ) ) );
          l_knjiga.vozac                := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 10 ) + 1, instr ( komad, p_delimiter, 1, 11 ) - instr ( komad, p_delimiter, 1, 10 ) - 1 ) ) );
          l_knjiga.osig_kuca            := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 11 ) + 1 ) ) );
          insert into knjiga_stetnika_svi ( broj_stete,
                                            datum_prijave,
                                            datum_nastanka,
                                            osiguranik,
                                            jmbg,
                                            tip_vozila,
                                            registarska_oznaka,
                                            broj_polise,
                                            iznos_stete,
                                            datum_likvidacije,
                                            vozac,
                                            osig_kuca ) 
                                  values  ( l_knjiga.broj_stete,
                                            l_knjiga.datum_prijave,
                                            l_knjiga.datum_nastanka,
                                            l_knjiga.osiguranik,
                                            l_knjiga.jmbg,
                                            l_knjiga.tip_vozila,
                                            l_knjiga.registarska_oznaka,
                                            l_knjiga.broj_polise,
                                            l_knjiga.iznos_stete,
                                            l_knjiga.datum_likvidacije,
                                            l_knjiga.vozac,
                                            l_knjiga.osig_kuca );
          if sql%found then
            br_upisanih := br_upisanih + 1;
          end if;
--          utl_file.put_line ( izlaz, l_knjiga.broj_stete || '*****' || instr ( komad, p_delimiter, 1, 1 ));
        end if;
      exception	
        when no_data_found then EOF := TRUE;
        when others then utl_file.put_line ( izlaz, 'Greška: ' || sqlerrm || '--' || komad );
      end;
      exit when EOF;
    end loop;
  end if;
  commit;
  p_upisano := br_upisanih;
  utl_file.put_line ( izlaz, 'Zatvaram.' );
  utl_file.put_line ( izlaz, 'Ukupno procitano: ' || br_procitanih );
  utl_file.put_line ( izlaz, 'Ukupno upisano: ' || br_upisanih );
  utl_file.fclose ( ulaz );
  utl_file.fclose ( izlaz );
exception when others then
  rollback;
  p_poruka := 'Greška: ' || sqlerrm;
  utl_file.put_line ( izlaz, 'Zatvaram.' || 'Greška: ' || sqlerrm );
  utl_file.fclose ( ulaz );
  utl_file.fclose ( izlaz );
END IMP_KNJIGA_STETNIKA;


/

