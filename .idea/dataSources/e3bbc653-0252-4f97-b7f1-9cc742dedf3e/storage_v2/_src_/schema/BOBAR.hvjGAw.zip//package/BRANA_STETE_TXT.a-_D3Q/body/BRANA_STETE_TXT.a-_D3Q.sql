create PACKAGE BODY BRANA_STETE_TXT is
 Function c_date(u_str varchar2, u_fm varchar2) return date is
 i date;
 u varchar2(1022);
begin
 greska := null;
 u :=ltrim(rtrim(u_str));
 if (length(u) is null) then
  return null;
 end if;
 i := to_date(u_str,u_fm);
 return i;
 exception when others then
  greska := sqlerrm;
  logit('>'||u_str||'< ' || greska);
  return null;
end;
Function c_numb(u_str varchar2) return number is
 i number;
 u varchar2(1022);
begin
 greska := null;
 u := ltrim(rtrim(u_str));
 if ((length(u) is null) or (u = '.')) then
  return null;
 end if;
 i := to_number(u_str);
 return i;
exception when others then
  greska := sqlerrm;
  logit('>'||u_str||'< ' || greska);
  return null;
end;
PROCEDURE logit(st number, en number) is
begin
 utl_file.put_line(logfl,to_char(linija,'09999')||':'||substr(komad,st,en) || ':');
 utl_file.put_line(logfl,greska);
end;
procedure logit(ms varchar2) is
begin
 utl_file.put_line(logfl,to_char(linija,'09999')||':'|| ms);
end;
-----------------------------------------------------------
procedure BRANA_STETE_TXT (put_do_fajla varchar2, P_KONTO_OD IN VARCHAR2, P_KONTO_DO IN VARCHAR2, DATUM_OD IN DATE, DATUM_DO IN DATE) IS
CURSOR POLISE IS
SELECT
                        ANLANL.RJ,
                        TO_CHAR(ANLANL.DATDOK,'YYYY') GODINA,
                        TO_CHAR(ANLANL.DATDOK,'MM') MESEC,
                        SUM(ANLANL.DEV_DUGUJE) DUG,
                        SUM(ANLANL.DEV_POTRAZUJE) POT
FROM
                        ANLANL
WHERE
                        ANLANL.KONTO BETWEEN P_KONTO_OD
                                         AND P_KONTO_DO
                    AND ANLANL.ANL_VLASNIK = 1
                    AND ANLANL.ANL_RADNJA = 2
                    AND ANLANL.ANL_VSDOK != 301
                    AND
                            (TO_CHAR(ANLANL.DATDOK,'YYYYMMDD')
                                      BETWEEN
                             TO_CHAR(DATUM_OD,'YYYYMMDD')
                                      AND
                             TO_CHAR(DATUM_DO,'YYYYMMDD')
                            )
GROUP BY
                             ANLANL.RJ,
                             TO_CHAR(ANLANL.DATDOK,'YYYY'),
                             TO_CHAR(ANLANL.DATDOK,'MM')
ORDER BY
                             ANLANL.RJ,
                             TO_CHAR(ANLANL.DATDOK,'YYYY'),
                             TO_CHAR(ANLANL.DATDOK,'MM')
;
a varchar2(50);
IME_PODACI VARCHAR2(50);
IME_KONTROLNI VARCHAR2(50);

brojac number;

BEGIN

EOF:=FALSE;
 dbms_output.enable(100000);
 IME_PODACI := 'STETE_' || TO_CHAR(DATUM_DO,'YYMMDD') || '_TXT.TXT';
 begin
  IZLAZ:= utl_file.fopen(put_do_fajla,IME_PODACI,'w');
 exception when utl_file.invalid_path then
  logit('FOPEN:invalid_path');
 when utl_file.invalid_mode then
  logit('FOPEN:invalid_mode');
 when utl_file.invalid_operation then
  logit('FOPEN:invalid_operation');
 end;

 brojac := 0;

 FOR CUR_REC IN POLISE LOOP

       UTL_FILE.PUT_LINE(IZLAZ,
                        lpad(P_KONTO_OD, 8, ' ')
                     || '  '
                     || lpad(CUR_REC.RJ, 13, ' ')
                     || '  '
                     || CUR_REC.GODINA
                     || '  '
                     || CUR_REC.MESEC
                     || '  '
                     || TO_CHAR(CUR_REC.DUG,'999999990.00')
                     || '  '
                     || TO_CHAR(CUR_REC.POT,'999999990.00')
                     || '  '
                     );

             brojac := brojac + 1;
 END LOOP;

    UTL_FILE.FCLOSE_ALL;
    commit;

 EXCEPTION
 WHEN OTHERS THEN
    rollback;
    UTL_FILE.FCLOSE_ALL;
 END;
end;
/

