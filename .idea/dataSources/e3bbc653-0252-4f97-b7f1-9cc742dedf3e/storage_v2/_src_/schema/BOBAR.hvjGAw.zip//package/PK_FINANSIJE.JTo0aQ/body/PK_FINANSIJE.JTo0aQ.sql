create PACKAGE BODY PK_FINANSIJE AS

  function automatsko_zatvaranje_stavki ( p_vlasnik number,
                                          p_radnja number, 
                                          p_datum_od date, 
                                          p_datum_do date, 
                                          p_nivo varchar2 default 'D' ) return number AS

cursor c_anl is
  select  a.anl_vlasnik, a.anl_radnja, a.anl_vsdok, a.anl_nalog, a.anl_stavka
	  from  ANLANL a, nalog n
   where  a.anl_vlasnik = n.nal_vlasnik and
          a.anl_radnja = n.nal_radnja and
          a.anl_vsdok = n.nal_vsdok and
          a.anl_nalog = n.nal_nalog and
          n.zakljucen = 1 and 
          a.anl_vlasnik = p_vlasnik and
          a.anl_radnja = p_radnja and
          a.konto in (
                           (select distinct osigdug from semakont)
                            union
                           (select distinct osigdug from semakont_im)
                      ) and
          nvl(a.dev_potrazuje, 0) != 0 and
          nvl(a.dev_duguje, 0) = 0 and
          a.pol_brpol is not null and
          a.pol_brpol != '0' and
          nvl(a.dev_potrazuje, 0) != nvl(a.zatvoren_iznos, 0) and 
          nvl(a.reznum_1, 0) <> 0 and 
          to_char(a.datnal,'rrrrmmdd') between to_char(p_datum_od,'rrrrmmdd') and 
                                               to_char(p_datum_do,'rrrrmmdd') 
 order by a.datnal, a.pol_brpol, a.reznum_1, a.datdok, a.datval; --dodao Nikola 07.03.2010
	   
/*
          kursor za dugovnu stranu premija
	Kursor je sortiran po datumu valute (dospeća rate)
*//*
cursor c_drugi is        	             
        	             select anl_vlasnik, anl_radnja, anl_vsdok, anl_nalog, anl_stavka
        	             from   anlanl, nalog n
        	             where  
	                            anl_vlasnik = n.nal_vlasnik and
	                            anl_radnja = n.nal_radnja and
	                            anl_vsdok = n.nal_vsdok and
	                            anl_nalog = n.nal_nalog and
	                            n.zakljucen = 1 and 
        	                    anl_vlasnik = 1 and 
        	                    anl_radnja = 2 and 
        	                    anl_vsdok in (314, 315, 316, 319) and 
               konto in (
                             (select distinct osigdug from semakont)
                          union
                             (select distinct osigdug from semakont_im)
                          union
                             (select distinct konto_ukupno from semakontzk)
                          union (select '20100' from dual)
                        ) and
--        	                    konto = '20100' and
                              nvl(dev_potrazuje, 0) = 0 and
                              nvl(dev_duguje, 0) != 0 and
                              pol_brpol is not null and
                              pol_brpol != '0' and
                              pol_brpol = r_anl_uplata.pol_brpol and
                              nvl(zatvoren_iznos, 0) != nvl(dev_duguje, 0) and
                              reznum_1 = r_anl_uplata.reznum_1 and
        	                    to_char(anlanl.datnal,'rrrr') = to_char(p_datum_do,'rrrr')
        	      order by anlanl.datnal,anlanl.pol_brpol,anlanl.reznum_1,anlanl.datdok,anlanl.datval, nvl(anlanl.rezdat_1,anlanl.datval); --dodao Nikola 07.03.2010
 */ begin
      RETURN NULL;
  END automatsko_zatvaranje_stavki;

END PK_FINANSIJE;
/

