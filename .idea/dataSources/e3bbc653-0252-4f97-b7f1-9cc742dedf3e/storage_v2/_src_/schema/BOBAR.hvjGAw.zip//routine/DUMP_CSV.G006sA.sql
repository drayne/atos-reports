create FUNCTION       DUMP_CSV  ( p_query
    in varchar2,
                        p_separator in varchar2 default ',',
                        p_dir       in varchar2 ,
                        p_filename  in varchar2,
                        p_sta in varchar2,
                        p_mjgod in varchar2 )
    return number
    is
        l_output        utl_file.file_type;
        l_log						utl_file.file_type;
        l_theCursor     integer default dbms_sql.open_cursor;
       l_columnValue   varchar2(4000);
       l_status        integer;
       l_colCnt        number default 0;
       l_separator     varchar2(10) default '';
       l_cnt           number default 0;
   begin
       execute immediate 'alter session set nls_date_format=''dd.mm.rrrr''';
       execute immediate 'alter session set nls_numeric_characters=''.,''';

       l_output := utl_file.fopen( p_dir, p_filename, 'w' );
       l_log := utl_file.fopen( p_dir, p_filename || '.log', 'w' );
               utl_file.put_line( l_log, 'Krenuo...' );

       dbms_sql.parse(  l_theCursor,  p_query,
                                            dbms_sql.native );
               utl_file.put_line( l_log, '1' );

       for i in 1 .. 255 loop
           begin
               dbms_sql.define_column( l_theCursor, i,
                                       l_columnValue, 4000 );
               l_colCnt := i;
           exception
               when others then
                   if ( sqlcode = -1007 ) then exit;
                   else
                       raise;
                   end if;
           end;
       end loop;
               utl_file.put_line( l_log, '2' );

       dbms_sql.define_column( l_theCursor, 1,
                               l_columnValue, 4000 );

       l_status := dbms_sql.execute(l_theCursor);
               utl_file.put_line( l_log, '3' );

       loop
           exit when ( dbms_sql.fetch_rows(l_theCursor) <= 0 );
           l_separator := '';
           for i in 3 .. l_colCnt loop
               dbms_sql.column_value( l_theCursor, i,
                                      l_columnValue );
               utl_file.put( l_output,
                             l_separator || l_columnValue );
               utl_file.put( l_log,
                             l_separator || l_columnValue );
               l_separator := p_separator;
           end loop;
           utl_file.new_line( l_output );
           utl_file.new_line( l_log );
           l_cnt := l_cnt+1;
           dbms_sql.column_value( l_theCursor, 1,
                                  l_columnValue );

           if l_columnValue = '1' then
	           dbms_sql.column_value( l_theCursor, 2,
	                                  l_columnValue );
            if p_sta = 'polisa' then
             update polisa set biro_datum = to_date(sysdate, 'dd.mm.rrrr') where rowid = l_columnValue;
            elsif p_sta = 'zk' then
             --update zelkarton set biro_datum = to_date ( '01.' || p_mjgod, 'dd.mm.rrrr' ) where rowid = l_columnValue;
             update zelkarton set biro_datum = to_date ( sysdate, 'dd.mm.rrrr' ) where rowid = l_columnValue;
            elsif p_sta = 'steta' then
             --update prijstet set biro_datum = to_date ( '01.' || p_mjgod, 'dd.mm.rrrr' ) where rowid = l_columnValue;
             update prijstet set biro_datum = to_date (sysdate, 'dd.mm.rrrr' ) where rowid = l_columnValue;
           elsif l_columnValue = '2' then
	           dbms_sql.column_value( l_theCursor, 2,
	                                  l_columnValue );
            if p_sta = 'zk' then
             --update stroga set biro_datum = to_date ( '01.' || p_mjgod, 'dd.mm.rrrr' ) where rowid = l_columnValue;
             update stroga set biro_datum = to_date ( sysdate, 'dd.mm.rrrr' ) where rowid = l_columnValue;
            end if;
       end if;
      end if;
       end loop;
       dbms_sql.close_cursor(l_theCursor);

       utl_file.fclose( l_output );
       utl_file.fclose( l_log );

       return l_cnt;
   exception when others then
       utl_file.fclose( l_output );
       utl_file.put_line( l_log, sqlerrm || l_columnvalue );
       utl_file.fclose( l_log );
       return l_cnt;
   end dump_csv;

/

