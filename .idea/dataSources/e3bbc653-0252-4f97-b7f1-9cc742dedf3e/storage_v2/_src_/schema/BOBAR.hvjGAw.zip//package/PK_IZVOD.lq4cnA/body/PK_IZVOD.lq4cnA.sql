create PACKAGE BODY       "PK_IZVOD" 
    is
  Function c_date(u_str varchar2, u_fm varchar2) return date is
 i date;
 u varchar2(1022);
begin
 greska := null;
 u :=ltrim(rtrim(u_str));
 if (length(u) is null) then
  return null;
 end if;
 i := to_date(u_str,u_fm);
 return i;
 exception when others then
  greska := sqlerrm;
  logit('>'||u_str||'< ' || greska);
  return null;
end;
Function c_numb(u_str varchar2) return number is
 i number;
 u varchar2(1022);
begin
 greska := null;
 u := ltrim(rtrim(u_str));
 if ((length(u) is null) or (u = '.')) then
  return null;
 end if;
 i := to_number(u_str);
 return i;
exception when others then
  greska := sqlerrm;
  logit('>'||u_str||'< ' || greska);
  return null;
end;
PROCEDURE logit(st number, en number) is
begin
 utl_file.put_line(logfl,to_char(linija,'09999')||':'||substr(komad,st,en) || ':');
 utl_file.put_line(logfl,greska);
end;
procedure logit(ms varchar2) is
begin
 utl_file.put_line(logfl,to_char(linija,'09999')||':'|| ms);
end;
------------------------------------------------------------------------------------------------
PROCEDURE prenos ( put_do_fajla varchar2 default ps_put_do_fajla,
                   p_anl_vlasnik number,
                   p_anl_radnja number,
                   p_datum varchar2,
                   p_operater varchar2 ) IS
 izv izvod%ROWTYPE;
 anl_izv anlanl_izvod%ROWTYPE;
 l_old_partija izvod.partija%TYPE;
 l_old_broj_izvoda izvod.broj_izvoda%TYPE;
 nastavi boolean := TRUE;
 postoji number := -1;
 br_upisanih number;
 greska_upis boolean := FALSE;
 l_izvod_id number;
 l_ukupno_stavki number;
 l_ukupno_stavki_izvod number := 0;
 l_broj_polise varchar2(32);
 l_negativan_iznos number;
 l_dev_duguje varchar2(128);
 l_dev_potrazuje varchar2(128);
 linija_fajla varchar2(1024);
 broj_fajlova number(16) :=0;
 brojac number(16) := 0;
 
BEGIN

--trenutno omoguceno samo za dva fajla
--ukoliko bude potrebe za vise racuna, potrebno je modifikovati ucitavanje  fajlova i brojac realizovati drugacije
--za brojac = 0 ucitava 555, kod brojac = 1 ucitava 552 fajl
--TODO: za vise racuna pojedine banke koristiti npr 552a, 552b ili pune racune u nazivima fajlova. Ukoliko postoje fajlovi napraviti ARRAY (collection, record sta god je bolje rjesenje) od putanja fajlova koji ce se ucitavati. Kroz niz proci kasnije u kodu WHILE linija 103 i ucitati jedan po jedan u anlanl_izvod 
  begin
    if(fileexists(put_do_fajla, '555-' || p_datum ||  '.txt') = 1) --nova banka
    then 
            broj_fajlova := broj_fajlova +1;
    end if;        
    
    if(fileexists(put_do_fajla, '552-' || p_datum ||  '.txt') = 1) --addiko banka
        then 
            broj_fajlova := broj_fajlova +1;
    end if;            
    
    --ulaz := utl_file.fopen ( 'PISI', 'BOS-' || p_datum || '.txt', 'r' );
   --ulaz := utl_file.fopen ( 'GOGI_DP', 'BOS-' || p_datum || '.txt', 'r' );
    --ulaz := utl_file.fopen ( 'GOGI_DP', '1.txt', 'r' );
    --logfl:= utl_file.fopen ( 'PISI', 'BOS-' || p_datum || '_error.log', 'w' );
    --logfl:= utl_file.fopen ( 'GOGI_DP', 'BOS-' || p_datum || '_error.log', 'w' );
    --logfl:= utl_file.fopen ( 'GOGI_DP', 'error.log', 'w' );
  exception when utl_file.invalid_path then
    logit('FOPEN:invalid_path');
  when utl_file.invalid_mode then
    logit('FOPEN:invalid_mode');
  when utl_file.invalid_operation then
    logit('FOPEN:invalid_operation');
  end;
  execute immediate 'alter session set nls_date_format=''dd.mm.rrrr''';
  execute immediate 'alter session set nls_numeric_characters=''.,''';
  --execute immediate 'alter session set nls_numeric_characters=",."'; --posto je u Halcom fajlu dec=, hiljada=.
  
  while (brojac < broj_fajlova)  
  loop
        EOF:=FALSE;
        dbms_output.enable(100000);
        if(brojac = 0) then
              ulaz := utl_file.fopen ( put_do_fajla, '555-' || p_datum || '.txt', 'r' );
              logfl:= utl_file.fopen ( put_do_fajla, '555-' || p_datum || '_error.log', 'w' );
        end if;
        
        if(brojac = 1) then
              ulaz := utl_file.fopen ( put_do_fajla, '552-' || p_datum || '.txt', 'r' );
              logfl:= utl_file.fopen ( put_do_fajla, '552-' || p_datum || '_error.log', 'w' );
        end if;        
        
          if (utl_file.is_open(ulaz)) then
            logit ( 'Početak ' );
            l_ukupno_stavki := 0;
            br_upisanih := 0;
            loop
              begin
                utl_file.get_line(ulaz,linija_fajla);
                /* novi fajl AOS */
                --komad : jedan red fajla!
                izv.partija := replace(SUBSTR(linija_fajla, 0, INSTR(linija_fajla, '|', 1, 1)-1), '-'); --broj racuna
                linija_fajla := SUBSTR(linija_fajla,  INSTR(linija_fajla, '|', 1, 1)+1 );
                        
                izv.datum_izvoda := SUBSTR(linija_fajla, 0, INSTR(linija_fajla, '|', 1, 1)-1);
                linija_fajla := SUBSTR(linija_fajla,  INSTR(linija_fajla, '|', 1, 1)+1 );
                
                izv.broj_izvoda := SUBSTR(linija_fajla, 0, INSTR(linija_fajla, '|', 1, 1)-1);
                linija_fajla := SUBSTR(linija_fajla,  INSTR(linija_fajla, '|', 1, 1)+1 );
                
                l_dev_duguje := nvl(SUBSTR(linija_fajla, 0, INSTR(linija_fajla, '|', 1, 1)-1), 0);
                l_dev_duguje := replace(l_dev_duguje, '.', '');
                l_dev_duguje := replace(l_dev_duguje, ',', '.');
                anl_izv.dev_duguje := l_dev_duguje;
                linija_fajla := SUBSTR(linija_fajla,  INSTR(linija_fajla, '|', 1, 1)+1 );
                
                l_dev_potrazuje :=nvl(SUBSTR(linija_fajla, 0, INSTR(linija_fajla, '|', 1, 1)-1), 0);
                l_dev_potrazuje := replace(l_dev_potrazuje, '.', '');
                l_dev_potrazuje := replace(l_dev_potrazuje, ',', '.');
                anl_izv.dev_potrazuje := l_dev_potrazuje;
                linija_fajla := SUBSTR(linija_fajla,  INSTR(linija_fajla, '|', 1, 1)+1 );
                
                anl_izv.uplatilac_racun :=SUBSTR(linija_fajla, 0, INSTR(linija_fajla, '|', 1, 1)-1); --nije potreban, pa samo preskacemo...mogao bi se upisati u anl_izvod po potrebi(ne postoji navedena kolona)
                linija_fajla := SUBSTR(linija_fajla,  INSTR(linija_fajla, '|', 1, 1)+1 );        
                
                anl_izv.uplatilac :=SUBSTR(linija_fajla, 0, INSTR(linija_fajla, '|', 1, 1)-1);
                linija_fajla := SUBSTR(linija_fajla,  INSTR(linija_fajla, '|', 1, 1)+1 );
                
                anl_izv.opis := SUBSTR(linija_fajla, 0, INSTR(linija_fajla, '|', 1, 1)-1);
                linija_fajla := SUBSTR(linija_fajla,  INSTR(linija_fajla, '|', 1, 1)+1 );
                
                anl_izv.poziv_na_broj := linija_fajla;
                
                
                --logit(anl_izv.uplatilac); --UPIS U LOG
                /* novi fajl AOS */
                
                /* stari import
                izv.broj_izvoda            := ltrim ( rtrim ( substr ( komad, 4, 15 ) ) );
                izv.datum_izvoda      := c_date ( ltrim ( rtrim ( substr ( komad, 19, 8 ) ) ), 'ddmmrrrr' );
                izv.partija                 := ltrim ( rtrim ( substr ( komad, 27, 30 ) ) );
                anl_izv.anl_stavka      := c_numb ( ltrim ( rtrim ( substr ( komad, 57, 6 ) ) ) );
                anl_izv.poziv_na_broj    := ltrim ( rtrim ( substr ( komad, 63, 80 ) ) );
                anl_izv.uplatilac       := ltrim ( rtrim ( substr ( komad, 143, 60 ) ) );
                anl_izv.opis          := ltrim ( rtrim ( substr ( komad, 203, 45 ) ) );
                l_dev_duguje          := ltrim ( rtrim ( substr ( komad, 319, 9 ) ) ) || '.' || ltrim ( rtrim ( substr ( komad, 328, 2 ) ) );
                l_negativan_iznos     := instr ( anl_izv.dev_duguje, '-' ); --vb cini mi se kao greska i da bi trebalo u zagradi biti l_dev_duguje jer anl_izv.dev_duguje ovde jos uvijek nema vrijednost 
                if l_negativan_iznos > 0 then
                  anl_izv.dev_duguje := substr ( l_dev_duguje, l_negativan_iznos );
                else
                  anl_izv.dev_duguje := l_dev_duguje;
                end if;
                l_dev_potrazuje       := ltrim ( rtrim ( substr ( komad, 330, 9 ) ) ) || '.' || ltrim ( rtrim ( substr ( komad, 339, 2 ) ) );
                l_negativan_iznos     := instr ( l_dev_potrazuje, '-' );
                if l_negativan_iznos > 0 then
                  anl_izv.dev_potrazuje := substr ( l_dev_potrazuje, l_negativan_iznos );
                else
                  anl_izv.dev_potrazuje := l_dev_potrazuje;
                end if;
                */
                anl_izv.datdok        := izv.datum_izvoda;
                anl_izv.brdok         := izv.broj_izvoda;
                anl_izv.pol_brpol     := null;
                anl_izv.rj            := 101;
                anl_izv.jmbg          := null;
                anl_izv.reznum_1      := null;
                anl_izv.reznum_4      := null;
                
                if izv.partija = 5651624000000815 then
                  l_broj_polise := substr ( anl_izv.poziv_na_broj, -7 );
                  begin
                    if l_broj_polise is not null and
                       numericno ( l_broj_polise ) = 1 and
                       anl_izv.dev_potrazuje <> 0 then
                      SELECT POLISA.POL_BRPOL, ZASTUP.OJ, POLISA.MBRZASTUP, POLISA.VSDOK, POLISA.VROS
                        INTO ANL_IZV.POL_BRPOL, ANL_IZV.RJ, ANL_IZV.JMBG, ANL_IZV.REZNUM_1, ANL_IZV.REZNUM_4
                        FROM POLISA, ZASTUP 
                       WHERE POL_BRPOL = L_BROJ_POLISE AND 
                             abs ( UKPREMIJA - ANL_IZV.DEV_POTRAZUJE ) <= 1  AND
                             TO_CHAR ( DATIST, 'RRRRMMDD' ) >= TO_CHAR ( IZV.DATUM_IZVODA, 'RRRRMMDD' ) AND
                             MBRZASTUP = ZAS_SIFRA;
                    end if;
                  exception when others then
                    null;
                  end;
                end if;
                
                if nvl ( l_old_partija, '0' ) <> izv.partija then --uslov nije ispunjen kada se vrti ista partija kroz LOOP
                  if l_old_partija is not null then
                    logit ( 'Izvod broj: ' || l_old_broj_izvoda );
                    logit ( 'Partija broj: ' || l_old_partija );
                    logit ( 'Broj stavki: ' || l_ukupno_stavki );
                    logit ( 'Broj upisanih stavki: ' || br_upisanih );
                  end if;
                  l_ukupno_stavki := 0;
                  br_upisanih := 0;
                    
                  select count(*) into postoji from izvod where broj_izvoda = izv.broj_izvoda and partija = izv.partija;
                  if postoji > 0 then
                    logit ( 'U bazi već postoji izvod broj:' || izv.broj_izvoda || ' za partiju: ' || izv.partija );
                    greska_upis := TRUE; --odradi  se rollback kasnije svih redova
                    exit;          
                  end if;
                  select izvod_seq.nextval into l_izvod_id from dual;
                  insert into izvod ( id, broj_izvoda, datum_izvoda, partija, sifoperat, datumobrade ) 
                             values ( l_izvod_id, izv.broj_izvoda, izv.datum_izvoda, izv.partija, p_operater, sysdate );
                end if;
                l_ukupno_stavki := l_ukupno_stavki + 1;
                insert into anlanl_izvod ( anl_vlasnik, 
                                           anl_radnja,
                                           anl_vsdok,
                                           anl_stavka,
                                           datdok,
                                           brdok,
                                           dev_duguje,
                                           dev_potrazuje,
                                           komitent,
                                           jmbg,
                                           rj,
                                           pol_brpol,
                                           datnal,
                                           opis,
                                           valuta,
                                           konto,
                                           izvod_id,
                                           poziv_na_broj,
                                           reznum_1,
                                           reznum_4,
                                           uplatilac_racun,
                                           uplatilac,
                                           sifoperat,
                                           datumobrade ) 
                                  values ( p_anl_vlasnik,
                                           p_anl_radnja,
                                           306,
                                           --anl_izv.anl_stavka,   --posto nema broja stavke u izvodu, upisujem l_ukupno_stavki posto se on svakako inkrementuje svakim loop-om
                                           l_ukupno_stavki,
                                           anl_izv.datdok,
                                           anl_izv.brdok,
                                           anl_izv.dev_duguje,
                                           anl_izv.dev_potrazuje,
                                           1,
                                           anl_izv.jmbg,
                                           anl_izv.rj,
                                           anl_izv.pol_brpol,
                                           null,
                                           yusciilat ( anl_izv.opis ),
                                           977,
                                           decode ( izv.partija, 5651624000000815, 20100, null ),
                                           l_izvod_id,
                                           anl_izv.poziv_na_broj,
                                           anl_izv.reznum_1,
                                           anl_izv.reznum_4,
                                           anl_izv.uplatilac_racun,
                                           yusciilat ( anl_izv.uplatilac ),
                                           p_operater,
                                           sysdate );
                br_upisanih := br_upisanih + 1; 
                l_old_partija := izv.partija;
                l_old_broj_izvoda := izv.broj_izvoda;
              exception 
                when no_data_found then 
                  logit ( 'Izvod broj: ' || l_old_broj_izvoda );
                  logit ( 'Partija broj: ' || l_old_partija );
                  logit ( 'Broj stavki: ' || l_ukupno_stavki );
                  logit ( 'Broj upisanih stavki: ' || br_upisanih );
                  EOF := TRUE; 
                when others then 
                  logit ( sqlerrm || ' ' || komad); 
                  logit ( anl_izv.dev_duguje || '*' || anl_izv.potrazuje ); 
             end; 
             exit when EOF; 
             l_ukupno_stavki_izvod := l_ukupno_stavki_izvod + 1;
            end loop;

            if greska_upis then
              rollback;
            else
              commit;
            end if;
            
            logit( 'Ukupan broj stavki na izvodu: ' || l_ukupno_stavki_izvod );
            logit( 'Kraj.' );
            utl_file.fclose(logfl);
          end if;
        brojac := brojac +1;
    end loop; --while petlja   
    
    exception when others then
          logit ( sqlerrm || '.....' || br_upisanih );
          utl_file.fclose_all;
    raise;
END;
END;
/

