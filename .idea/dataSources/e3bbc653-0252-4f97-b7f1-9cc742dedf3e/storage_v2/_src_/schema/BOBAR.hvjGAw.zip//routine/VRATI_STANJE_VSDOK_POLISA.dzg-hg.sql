create FUNCTION       "VRATI_STANJE_VSDOK_POLISA" (p_vsdok in number, p_polisa in number, p_datod date, p_datdo date) RETURN float  AS 
r_stanje float(32);
BEGIN
        select sum(dev_duguje-dev_potrazuje)
        into r_stanje
        from anlanl a
        where A.ANL_VSDOK = p_vsdok
        and A.DATDOK between p_datod and p_datdo
        and A.POL_BRPOL = p_polisa
        and A.KONTO in (20100, 20110, 20120, 20130, 20190);
        return r_stanje;
  
 exception
        when NO_DATA_FOUND    then return 0;     
  
END;

/

