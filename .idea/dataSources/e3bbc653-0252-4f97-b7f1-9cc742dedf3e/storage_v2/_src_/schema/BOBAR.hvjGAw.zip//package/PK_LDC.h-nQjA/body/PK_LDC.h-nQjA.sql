create PACKAGE BODY Pk_Ldc AS
/******************************************************************************
   name:       pk_ldc
   purpose:    paket sadrzi funkcije i procedure koje se odnose na plate
******************************************************************************/

  CURSOR c_radnik(p_vlasnik IN NUMBER, p_lokacija IN NUMBER) IS
  SELECT rad_sifra
    FROM TLDC_RADNIK
   WHERE vlasnik  = p_vlasnik
     AND lokacija = p_lokacija;

  CURSOR c_sati(p_obracun IN TLDC_OBRACUN%ROWTYPE, p_radnik IN NUMBER) IS
  SELECT os.obst_vlasnik,
         os.obst_lokacija,
         os.obst_godina,
         os.obst_mesec,
         os.obst_broj,
         os.obst_radnik,
         os.obst_vrstasata
    FROM TLDC_OBRACUNSTAVKA os
   WHERE os.obst_vlasnik  = p_obracun.obr_vlasnik
     AND os.obst_lokacija = p_obracun.obr_lokacija
     AND os.obst_godina   = p_obracun.obr_godina
     AND os.obst_mesec    = p_obracun.obr_mesec
     AND os.obst_broj     = p_obracun.obr_broj
     AND os.obst_radnik = p_radnik
   ORDER BY os.obst_vrstasata ASC;

  CURSOR c_sati_sve(p_obracun IN TLDC_OBRACUN%ROWTYPE, p_radnik IN NUMBER) IS
  SELECT *
    FROM TLDC_OBRACUNSTAVKA
   WHERE obst_vlasnik  = p_obracun.obr_vlasnik
     AND obst_lokacija = p_obracun.obr_lokacija
     AND obst_godina   = p_obracun.obr_godina
     AND obst_mesec    = p_obracun.obr_mesec
     AND obst_broj     = p_obracun.obr_broj
     AND obst_radnik = p_radnik
   ORDER BY obst_vrstasata ASC
     FOR UPDATE;

  FUNCTION f_zaokruzi(p_iznos IN NUMBER) RETURN NUMBER IS
  /*
    Zaokruzivanje iznosa.
    Za sada radi obican round, ali ce kasnije biti dodato
    zaokruzivanje na ceo dinar ili 50 para i sl.
  */
  BEGIN
    RETURN ROUND(p_iznos, 2);
  END f_zaokruzi;

  PROCEDURE p_kreiraj_sate_radnika(p_obracun IN TLDC_OBRACUN%ROWTYPE, p_rad_sifra IN TLDC_RADNIK.rad_sifra%TYPE) IS
  /*
    Dodaj stavke obracuna za jednog radnika na osnovu TLDC_VRSTASATASABIRAU
  */
    r_vrstasata TLDC_VRSTASATA%ROWTYPE;
  BEGIN
      /*
        Brisanje zbirnih sati
      delete tldc_obracunstavka
       where obst_vlasnik  = p_obracun.obr_vlasnik
         and obst_lokacija = p_obracun.obr_lokacija
         and obst_godina   = p_obracun.obr_godina
         and obst_mesec    = p_obracun.obr_mesec
         and obst_broj     = p_obracun.obr_broj
         and obst_radnik   = p_rad_sifra
         and exists (select 1
                       from tldc_vrstasata
                      where vrsat_sifra = obst_vrstasata
                        and zbirnasifra is not null);
      */

      /*
        Stavke obracuna tekuceg radnika
      */
      FOR r_sati IN c_sati_sve(p_obracun, p_rad_sifra) LOOP
        /*
          Polja koja se ne unose za tekucu vrstu sata staviti na NULL
        */
        SELECT *
          INTO r_vrstasata
          FROM TLDC_VRSTASATA
         WHERE vrsat_sifra = r_sati.obst_vrstasata;

        IF r_vrstasata.unos_sati = 0 THEN
          r_sati.sati := NULL;
        END IF;
        IF r_vrstasata.unos_bodova = 0 THEN
          r_sati.bodova := NULL;
        END IF;
        IF r_vrstasata.unos_fiksniiznos = 0 THEN
          r_sati.fiksniiznos := NULL;
        END IF;
        IF r_vrstasata.unos_ucinakradnika = 0 THEN
          r_sati.ucinakradnika := NULL;
        END IF;
        IF r_vrstasata.unos_mtr = 0 THEN
          r_sati.mtr := NULL;
        END IF;
        IF r_vrstasata.unos_radninalog = 0 THEN
          r_sati.radninalog := NULL;
        END IF;
        IF r_vrstasata.unos_podbroj = 0 THEN
          r_sati.podbroj := NULL;
        END IF;
        IF r_vrstasata.unos_obracunatiznos = 0 THEN
          r_sati.obracunatiznos := NULL;
        END IF;
        IF r_vrstasata.unos_iznosukupno = 0 THEN
          r_sati.iznosukupno := NULL;
        END IF;
        IF r_vrstasata.unos_iznosranije = 0 THEN
          r_sati.iznosranije := NULL;
        END IF;
        IF r_vrstasata.unos_iznosrazlika = 0 THEN
          r_sati.iznosrazlika := NULL;
        END IF;

        UPDATE TLDC_OBRACUNSTAVKA
           SET sati           = r_sati.sati,
               bodova         = r_sati.bodova,
               fiksniiznos    = r_sati.fiksniiznos,
               ucinakradnika  = r_sati.ucinakradnika,
               mtr            = r_sati.mtr,
               radninalog     = r_sati.radninalog,
               podbroj        = r_sati.podbroj,
               obracunatiznos = r_sati.obracunatiznos,
               iznosukupno    = r_sati.iznosukupno,
            -- iznosranije    = r_sati.iznosranije,
               iznosrazlika   = r_sati.iznosrazlika
         WHERE CURRENT OF c_sati_sve;

        /*
          Dodavanje zbirnih sati koji nedostaju
        */
        FOR r_sabirau IN (SELECT vssu_sifravrstesata_u
                            FROM TLDC_VRSTASATASABIRAU
                           START WITH vssu_sifravrstesata = r_sati.obst_vrstasata
                         CONNECT BY PRIOR vssu_sifravrstesata_u = vssu_sifravrstesata) LOOP
          BEGIN
            INSERT INTO TLDC_OBRACUNSTAVKA (
              obst_vlasnik,
              obst_lokacija,
              obst_godina,
              obst_mesec,
              obst_broj,
              obst_radnik,
              obst_vrstasata,
              operater
            ) VALUES (
              p_obracun.obr_vlasnik,
              p_obracun.obr_lokacija,
              p_obracun.obr_godina,
              p_obracun.obr_mesec,
              p_obracun.obr_broj,
              p_rad_sifra,
              r_sabirau.vssu_sifravrstesata_u,
              r_sati.operater
            );
          EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN NULL;
          END;
        END LOOP;
      END LOOP;

  END p_kreiraj_sate_radnika;

  PROCEDURE p_kreiraj_sate(p_obracun IN TLDC_OBRACUN%ROWTYPE) IS
  /*
    Dodaj stavke obracuna za sve radnike na osnovu TLDC_VRSTASATASABIRAU
  */
  BEGIN
    /*
      Svi radnici organizacionog dela
    */
    FOR r_radnik IN c_radnik(p_obracun.obr_vlasnik, p_obracun.obr_lokacija) LOOP
      p_kreiraj_sate_radnika(p_obracun, r_radnik.rad_sifra);
    END LOOP;
  END p_kreiraj_sate;


  PROCEDURE p_saberi_sate(p_sat IN c_sati%ROWTYPE) IS
  /*
    Procedura sabira sate, bodove i obracunati iznos iz zadate stavke
    obracuna u sve zbirne sate u koje se ta vrsta sata sabira
  */
    l_sati NUMBER;
    l_bodova NUMBER;
    l_obracunatiznos NUMBER;
  BEGIN
    SELECT sati, bodova, obracunatiznos
      INTO l_sati, l_bodova, l_obracunatiznos
      FROM TLDC_OBRACUNSTAVKA
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;
    FOR r_sabirau IN (SELECT vssu_sifravrstesata_u, znakzacasove, znakzaiznos, znakzabodove
                        FROM TLDC_VRSTASATASABIRAU
                       WHERE vssu_sifravrstesata = p_sat.obst_vrstasata) LOOP
      UPDATE TLDC_OBRACUNSTAVKA
         SET sati           = NVL(sati, 0)           + (r_sabirau.znakzacasove * NVL(l_sati, 0)),
             bodova         = NVL(bodova, 0)         + (r_sabirau.znakzabodove * NVL(l_bodova, 0)),
             obracunatiznos = NVL(obracunatiznos, 0) + (r_sabirau.znakzaiznos  * NVL(l_obracunatiznos, 0))
       WHERE obst_vlasnik   = p_sat.obst_vlasnik
         AND obst_lokacija  = p_sat.obst_lokacija
         AND obst_godina    = p_sat.obst_godina
         AND obst_mesec     = p_sat.obst_mesec
         AND obst_broj      = p_sat.obst_broj
         AND obst_radnik    = p_sat.obst_radnik
         AND obst_vrstasata = r_sabirau.vssu_sifravrstesata_u;
     END LOOP;
  END;

  PROCEDURE p_obr_00(p_sat IN c_sati%ROWTYPE) IS
  /*
    Procedura ne radi nista, samo sluzi kao template za ostale procedure
  */
  BEGIN
    NULL;
  END p_obr_00;

  PROCEDURE p_obr_01(p_sat IN c_sati%ROWTYPE) IS
  /*
    p_obr_01
    Redovan rad
  */
    l_sati NUMBER;
    l_broj_bodova NUMBER;
    l_planirano_sati NUMBER;
    l_ucinakradnika NUMBER;
    l_uvecanje NUMBER;
    l_vrednost_boda NUMBER;
    l_uk_bodova NUMBER;
    l_fiksniiznos NUMBER;
    l_iznos NUMBER;
    l_ucinak NUMBER;
  BEGIN

    SELECT sati, NVL(ucinakradnika, 1), NVL(fiksniiznos, 0)
      INTO l_sati, l_ucinakradnika, l_fiksniiznos
      FROM TLDC_OBRACUNSTAVKA
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

    IF l_ucinakradnika = 0 THEN
      l_ucinakradnika := 1;
    END IF;

    SELECT planirano_sati, vrednost_boda, ucinak
      INTO l_planirano_sati, l_vrednost_boda, l_ucinak
      FROM TLDC_OBRACUN
     WHERE obr_vlasnik   = p_sat.obst_vlasnik
       AND obr_lokacija  = p_sat.obst_lokacija
       AND obr_godina    = p_sat.obst_godina
       AND obr_mesec     = p_sat.obst_mesec
       AND obr_broj      = p_sat.obst_broj;

    IF l_ucinak IS NULL OR l_ucinak = 0 THEN
      l_ucinak := 1;
    END IF;

    SELECT broj_bodova
      INTO l_broj_bodova
      FROM TLDC_POSLOVI p, TLDC_RADNIK r
     WHERE p.pos_vlasnik   = r.vlasnik
       AND p.pos_lokacija  = r.lokacija
       AND p.pos_sifra     = r.poslovi
       AND r.rad_sifra = p_sat.obst_radnik;

    SELECT NVL(uvecanje, 0)
      INTO l_uvecanje
      FROM TLDC_VRSTASATA
     WHERE vrsat_sifra = p_sat.obst_vrstasata;

    l_uk_bodova := (l_sati / l_planirano_sati) *
                   l_broj_bodova *
                   l_ucinakradnika *
                   l_ucinak *
                   ((100 + l_uvecanje) / 100);
    l_iznos := ROUND(l_uk_bodova * l_vrednost_boda, 2) + l_fiksniiznos;

    UPDATE TLDC_OBRACUNSTAVKA
       SET bodova = l_uk_bodova,
           obracunatiznos = l_iznos
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

  END p_obr_01;

  PROCEDURE p_obr_02(p_sat IN c_sati%ROWTYPE) IS
  /*
    p_obr_02
    Evidentno
  */
  BEGIN
    /*
      Obrada ne radi nista
    */
    NULL;
  END p_obr_02;

  PROCEDURE p_obr_13(p_sat IN c_sati%ROWTYPE) IS
  /*
    p_obr_13
    Nacin obracuna 13
  */
    l_bodova NUMBER;
    l_vrednost_boda NUMBER;
    l_ucinakradnika NUMBER;
    l_uvecanje NUMBER;
    l_fiksniiznos NUMBER;
    l_iznos NUMBER;
    l_ucinak NUMBER;
  BEGIN
    SELECT ucinakradnika, NVL(fiksniiznos, 0), bodova
      INTO l_ucinakradnika, l_fiksniiznos, l_bodova
      FROM TLDC_OBRACUNSTAVKA
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

    IF l_ucinakradnika IS NULL OR l_ucinakradnika = 0 THEN
      l_ucinakradnika := 1;
    END IF;

    SELECT vrednost_boda, ucinak
      INTO l_vrednost_boda, l_ucinak
      FROM TLDC_OBRACUN
     WHERE obr_vlasnik   = p_sat.obst_vlasnik
       AND obr_lokacija  = p_sat.obst_lokacija
       AND obr_godina    = p_sat.obst_godina
       AND obr_mesec     = p_sat.obst_mesec
       AND obr_broj      = p_sat.obst_broj;

    IF l_ucinak IS NULL OR l_ucinak = 0 THEN
      l_ucinak := 1;
    END IF;

    SELECT NVL(uvecanje, 0)
      INTO l_uvecanje
      FROM TLDC_VRSTASATA
     WHERE vrsat_sifra = p_sat.obst_vrstasata;

    l_iznos := l_bodova * l_vrednost_boda * l_ucinakradnika * l_ucinak;
    l_iznos := l_iznos + l_fiksniiznos;
    l_iznos := ROUND(l_iznos * ((100 + l_uvecanje) / 100), 2);

    UPDATE TLDC_OBRACUNSTAVKA
       SET obracunatiznos = l_iznos
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

  END p_obr_13;

  PROCEDURE p_obr_56(p_sat IN c_sati%ROWTYPE) IS
  /*
    p_obr_56
    Preracun na bruto prema granicama za KVL
  */
    l_kval_iznos NUMBER;
    l_sati NUMBER;
    l_obracunatiznos NUMBER;
    l_planirano_sati NUMBER;
    l_prosek NUMBER;
    l_iznos_grana NUMBER;
    l_btto NUMBER;
    l_stopa_nme NUMBER;
    l_porez NUMBER;
    l_iznos NUMBER;
  BEGIN
    SELECT k.iznos
      INTO l_kval_iznos
      FROM TLDC_RADNIK r, TLDC_KVALIFIKACIJE k
     WHERE r.rad_sifra = p_sat.obst_radnik
       AND r.kvalifikacija = k.kvl_sifra;

    SELECT sati, obracunatiznos
      INTO l_sati, l_obracunatiznos
      FROM TLDC_OBRACUNSTAVKA
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

    SELECT planirano_sati, prosek_republike
      INTO l_planirano_sati, l_prosek
      FROM TLDC_OBRACUN
     WHERE obr_vlasnik   = p_sat.obst_vlasnik
       AND obr_lokacija  = p_sat.obst_lokacija
       AND obr_godina    = p_sat.obst_godina
       AND obr_mesec     = p_sat.obst_mesec
       AND obr_broj      = p_sat.obst_broj;

    SELECT SUM(dp.procenat)
      INTO l_stopa_nme
      FROM TLDC_DOPRINOS dp, orgdeo od, mesto me, opstina op
     WHERE od.vlasnik = p_sat.obst_vlasnik
       AND od.radnja  = p_sat.obst_lokacija
       AND od.mesto = me.mes_sifra
       AND me.opst = op.ops_sifra
       AND op.model_doprinosa = dp.model
       AND dp.vrsta = 'R';

    SELECT SUM(procenat)
      INTO l_porez
      FROM TLDC_DOPRINOS
     WHERE vrsta = 'P';

    l_kval_iznos := l_kval_iznos * l_sati / l_planirano_sati;
    l_iznos_grana := 5 * l_prosek;
    l_btto := f_zaokruzi(l_obracunatiznos * 100 / (100 - l_stopa_nme - l_porez));

    IF l_btto > l_iznos_grana THEN
      l_iznos := f_zaokruzi(l_obracunatiznos + (l_iznos_grana * l_stopa_nme / 100));
      l_iznos := f_zaokruzi(l_iznos * 100 / (100 - l_porez));
    ELSIF l_btto > l_kval_iznos THEN
      l_iznos := f_zaokruzi(l_obracunatiznos * 100 / (100 - l_stopa_nme - l_porez));
    ELSE
      l_iznos := f_zaokruzi((l_obracunatiznos + (l_kval_iznos * l_stopa_nme / 100)) * 100 / (100 - l_porez));
    END IF;

    UPDATE TLDC_OBRACUNSTAVKA
       SET obracunatiznos = l_iznos
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

  END p_obr_56;

  PROCEDURE p_obr_62(p_sat IN c_sati%ROWTYPE) IS
  /*
    p_obr_62
    Obracun doprinosa
  */
    l_osnov TLDC_VRSTASATA.vrsat_sifra%TYPE;
    l_procenat NUMBER;
    l_iznos NUMBER;
  BEGIN

    SELECT dp.osnov, dp.procenat
      INTO l_osnov, l_procenat
      FROM TLDC_VRSTASATA vs, TLDC_DOPRINOS dp
     WHERE vs.vrsat_sifra = p_sat.obst_vrstasata
       AND vs.doprinos = dp.dop_sifra;

    SELECT obracunatiznos * l_procenat / 100.00
      INTO l_iznos
      FROM TLDC_OBRACUNSTAVKA
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = l_osnov;

    UPDATE TLDC_OBRACUNSTAVKA
       SET obracunatiznos = ROUND(l_iznos, 2)
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

  END p_obr_62;

  PROCEDURE p_obr_63(p_sat IN c_sati%ROWTYPE) IS
  /*
    p_obr_63
    Obracun poreza
  */
    l_osnov TLDC_VRSTASATA.vrsat_sifra%TYPE;
    l_procenat NUMBER;
    l_iznos NUMBER;
    l_placa_porez NUMBER;
  BEGIN

    /*
      Da li radnik placa porez?
    */
    SELECT porez
      INTO l_placa_porez
      FROM TLDC_RADNIK
     WHERE rad_sifra = p_sat.obst_radnik;

    IF l_placa_porez = 1 THEN

      SELECT dp.osnov, dp.procenat
        INTO l_osnov, l_procenat
        FROM TLDC_VRSTASATA vs, TLDC_DOPRINOS dp
       WHERE vs.vrsat_sifra = p_sat.obst_vrstasata
         AND vs.doprinos = dp.dop_sifra;

      SELECT obracunatiznos * l_procenat / 100.00
        INTO l_iznos
        FROM TLDC_OBRACUNSTAVKA
       WHERE obst_vlasnik   = p_sat.obst_vlasnik
         AND obst_lokacija  = p_sat.obst_lokacija
         AND obst_godina    = p_sat.obst_godina
         AND obst_mesec     = p_sat.obst_mesec
         AND obst_broj      = p_sat.obst_broj
         AND obst_radnik    = p_sat.obst_radnik
         AND obst_vrstasata = l_osnov;

      UPDATE TLDC_OBRACUNSTAVKA
         SET obracunatiznos = ROUND(l_iznos, 2)
       WHERE obst_vlasnik   = p_sat.obst_vlasnik
         AND obst_lokacija  = p_sat.obst_lokacija
         AND obst_godina    = p_sat.obst_godina
         AND obst_mesec     = p_sat.obst_mesec
         AND obst_broj      = p_sat.obst_broj
         AND obst_radnik    = p_sat.obst_radnik
         AND obst_vrstasata = p_sat.obst_vrstasata;

    END IF;

  END p_obr_63;

  PROCEDURE p_obr_64(p_sat IN c_sati%ROWTYPE) IS
  /*
    p_obr_64
    Obracun toplog obroka
  */
    l_sati NUMBER;
    l_planirano_sati NUMBER;
    l_prosek NUMBER;
    l_proc_to NUMBER;
    l_iznos NUMBER;
  BEGIN

    SELECT sati
      INTO l_sati
      FROM TLDC_OBRACUNSTAVKA
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

    SELECT planirano_sati, prosek_republike
      INTO l_planirano_sati, l_prosek
      FROM TLDC_OBRACUN
     WHERE obr_vlasnik   = p_sat.obst_vlasnik
       AND obr_lokacija  = p_sat.obst_lokacija
       AND obr_godina    = p_sat.obst_godina
       AND obr_mesec     = p_sat.obst_mesec
       AND obr_broj      = p_sat.obst_broj;

    SELECT vrednost_num
      INTO l_proc_to
      FROM TLDC_PARAMETRI
     WHERE par_vlasnik = p_sat.obst_vlasnik
       AND par_lokacija = p_sat.obst_lokacija
       AND par_naziv = 'PROCENAT TO';

    l_iznos := f_zaokruzi(l_prosek * l_proc_to / 100 * l_sati / l_planirano_sati);

    UPDATE TLDC_OBRACUNSTAVKA
       SET obracunatiznos = l_iznos
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

  END p_obr_64;

  PROCEDURE p_obr_67(p_sat IN c_sati%ROWTYPE) IS
  /*
    p_obr_67
    Obracun osnova doprinosa
  */
    l_kval_iznos NUMBER;
    l_sati NUMBER;
    l_planirano_sati NUMBER;
    l_obracunatiznos NUMBER;
    l_iznos NUMBER;
    l_prosek NUMBER;
  BEGIN

    SELECT k.iznos
      INTO l_kval_iznos
      FROM TLDC_RADNIK r, TLDC_KVALIFIKACIJE k
     WHERE r.rad_sifra = p_sat.obst_radnik
       AND r.kvalifikacija = k.kvl_sifra;

    SELECT sati, obracunatiznos
      INTO l_sati, l_obracunatiznos
      FROM TLDC_OBRACUNSTAVKA
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

    SELECT planirano_sati, prosek_republike
      INTO l_planirano_sati, l_prosek
      FROM TLDC_OBRACUN
     WHERE obr_vlasnik   = p_sat.obst_vlasnik
       AND obr_lokacija  = p_sat.obst_lokacija
       AND obr_godina    = p_sat.obst_godina
       AND obr_mesec     = p_sat.obst_mesec
       AND obr_broj      = p_sat.obst_broj;

    l_iznos := l_kval_iznos * l_sati / l_planirano_sati;
    IF l_obracunatiznos > l_iznos THEN
      l_iznos := l_obracunatiznos;
    END IF;
    IF l_iznos > 5 * l_prosek THEN
      l_iznos := 5 * l_prosek;
    END IF;

    UPDATE TLDC_OBRACUNSTAVKA
       SET obracunatiznos = ROUND(l_iznos, 2)
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

  END p_obr_67;

  PROCEDURE p_obr_70(p_sat IN c_sati%ROWTYPE) IS
  /*
    p_obr_70
    Obracun regresa za ustanove
  */
    l_ima_regres NUMBER;
    l_prosek NUMBER;
    l_proc_reg NUMBER;
    l_iznos NUMBER;
  BEGIN

    SELECT regres
      INTO l_ima_regres
      FROM TLDC_RADNIK
     WHERE rad_sifra = p_sat.obst_radnik;

    IF l_ima_regres = 1 THEN

      SELECT prosek_republike
        INTO l_prosek
        FROM TLDC_OBRACUN
       WHERE obr_vlasnik   = p_sat.obst_vlasnik
         AND obr_lokacija  = p_sat.obst_lokacija
         AND obr_godina    = p_sat.obst_godina
         AND obr_mesec     = p_sat.obst_mesec
         AND obr_broj      = p_sat.obst_broj;

      SELECT vrednost_num
        INTO l_proc_reg
        FROM TLDC_PARAMETRI
       WHERE par_vlasnik = p_sat.obst_vlasnik
         AND par_lokacija = p_sat.obst_lokacija
         AND par_naziv = 'PROCENAT REGRES';

      l_iznos := f_zaokruzi(l_prosek * l_proc_reg / 100);

    ELSE
      l_iznos := 0;
    END IF;

    UPDATE TLDC_OBRACUNSTAVKA
       SET obracunatiznos = l_iznos
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

  END p_obr_70;

  PROCEDURE p_obr_77(p_sat IN c_sati%ROWTYPE) IS
  /*
    p_obr_77
    Obracun minulog rada

    obracunati iznos se mnozi sa PROCENAT MINULI RAD iz TLDC_PARAMETRI i
    brojem godina radnog staza na datum isplate i to se stavlja u obracunati iznos.
  */
    l_datum_isplate DATE;
    l_procenat NUMBER;
    l_iznos NUMBER;
    l_datum_zaposlenja DATE;
    staz_god NUMBER;
    staz_mes NUMBER;
    staz_dan NUMBER;
    l_mesec1 NUMBER;
    l_mesec2 NUMBER;
    l_godina NUMBER;
  BEGIN

    SELECT obracunatiznos
      INTO l_iznos
      FROM TLDC_OBRACUNSTAVKA
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

    SELECT datum_isplate
      INTO l_datum_isplate
      FROM TLDC_OBRACUN
     WHERE obr_vlasnik   = p_sat.obst_vlasnik
       AND obr_lokacija  = p_sat.obst_lokacija
       AND obr_godina    = p_sat.obst_godina
       AND obr_mesec     = p_sat.obst_mesec
       AND obr_broj      = p_sat.obst_broj;

    SELECT vrednost_num
      INTO l_procenat
      FROM TLDC_PARAMETRI
     WHERE par_vlasnik = p_sat.obst_vlasnik
       AND par_lokacija = p_sat.obst_lokacija
       AND par_naziv = 'PROCENAT MINULI RAD';

    SELECT datum_zaposlenja, staz_god, staz_mes, staz_dan
      INTO l_datum_zaposlenja, staz_god, staz_mes, staz_dan
      FROM TLDC_RADNIK
     WHERE rad_sifra = p_sat.obst_radnik;

    l_mesec1 := staz_god * 12 + staz_mes + staz_dan/31;
    l_mesec2 := MONTHS_BETWEEN(l_datum_isplate, l_datum_zaposlenja);
    l_godina := TRUNC((l_mesec1 + l_mesec2) / 12);

    l_iznos := f_zaokruzi(l_iznos * l_procenat * l_godina / 100);

    UPDATE TLDC_OBRACUNSTAVKA
       SET obracunatiznos = l_iznos
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

  END p_obr_77;

  PROCEDURE p_obr_99(p_sat IN c_sati%ROWTYPE) IS
  /*
    p_obr_99
    Obracun obustava

    Prodje se kroz karticu obustava i izracunaju se iznosi za svaku od njih.
    Zbir tih iznosa se sabere sa iznosranije iz stavke obracuna i to se
    upise u obracunati iznos.
  */

    CURSOR c IS
    SELECT kob.kob_rbr, kob.kob_broj_rate, kob.iznos,
           obu.iznosrate, obu.brojrata, obu.ostatakduga, obu.osnov, obu.procenat
      FROM TLDC_KARTICAOBUSTAVA kob, TLDC_OBUSTAVA obu
     WHERE kob.kob_radnik   = p_sat.obst_radnik
       AND kob.obr_vlasnik  = p_sat.obst_vlasnik
       AND kob.obr_lokacija = p_sat.obst_lokacija
       AND kob.obr_godina   = p_sat.obst_godina
       AND kob.obr_mesec    = p_sat.obst_mesec
       AND kob.obr_broj     = p_sat.obst_broj
       AND kob.kob_radnik = obu.obu_radnik
       AND kob.kob_rbr    = obu.obu_rbr
       FOR UPDATE OF kob.iznos;

    l_iznos NUMBER;
    l_zbir NUMBER;

  BEGIN
  	dbms_output.put_line('p_obr_99 - in');
    l_zbir := 0;
    FOR r IN c LOOP
      IF r.brojrata IS NULL AND r.procenat IS NULL THEN
        /*
          iznos rate je fiksan
        */
        l_iznos := r.iznosrate;
      ELSIF r.brojrata IS NOT NULL THEN
        /*
          ako je kob_broj_rate = brojrata (znaci u pitanju je poslednja rata)
          iznos je jednak ostatku duga.

          ako je ostatakduga - iznosrate < iznosrate (znaci kada se odbije rata, ostatak duga je manji od iznosa rate)
          iznos je jednak ostatku duga.

          u ostalim slucajevima iznos je jednak iznosu rate
        */
        IF r.kob_broj_rate = r.brojrata THEN
          l_iznos := r.ostatakduga;
        ELSIF r.ostatakduga - r.iznosrate < r.iznosrate THEN
          l_iznos := r.ostatakduga;
        ELSE
          l_iznos := r.iznosrate;
        END IF;
      ELSIF r.procenat IS NOT NULL THEN
        /*
          iznos je jednak procentu od obracunatog iznosa iz stavke obracuna cija je
          vrsta sata = osnov
        */
        BEGIN
          SELECT obracunatiznos
            INTO l_iznos
            FROM TLDC_OBRACUNSTAVKA
           WHERE obst_vlasnik   = p_sat.obst_vlasnik
             AND obst_lokacija  = p_sat.obst_lokacija
             AND obst_godina    = p_sat.obst_godina
             AND obst_mesec     = p_sat.obst_mesec
             AND obst_broj      = p_sat.obst_broj
             AND obst_radnik    = p_sat.obst_radnik
             AND obst_vrstasata = r.osnov;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN NULL;
        END;
        l_iznos := f_zaokruzi(l_iznos * r.procenat / 100);
      ELSE
        l_iznos := 0;
      END IF;
      /*
        ostatak duga i ostalo za obustavu se izracunava u trigeru
      */
      UPDATE TLDC_KARTICAOBUSTAVA
         SET iznos = l_iznos
       WHERE CURRENT OF c;
      l_zbir := l_zbir + NVL(l_iznos, 0);
    END LOOP;

    UPDATE TLDC_OBRACUNSTAVKA
       SET obracunatiznos = l_zbir + nvl(iznosranije, 0)
     WHERE obst_vlasnik   = p_sat.obst_vlasnik
       AND obst_lokacija  = p_sat.obst_lokacija
       AND obst_godina    = p_sat.obst_godina
       AND obst_mesec     = p_sat.obst_mesec
       AND obst_broj      = p_sat.obst_broj
       AND obst_radnik    = p_sat.obst_radnik
       AND obst_vrstasata = p_sat.obst_vrstasata;

  END p_obr_99;

  PROCEDURE p_obustave_radnika(p_obracun IN TLDC_OBRACUN%ROWTYPE, p_rad_sifra IN TLDC_RADNIK.rad_sifra%TYPE, p_operater IN VARCHAR2) IS
  /*
    Procedura proverava da li se za zadati obracun rade i obustave. Ako se rade,
    onda za svaku aktivnu obustavu radnika proverava koliko puta u mesecu se
    vrsi ta obustava. Ako obustava u tekucem mesecu nije dovoljno puta obradjena
    dodaje se stavka u karticu obustava.
  */
    l_obustave NUMBER;
    l_brojobustava NUMBER;
    l_mesec_isplate DATE;
    r_karticaobustava TLDC_KARTICAOBUSTAVA%ROWTYPE;
  BEGIN
    /*
      Prvo obrisati sve obustave za zadati obracun
    */
    DELETE TLDC_KARTICAOBUSTAVA
     WHERE kob_radnik = p_rad_sifra
       AND obr_vlasnik  = p_obracun.obr_vlasnik
       AND obr_lokacija = p_obracun.obr_lokacija
       AND obr_godina   = p_obracun.obr_godina
       AND obr_mesec    = p_obracun.obr_mesec
       AND obr_broj     = p_obracun.obr_broj;

    SELECT obustave, TRUNC(datum_isplate, 'mm')
      INTO l_obustave, l_mesec_isplate
      FROM TLDC_OBRACUN
     WHERE obr_vlasnik  = p_obracun.obr_vlasnik
       AND obr_lokacija = p_obracun.obr_lokacija
       AND obr_godina   = p_obracun.obr_godina
       AND obr_mesec    = p_obracun.obr_mesec
       AND obr_broj     = p_obracun.obr_broj;

    /*
      Ako se za obracun rade obustave, onda popuni karticu obustava
    */
    IF l_obustave = 1 THEN
      r_karticaobustava.kob_radnik   := p_rad_sifra;
      r_karticaobustava.obr_vlasnik  := p_obracun.obr_vlasnik;
      r_karticaobustava.obr_lokacija := p_obracun.obr_lokacija;
      r_karticaobustava.obr_godina   := p_obracun.obr_godina;
      r_karticaobustava.obr_mesec    := p_obracun.obr_mesec;
      r_karticaobustava.obr_broj     := p_obracun.obr_broj;
      r_karticaobustava.operater     := p_operater;
      FOR r IN (SELECT obu_rbr, brojobustavaumesecu
                  FROM TLDC_OBUSTAVA
                 WHERE obu_radnik = p_rad_sifra
                   AND status = 'X') LOOP
        /*
          Da li je tekuca obustava obradjena dovoljno puta u tekucem mesecu?
        */
        SELECT COUNT(*)
          INTO l_brojobustava
          FROM TLDC_KARTICAOBUSTAVA kob, TLDC_OBRACUN obr
         WHERE kob.kob_radnik = p_rad_sifra
           AND kob.kob_rbr    = r.obu_rbr
           AND kob.obr_vlasnik  = obr.obr_vlasnik
           AND kob.obr_lokacija = obr.obr_lokacija
           AND kob.obr_godina   = obr.obr_godina
           AND kob.obr_mesec    = obr.obr_mesec
           AND kob.obr_broj     = obr.obr_broj
           AND TRUNC(obr.datum_isplate, 'mm') = l_mesec_isplate;
        IF l_brojobustava < r.brojobustavaumesecu THEN
          /*
            Treba dodati obustavu u karticu obustava
            iznos ce biti izracunat prilikom obracuna.
          */
          r_karticaobustava.kob_rbr := r.obu_rbr;
          SELECT NVL(MAX(kob_broj_rate), 0) + 1
            INTO r_karticaobustava.kob_broj_rate
            FROM TLDC_KARTICAOBUSTAVA
           WHERE kob_radnik = p_rad_sifra
             AND kob_rbr    = r.obu_rbr;
          INSERT INTO TLDC_KARTICAOBUSTAVA (
            kob_radnik,
            kob_rbr,
            kob_broj_rate,
            obr_vlasnik,
            obr_lokacija,
            obr_godina,
            obr_mesec,
            obr_broj,
            operater)
          VALUES (
            r_karticaobustava.kob_radnik,
            r_karticaobustava.kob_rbr,
            r_karticaobustava.kob_broj_rate,
            r_karticaobustava.obr_vlasnik,
            r_karticaobustava.obr_lokacija,
            r_karticaobustava.obr_godina,
            r_karticaobustava.obr_mesec,
            r_karticaobustava.obr_broj,
            r_karticaobustava.operater
          );
        END IF;
      END LOOP;
    END IF;
	COMMIT;
  END p_obustave_radnika;

  PROCEDURE p_obracun_radnika(p_obracun IN TLDC_OBRACUN%ROWTYPE, p_rad_sifra IN TLDC_RADNIK.rad_sifra%TYPE) IS
    l_nacinobracuna TLDC_VRSTASATA.nacinobracuna%TYPE;
  BEGIN
    p_kreiraj_sate_radnika(p_obracun, p_rad_sifra);
    FOR r_sati IN c_sati(p_obracun, p_rad_sifra) LOOP

      SELECT nacinobracuna
        INTO l_nacinobracuna
        FROM TLDC_VRSTASATA
       WHERE r_sati.obst_vrstasata = vrsat_sifra;
      dbms_output.put_line(l_nacinobracuna);
      IF l_nacinobracuna = '01' THEN
        p_obr_01(r_sati);
      ELSIF l_nacinobracuna = '02' THEN
        p_obr_02(r_sati);
      ELSIF l_nacinobracuna = '13' THEN
        p_obr_13(r_sati);
      ELSIF l_nacinobracuna = '62' THEN
        p_obr_62(r_sati);
      ELSIF l_nacinobracuna = '63' THEN
        p_obr_63(r_sati);
      ELSIF l_nacinobracuna = '64' THEN
        p_obr_64(r_sati);
      ELSIF l_nacinobracuna = '67' THEN
        p_obr_67(r_sati);
      ELSIF l_nacinobracuna = '70' THEN
        p_obr_70(r_sati);
      ELSIF l_nacinobracuna = '77' THEN
        p_obr_77(r_sati);
      ELSIF l_nacinobracuna = '99' THEN
        p_obr_99(r_sati);
      ELSE
        p_obr_00(r_sati);
      END IF;

      p_saberi_sate(r_sati);

    END LOOP;

    UPDATE TLDC_OBRACUNSTAVKA
       SET iznosrazlika = NVL(obracunatiznos, 0) - NVL(iznosranije, 0)
     WHERE obst_vlasnik  = p_obracun.obr_vlasnik
       AND obst_lokacija = p_obracun.obr_lokacija
       AND obst_godina   = p_obracun.obr_godina
       AND obst_mesec    = p_obracun.obr_mesec
       AND obst_broj     = p_obracun.obr_broj
       AND obst_radnik   = p_rad_sifra;

    COMMIT;

  END;

  PROCEDURE p_obracun(p_obracun IN TLDC_OBRACUN%ROWTYPE) IS
  BEGIN
    FOR r_radnik IN c_radnik(p_obracun.obr_vlasnik, p_obracun.obr_lokacija) LOOP
      p_obracun_radnika(p_obracun, r_radnik.rad_sifra);
    END LOOP;
  END p_obracun;

  PROCEDURE p_preth_obracun_radnika(p_obracun IN TLDC_OBRACUN%ROWTYPE, p_rad_sifra IN TLDC_RADNIK.rad_sifra%TYPE, p_operater IN VARCHAR2) IS
  BEGIN

    DELETE TLDC_OBRACUNSTAVKA
     WHERE obst_vlasnik  = p_obracun.obr_vlasnik
       AND obst_lokacija = p_obracun.obr_lokacija
       AND obst_godina   = p_obracun.obr_godina
       AND obst_mesec    = p_obracun.obr_mesec
       AND obst_broj     = p_obracun.obr_broj
       AND obst_radnik   = p_rad_sifra;

    /*
      Preuzmi sate iz prethodnog obracuna
    */
    INSERT INTO TLDC_OBRACUNSTAVKA
      (obst_vlasnik,
       obst_lokacija,
       obst_godina,
       obst_mesec,
       obst_broj,
       obst_radnik,
       obst_vrstasata,
       sati,
       bodova,
       fiksniiznos,
       ucinakradnika,
       iznosranije, -- U iznos ranije se stavlja obracunatiznos iz prethodnog obracuna
       mtr,
       radninalog,
       podbroj,
       operater)
    SELECT
       p_obracun.obr_vlasnik,
       p_obracun.obr_lokacija,
       p_obracun.obr_godina,
       p_obracun.obr_mesec,
       p_obracun.obr_broj,
       p_rad_sifra,
       obst_vrstasata,
       sati,
       bodova,
       fiksniiznos,
       ucinakradnika,
       obracunatiznos,
       mtr,
       radninalog,
       podbroj,
       p_operater
    FROM TLDC_OBRACUNSTAVKA
    WHERE obst_vlasnik   = p_obracun.obr_vlasnik
      AND obst_lokacija  = p_obracun.obr_lokacija
      AND obst_godina    = p_obracun.obr_godina
      AND obst_mesec     = p_obracun.obr_mesec
      AND obst_broj      = p_obracun.obr_broj - 1
      AND obst_radnik    = p_rad_sifra;

    p_obustave_radnika(p_obracun, p_rad_sifra, p_operater);

    COMMIT;

  END p_preth_obracun_radnika;

  PROCEDURE p_preth_obracun(p_obracun IN TLDC_OBRACUN%ROWTYPE, p_operater IN VARCHAR2) IS
  BEGIN
    FOR r_radnik IN c_radnik(p_obracun.obr_vlasnik, p_obracun.obr_lokacija) LOOP
      p_preth_obracun_radnika(p_obracun, r_radnik.rad_sifra, p_operater);
    END LOOP;
  END p_preth_obracun;

  procedure p_od_obrazac(p_obracun in tldc_obracun%rowtype) is
    cursor c_od is
	select ppod_id, aop
	  from tldc_ppod
	   for update;
	l_ukupno number;
	l_na_isplaceno number;
	l_na_najnizu number;
	l_na_najvisu number;
  begin

    for r_od in c_od loop
      select sum(decode(pv.kolona, 'obracunatiznos', round(os.obracunatiznos, 0),
                                   'iznosranije',    round(os.iznosranije, 0),
                                   'iznosrazlika',   round(os.iznosrazlika, 0)) * pv.znak),
             sum(decode(pv.kolona, 'obracunatiznos', round(os.obracunatiznos, 0),
                                   'iznosranije',    round(os.iznosranije, 0),
                                   'iznosrazlika',   round(os.iznosrazlika, 0)) *
                 decode(grupa.grupa, 0, 1, null) * -- grupa = 0 => doprinos na isplacenu zaradu
                 pv.znak),
             sum(decode(pv.kolona, 'obracunatiznos', round(os.obracunatiznos, 0),
                                   'iznosranije',    round(os.iznosranije, 0),
                                   'iznosrazlika',   round(os.iznosrazlika, 0)) *
                 decode(grupa.grupa, -1, 1, null) * -- grupa = -1 => doprinos na najnizu osnovicu
                 pv.znak),
             sum(decode(pv.kolona, 'obracunatiznos', round(os.obracunatiznos, 0),
                                   'iznosranije',    round(os.iznosranije, 0),
                                   'iznosrazlika',   round(os.iznosrazlika, 0)) *
                 decode(grupa.grupa, +1, 1, null) * -- grupa = +1 => doprinos na najvisu osnovicu
                 pv.znak)
        into l_ukupno, l_na_isplaceno, l_na_najnizu, l_na_najvisu
        from tldc_ppod_vrst pv, tldc_obracunstavka os,
		     (  select os.obst_radnik,
                   os.obst_vlasnik,
                   os.obst_lokacija,
                   os.obst_godina,
                   os.obst_mesec,
                   os.obst_broj,
                   sign(os.obracunatiznos - kv.iznos * os.sati / ob.planirano_sati) + sign(os.obracunatiznos - 5 * ob.prosek_republike) grupa
              from tldc_obracunstavka os, tldc_vrstasata vs, tldc_radnik ra, tldc_kvalifikacije kv, tldc_obracun ob
             where os.obst_vrstasata = vs.vrsat_sifra
               and vs.nacinobracuna = '67'
               and os.obst_radnik = ra.rad_sifra
               and ra.kvalifikacija = kv.kvl_sifra
               and os.obst_vlasnik = ob.obr_vlasnik
               and os.obst_lokacija = ob.obr_lokacija
               and os.obst_godina = ob.obr_godina
               and os.obst_mesec = ob.obr_mesec
               and os.obst_broj = ob.obr_broj
         ) grupa
	     where pv.ppod_id = r_od.ppod_id
         and pv.vrstasata = os.obst_vrstasata
         and os.obst_vlasnik  = p_obracun.obr_vlasnik
         and (p_obracun.obr_lokacija is null or os.obst_lokacija = p_obracun.obr_lokacija)
         and os.obst_godina   = p_obracun.obr_godina
         and os.obst_mesec    = p_obracun.obr_mesec
         and os.obst_broj     = p_obracun.obr_broj
         and os.obst_vlasnik  = grupa.obst_vlasnik
         and os.obst_lokacija = grupa.obst_lokacija
         and os.obst_godina   = grupa.obst_godina
         and os.obst_mesec    = grupa.obst_mesec
         and os.obst_broj     = grupa.obst_broj
         and os.obst_radnik   = grupa.obst_radnik;

    update tldc_ppod
       set ukupno = l_ukupno,
           na_isplaceno = l_na_isplaceno,
           na_najnizu = l_na_najnizu,
           na_najvisu = l_na_najvisu
     where current of c_od;

	end loop;

    /*
      Broj zaposlenih ide u AOP 02
    */
    select sum(ukupno), sum(na_isplaceno), sum(najniza), sum(najvisa)
      into l_ukupno,    l_na_isplaceno,    l_na_najnizu, l_na_najvisu
      from (
        select 1 ukupno,
               decode(os.obracunatiznos, kv.iznos * os.sati / ob.planirano_sati, null, 5 * ob.prosek_republike, null, 1) na_isplaceno,
               decode(os.obracunatiznos, kv.iznos * os.sati / ob.planirano_sati, 1, null) najniza,
               decode(os.obracunatiznos, 5 * ob.prosek_republike, 1, null) najvisa
          from tldc_obracunstavka os, tldc_vrstasata vs, tldc_radnik ra, tldc_kvalifikacije kv, tldc_obracun ob
         where os.obst_vrstasata = vs.vrsat_sifra
           and vs.nacinobracuna = '67'
           and os.obst_radnik = ra.rad_sifra
           and ra.status = 1
           and ra.kvalifikacija = kv.kvl_sifra
           and os.obst_vlasnik  = ob.obr_vlasnik
           and os.obst_lokacija = ob.obr_lokacija
           and os.obst_godina   = ob.obr_godina
           and os.obst_mesec    = ob.obr_mesec
           and os.obst_broj     = ob.obr_broj
           and os.obst_vlasnik  = p_obracun.obr_vlasnik
           and (p_obracun.obr_lokacija is null or os.obst_lokacija = p_obracun.obr_lokacija)
           and os.obst_godina   = p_obracun.obr_godina
           and os.obst_mesec    = p_obracun.obr_mesec
           and os.obst_broj     = p_obracun.obr_broj
      );

    update tldc_ppod
       set ukupno = l_ukupno,
           na_isplaceno = l_na_isplaceno,
           na_najnizu = l_na_najnizu,
           na_najvisu = l_na_najvisu
     where aop = '02';

	commit;
  end p_od_obrazac;

END Pk_Ldc;
/

