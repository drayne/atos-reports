create PROCEDURE KNJIZENJE_LOGGING
( p_anl IN anlanl%rowtype
) AS 
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  	insert into ANLANL_LOGGING (anl_vsdok,
											anl_nalog,
											anl_stavka,
											anl_radnja,
											anl_vlasnik,
											datdok,
											dev_duguje,
											dev_potrazuje,
											komitent,
											datknj,
											datumobrade,
											sifoperat,
											pol_brpol,
											konto,
											datnal,
											valuta,
											opis,
											jmbg,
											rj,
											REZNUM_1,
											REZNUM_4)
							values (p_anl.anl_vsdok,
											p_anl.anl_nalog,
											p_anl.anl_stavka,
											p_anl.anl_radnja,
											p_anl.anl_vlasnik,
											p_anl.datdok,
											p_anl.dev_duguje,
											p_anl.dev_potrazuje,
											p_anl.komitent,
											p_anl.datknj,
											p_anl.datumobrade,
											p_anl.sifoperat,
											p_anl.pol_brpol,
											p_anl.konto,
											p_anl.datnal,
											p_anl.valuta,
											p_anl.opis,
											p_anl.jmbg,
											p_anl.rj,
											p_anl.REZNUM_1,
											p_anl.REZNUM_4);
  COMMIT;
EXCEPTION WHEN OTHERS THEN
  NULL;
END KNJIZENJE_LOGGING;


/

