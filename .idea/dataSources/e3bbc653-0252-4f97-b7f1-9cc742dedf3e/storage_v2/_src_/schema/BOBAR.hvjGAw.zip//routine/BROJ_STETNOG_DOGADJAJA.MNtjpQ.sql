create FUNCTION BROJ_STETNOG_DOGADJAJA (p_id number) RETURN number AS 
r_return number:=0;
BEGIN
  select case when count(kao.prijstet_id) = 0 then 1 else count(kao.prijstet_id) end into r_return 
  from knjigastao kao 
  where kao.prijstet_id<=p_id and trim(kao.zapisnikmupa) 
  in (select trim(kao1.zapisnikmupa) from knjigastao kao1 where kao1.prijstet_id=p_id and kao1.zapisnikmupa is not null);
  return r_return;
END BROJ_STETNOG_DOGADJAJA;

/

