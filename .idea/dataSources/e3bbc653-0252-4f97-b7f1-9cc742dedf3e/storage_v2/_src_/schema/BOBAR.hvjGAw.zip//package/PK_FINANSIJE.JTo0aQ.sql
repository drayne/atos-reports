create PACKAGE PK_FINANSIJE AS 
  /* p_nivo - Na kom nivou se vrši zatvaranje ( 'D' - dokument
                                                'K' - komitent ) */      
  function automatsko_zatvaranje_stavki ( p_vlasnik number,
                                          p_radnja number,
                                          p_datum_od date, 
                                          p_datum_do date, 
                                          p_nivo varchar2 default 'D' ) return number; 

END PK_FINANSIJE;

/

