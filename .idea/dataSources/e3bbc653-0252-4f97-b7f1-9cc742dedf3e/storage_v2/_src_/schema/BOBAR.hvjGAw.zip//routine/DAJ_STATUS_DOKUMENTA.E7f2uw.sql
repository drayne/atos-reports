create FUNCTION DAJ_STATUS_DOKUMENTA ( p_broj_dok number, p_vsdok number ) RETURN NUMBER AS
  l_status number;
BEGIN
  select str.svsprom
    into l_status
    from stroga str
   where str.id = ( select max (id) from stroga where str_vsdok = p_vsdok and str_brojdok = p_broj_dok);
  RETURN l_status;
EXCEPTION 
  WHEN NO_DATA_FOUND THEN RETURN 0;
  WHEN OTHERS THEN RETURN -1;
END DAJ_STATUS_DOKUMENTA;

/

