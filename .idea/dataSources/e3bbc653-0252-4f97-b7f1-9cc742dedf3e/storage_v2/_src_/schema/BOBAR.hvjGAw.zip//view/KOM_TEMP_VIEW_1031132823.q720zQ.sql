create view KOM_TEMP_VIEW_1031132823 as
  select k.kom_sifra, k.naziv, m.mes_sifra||' '|| m.mesto as mesto, k.adresa, k.delat delatnost, to_char(m.mes_sifra)||' '||m.mesto as adresa1, 0 donos_dug, 0 donos_pot from komitent k, mesto m, vrstasvoj v where k.kom_sifra between 119295 and 119295 and k.pttm = m.mes_sifra and k.vrstasvojine = v.vrs_sifra(+) and v.VRS_SIFRA = 99 and k.kom_sifra in ( select komitent from anlanl where komitent between 119295 and 119295 and anl_vlasnik between 1 and 1 and anl_radnja between 2 and 2 and anl_vsdok not in (300) and trunc(datnal) between to_date('01.01.14') and to_date('31.10.14') and konto between '46420' and '46420')

/

