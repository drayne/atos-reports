create PACKAGE "PK_EL_NALOG" IS

  function formiraj_el_nalog ( p_el_nal_id number ) return number;
END;


/

