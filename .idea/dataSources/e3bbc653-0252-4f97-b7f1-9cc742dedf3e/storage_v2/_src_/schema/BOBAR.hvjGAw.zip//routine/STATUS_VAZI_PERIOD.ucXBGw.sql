create FUNCTION       STATUS_VAZI_PERIOD (pid number,status_od number, status_do number, dat_stat_od date, dat_stat_do date) RETURN number AS 
BEGIN
  for red in (
    select provera.STA_DATUM_OD, provera.STA_DATUM_DO
    from
    (select ss.*,
    (select SS.STA_DATUM_OD
    from statstet ss
    where SS.PRIJSTET_ID = pid
    and SS.STA_REDNIBROJ =  
    (
    select SS.STA_REDNIBROJ
    from statstet ss
    where SS.PRIJSTET_ID = pid
    and SS.STATUS_STETE between status_od and status_do
    ) +1)  as STA_DATUM_DO
    from statstet ss
    where SS.PRIJSTET_ID = pid
    and SS.STATUS_STETE between status_od and status_do) provera
  ) loop 
  if dat_stat_od >= red.STA_DATUM_OD and dat_stat_do <= red.STA_DATUM_DO
  then 
    return 1;
  end if;
  end loop;

 return null;

END STATUS_VAZI_PERIOD;

/

