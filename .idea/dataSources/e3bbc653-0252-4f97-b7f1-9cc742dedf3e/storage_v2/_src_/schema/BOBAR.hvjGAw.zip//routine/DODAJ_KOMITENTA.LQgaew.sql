create PROCEDURE       "DODAJ_KOMITENTA" (p_jmbg in number default 0, p_nazivugov in varchar2, p_sifra_komitenta number, p_pttmug in number, p_adresa in varchar2, p_oj in number)  IS PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN
 
insert into komitent (kom_sifra, naziv, pttm, adresa, sifoperat, matbr, org, datumobrade) values(p_sifra_komitenta, p_nazivugov, p_pttmug, p_adresa, 'auto' , p_jmbg, p_oj, sysdate); COMMIT;
  
END;

/

