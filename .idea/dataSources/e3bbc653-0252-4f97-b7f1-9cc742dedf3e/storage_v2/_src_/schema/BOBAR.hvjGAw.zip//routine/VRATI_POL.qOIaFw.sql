create FUNCTION       vrati_pol (p_vrijednost number) RETURN VARCHAR2 AS 
r_pol varchar2(20);
BEGIN
  select vrijednost 
  into r_pol 
  from sifarnik 
  where parametar =  'POL'
  and vrijednost_id=p_vrijednost;
  return r_pol;
 exception
        when NO_DATA_FOUND    then return '';     
  
END;

/

