create PROCEDURE       "DSE_LOOP" (p_vsdok integer, p_broj_od integer, p_broj_do integer) AS 
BEGIN
  FOR j IN p_broj_od .. p_broj_do
  LOOP
    insert into dse_izuzetci ( vsdok ,brojdok, datum_unosa, operater_unosa) values
    (p_vsdok, j, sysdate, 'admin');
  END LOOP;
  commit;
END DSE_LOOP;

/

