create trigger DATVAL_PLUS_14
  before insert
  on ANLANL
  for each row
  BEGIN
  if :new.anl_vsdok=317 and :new.dev_duguje=0 and :new.dev_potrazuje<>0 then
    :new.datval:=:new.datdok+14;
  end if;
END;


/

