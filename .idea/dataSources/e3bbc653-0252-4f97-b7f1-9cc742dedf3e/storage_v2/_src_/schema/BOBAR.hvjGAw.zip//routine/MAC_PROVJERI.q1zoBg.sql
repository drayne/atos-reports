create FUNCTION       MAC_PROVJERI (p_korisnik varchar2 ,p_host varchar2,p_mac varchar2) RETURN VARCHAR2 AS 
  ima number:=0;
BEGIN

  for red in (select * from operater where trim(korisnik)=trim(p_korisnik) and trim(mac)='1') loop
    return 'Nemate pravo da se logujete ni sa jednog računara!';
  end loop;

  for red in (select * from operater where trim(korisnik)=trim(p_korisnik) and trim(mac)='0') loop
    return '';
  end loop;

  select count(*) into ima 
  from operater o, mac m 
  where m.sifra=o.mac
  and length(trim(nvl(o.mac,'')))>1 
  and trim(o.korisnik)=trim(p_korisnik) and trim(m.mac)=trim(p_mac);
  if ima =0 then
    return 'Molimo Vas da pristupite na backup.atososiguranje.com!';
  else
    return '';
  end if;
END MAC_PROVJERI;

/

