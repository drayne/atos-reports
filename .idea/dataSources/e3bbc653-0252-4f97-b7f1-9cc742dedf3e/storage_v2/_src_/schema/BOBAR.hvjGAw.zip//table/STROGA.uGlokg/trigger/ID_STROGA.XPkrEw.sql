create trigger ID_STROGA
  before insert
  on STROGA
  for each row
  begin
 select stroga_seq.nextval into :new.id from dual;
end;



/

