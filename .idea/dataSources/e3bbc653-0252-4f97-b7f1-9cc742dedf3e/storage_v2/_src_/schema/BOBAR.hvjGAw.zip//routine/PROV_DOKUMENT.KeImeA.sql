create FUNCTION          "PROV_DOKUMENT"   ( vrsta_dok  in  number,
                         broj_dok   in  varchar2,
                         vraca_zast out number,
                         vraca_oj   out number )
      RETURN number IS

  vrati 		number;
  vrstaprom number;
  zastupnik number;
  RAZDUZUJE number;
  org_jed 	number;
  broj 			number;

BEGIN

	vrati  := null;

  select str.svsprom,
         str.mbrzastupprima,
         zas.oj,
         ZAS.RAZDUZUJE         
    into vrstaprom,
         zastupnik,
         org_jed,
         RAZDUZUJE
    from stroga str,
         zastup zas
   where str.id             = (select max (id) from stroga where str_vsdok = vrsta_dok and str_brojdok = broj_dok)
     and str.mbrzastupprima = zas.zas_sifra;
/*
  if razduzuje = 1 then
  	 vraca_zast := zastupnik;	
  	 vraca_oj   := org_jed;
  	 vrati      := 5;
*/ 	     
  if vrstaprom in ( 1, 11 ) then
  	 if razduzuje = 1 then
  	    vraca_zast := zastupnik;	
  	    vraca_oj   := org_jed;
  	    vrati      := 5;
  	 else
  	    vraca_zast := zastupnik;
  	    vraca_oj   := org_jed;
  	    vrati      := 0;
  	 end if;
  elsif vrstaprom in ( 21, 23 ) then
  	 vraca_zast := zastupnik;	
  	 vraca_oj   := org_jed;
  	 vrati      := 2;
  elsif vrstaprom in ( 22, 24, 25 ) then
     select count(*)
       into broj
       from stroga
      where str_vsdok   = vrsta_dok and
            str_brojdok = broj_dok  and
            svsprom    in ( 21, 23 );
     if broj > 0 then
  	    vraca_zast := zastupnik;	
  	    vraca_oj   := org_jed;
  	    vrati      := 3;
     else
  	    vraca_zast := zastupnik;
  	    vraca_oj   := org_jed;
  	    vrati      := 4;
     end if;
  end if;

  return vrati;

exception

  when no_data_found then
	 	 vraca_zast := 0;
  	 vraca_oj   := 0;
  	 vrati      := 1;
     return vrati;

END;

/

