create FUNCTION vrati_vros_steta ( vrsta_stete VRSTA_STETE.VS_SIFRA%type ) RETURN number IS
rvros number;
BEGIN
  SELECT v.vros
  INTO rvros
  FROM vrsta_stete v
  WHERE vrsta_stete = v.VS_SIFRA;
  
  return rvros;
END;

/

