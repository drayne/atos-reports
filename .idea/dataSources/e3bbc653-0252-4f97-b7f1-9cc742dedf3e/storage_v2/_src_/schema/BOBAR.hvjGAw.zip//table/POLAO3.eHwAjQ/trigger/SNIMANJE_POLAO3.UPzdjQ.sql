create trigger SNIMANJE_POLAO3
  before insert or update
  on POLAO3
  for each row
  begin
  -- Zbog AZORS-a
  update polisa set azors_slanje_id=null where pol_brpol=:new.ao3_brpol and vsdok = :new.vsdok;
end;


/

