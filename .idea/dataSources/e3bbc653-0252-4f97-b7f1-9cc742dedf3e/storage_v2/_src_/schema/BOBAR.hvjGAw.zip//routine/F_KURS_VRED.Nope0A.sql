create function f_kurs_vred(
  p_datum      in date,
  p_vrkursa    in kurs.vrsta%type,
  p_valuta     in kurs.valuta%type
) return number as
  l_kurs number default 1.0;
begin
    select kurs3/za
      into l_kurs
      from kurs
     where datum = (select max(datum)
                      from kurs
                     where trunc(datum) <= trunc(p_datum)
                       and vrsta  = p_vrkursa
                       and valuta = p_valuta)
       and vrsta  = p_vrkursa
       and valuta = p_valuta;
  return l_kurs;
exception
  when others then return 1.0;
end;


/

