create trigger LIK_LISTOVI_STETE_BI
  before insert
  on LIK_LISTOVI_STETE
  for each row
  BEGIN
  if :new.id is null then
    select lik_list_ste_seq.nextval into :new.id from dual;
  end if;
END;


/

