create trigger SNIMANJE_PRIJSTET
  before insert or update
  on PRIJSTET
  for each row
  BEGIN
  -- Zbog AZORS-a 
  if :old.azors_slanje_id is not null then
    :new.azors_slanje_id:=null;
  end if;
END;


/

