create function broj_naloga ( p_vlasnik number,p_radnja number,p_vsdok number,p_datum_naloga date ) return number as
  nalog number:=0;
BEGIN
  		select nvl ( max ( nal_nalog ), to_char ( p_datum_naloga, 'rr' ) * 10000 ) + 1
			    into nalog
			    from nalog
			   where nal_vlasnik = p_vlasnik and
			   			 nal_radnja = p_radnja and
			   			 nal_vsdok = p_vsdok and
			   			 to_char ( datnal, 'rrrr' ) = to_char ( p_datum_naloga, 'rrrr' );
    return nalog;
END broj_naloga;

/

