create procedure p_aopizvestaj is
/******************************************************************************
   NAME:       p_aopizvestaj
   PURPOSE:    Punjenje tabele AOPIZVESTAJ na osnovu tabela: AOP, AOPAOP,
               AOPKONTO, KONTO, KONSOLIDOVANI_KONTO i KONS_KONTO_VEZA.
               Tabela AOPIZVESTAJ sadrzi tacno koja AOP oznaka sadrzi koji
               konto, i da li je on bruto ili neto i da li se sabira ili
               oduzima. Na osnovu nje se kasnije prave izvestaji bilans stanja
               i bilans uspeha

   REVISIONS:
   Ver        Date        Author            Description
   ---------  ----------  ----------------  -----------------------------------
   1.0        06.02.2004  Branko Vukasovic  1. Created this procedure.

******************************************************************************/
  procedure p_popuni_aop (p_oj          in number,
                          p_vlasnik_aop in number,
                          p_tekuci_aop  in number,
                          p_znak        in number) is
  begin
    /*
      Prvo vlasniku dodaj konta koja direktno pripadaju tekucoj AOP sifri
    */
    if p_oj = 0 then
      /*
        U tabeli AOPKONTO se nalazi sifra konsolidovanog konta pa pravu
        sifru konta i org. jed. treba uzimati iz tabele KONS_KONTO_VEZA
      */
     insert into aopizvestaj
       (aop_oj, aop_oznaka, kon_oj, kon_sifra, vrsta, znak)
     select p_oj, p_vlasnik_aop, v.konto_oj, v.konto_sifra, a.vrsta, p_znak*a.znak
       from aopkonto a, kons_konto_veza v
      where a.konto = v.konsol_sifra
        and a.oj = p_oj
        and a.aop_oznaka = p_tekuci_aop;
    else
      /*
        Iz tabele AOPKONTO se direktno preuzimaju sifra i org.jed. konta
      */
     insert into aopizvestaj
       (aop_oj, aop_oznaka, kon_oj, kon_sifra, vrsta, znak)
     select p_oj, p_vlasnik_aop, p_oj, konto, vrsta, znak*p_znak
       from aopkonto
      where oj = p_oj
        and aop_oznaka = p_tekuci_aop;
    end if;

    /*
      Zatim vlasniku dodaj ona konta koja pripadaju AOP siframa koje
      se sadrze u tekucoj AOP sifri
    */
    for r_pod_aop in (select aop_pod, znak
                        from aopaop
                       where oj = p_oj
                         and aop_nad = p_tekuci_aop) loop
      p_popuni_aop(p_oj, p_vlasnik_aop, r_pod_aop.aop_pod, p_znak*r_pod_aop.znak);
    end loop;
  end;

begin

  delete aopizvestaj;

  for r_aop in (select oj, oznaka from aop order by 1, 2) loop
    p_popuni_aop(r_aop.oj, r_aop.oznaka, r_aop.oznaka, +1);
  end loop;

  commit;

end p_aopizvestaj;


/

