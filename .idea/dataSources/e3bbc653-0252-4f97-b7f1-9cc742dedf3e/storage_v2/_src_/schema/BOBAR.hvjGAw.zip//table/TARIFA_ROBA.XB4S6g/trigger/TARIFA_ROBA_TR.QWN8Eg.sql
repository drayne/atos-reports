create trigger TARIFA_ROBA_TR
  before insert
  on TARIFA_ROBA
  for each row
  begin
 select tarifa_roba_seq.nextval into :new.id from dual;
end;


/

