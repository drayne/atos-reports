create PROCEDURE       job_AUTO_AZUR_STATUSA_STETA AS 
	--obradjeno number := 0;
	l_status_stete number;
  --datum_od date:=to_char('01.01.1900','dd.mm.rrrr');
  --datum_do date:=sysdate;
  id_Stete number;
BEGIN
for i in (select distinct(vros) vros from semakont_stete
where vros in (0,1,15,200,250,300,350,380,400,800,900,940,200,890,850,860,870,500,950,510)) loop
	for red in (select max ( datdok ) datdok, prijstet.id as idd, iznos_prijavljen, sum ( dev_duguje ) iznos from bobar.prijstet, bobar.anlanl
   												 where datdok between '01-jan-90' and sysdate and
   												 			 anlanl.anl_radnja = 2 and
   												 		--	 nvl(dev_duguje, 0) != 0 and
   												 		 anl_vsdok not in (300) and 
   												 			 prst_vrsta in ( select vs_sifra
   												 			 									 from bobar.vrsta_stete
   												 			 									where vros = i.vros ) and
   															 pol_brpol is not null and
   															 konto in ( select osigdug 
   																			  		from bobar.semakont_stete 
   																			  	 where vros = i.vros ) and
   															 anlanl.pol_brpol = to_char ( prijstet.prst_brstete ) || '/' || substr ( to_char ( prijstet.prst_godina ), 3 ) and
   															 ( prijstet.status_stete between 60 and 69 or prijstet.status_stete = 81 )
   											group by prijstet.id, iznos_prijavljen				 
   											order by prijstet.id) loop
                        id_stete:=red.idd;
		if red.iznos > 0 then
			if red.iznos_prijavljen > red.iznos then
				update bobar.prijstet set status_stete = 81, datum_statusa = red.datdok, 
														datumobrade = red.datdok where id = red.idd;
			elsif red.iznos_prijavljen = red.iznos then
				update bobar.prijstet set status_stete = 80, datum_statusa = red.datdok, 
														datumobrade = red.datdok where id = red.idd;
			end if;	
		end if;
	end loop;
end loop;
commit; 
  exception when others then
    rollback;
    posalji_sms('066903255','Desio se problem kod izvršavanja procedure auto_azur_statusa_steta na steti '||id_Stete);
    dbms_output.put_line(SQLERRM);
    --commit;
END job_AUTO_AZUR_STATUSA_STETA;

/

