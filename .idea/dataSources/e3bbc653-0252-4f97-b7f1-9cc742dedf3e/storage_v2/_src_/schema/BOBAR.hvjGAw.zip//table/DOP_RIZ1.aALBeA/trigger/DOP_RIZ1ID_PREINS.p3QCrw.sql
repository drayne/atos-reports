create trigger DOP_RIZ1ID_PREINS
  before insert
  on DOP_RIZ1
  for each row
  begin
 select dop_riz1seq.nextval into :new.id from dual;
end;



/

