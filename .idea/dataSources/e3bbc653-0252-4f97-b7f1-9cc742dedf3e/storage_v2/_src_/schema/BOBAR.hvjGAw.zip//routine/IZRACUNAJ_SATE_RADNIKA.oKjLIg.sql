create FUNCTION IZRACUNAJ_SATE_RADNIKA (p_firma in number, radnik in number,godina in number ,mjesec in number) RETURN number AS 
 gm varchar(6):=godina||mjesec;
begin
for redi in (select datum_zapocinjanja,datum_otpusta 
from pl_radnici where (to_char(datum_zapocinjanja,'rrrrmm')=gm or to_char(datum_otpusta,'rrrrmm')=gm)
and id=radnik and firma=p_firma
) loop
 return 20;
end loop;
  return null;
END IZRACUNAJ_SATE_RADNIKA;

/

