create FUNCTION DAJ_POREZ (	p_vros 			in number,
                      p_datum			in date ) RETURN number AS
  l_procenat  number;
    				
BEGIN
	
  select porez
    into l_procenat
    from vros_rezdod
   where vros = p_vros and
         upper ( porez_ukljucen ) = 'D' and
         datum_porez = ( select max ( datum_porez ) 
                           from vros_rezdod
                          where vros = p_vros and
                                p_datum >= datum_porez and
                                upper ( porez_ukljucen ) = 'D' );

  return l_procenat;
exception 
  when no_data_found then
    return 0;
  when others then
    raise_application_error ( -20101, 'Greška prilikom određivanja poreza: ' || sqlerrm );
    return 0;
END DAJ_POREZ;


/

