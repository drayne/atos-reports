create PROCEDURE JOB_AUTOSEMBERIJA AS 
broj number :=0;
BEGIN
  select count(*) into broj from tep.sms_slanje where trim(lower(status))='send';
  if broj = 0 then
    for red in (select rownum,telefon_mobilni from
    (
    select distinct(mobilni(telefon_mobilni)) as telefon_mobilni 
    from polisa
    where mobilni(telefon_mobilni)<>'FALSE' and vsdok=1
    ) 
    where rownum<=1500 and telefon_mobilni not in (select trim(receiver) from tep.sms_slanje where vrsta=5)
    ) loop
  insert into tep.sms_slanje (RECEIVER,MSG,VRSTA,DATUM_SLANJA,operater) 
			values (red.telefon_mobilni,
			'I ovog ljeta „Grupacija Bobar“ misli na Vas.Za bezbjedan i ugodan godisnji odmor nabavite NOKIAN ljetne gume.Bobar autosemberija odobrava popust od 15% za NOKIAN ljetne gume uz vazecu polisu „Bobar Osiguranje“-a.Telefon 055/232-150',
			5,
			sysdate,
			'Autosemberija');
			commit;
    --posalji_sms(red.telefon_mobilni,);
    end loop;
  end if;
END JOB_AUTOSEMBERIJA;

/

