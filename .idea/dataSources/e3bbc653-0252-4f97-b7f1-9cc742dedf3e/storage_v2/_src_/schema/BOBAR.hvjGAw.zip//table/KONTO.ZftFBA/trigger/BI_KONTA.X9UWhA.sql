create trigger BI_KONTA
  before insert
  on KONTO
  for each row
  BEGIN
    IF :NEW.ps_dug IS NULL THEN
        :NEW.ps_dug := 0;
     END IF;
     IF :NEW.ps_pot IS NULL THEN
        :NEW.ps_pot := 0;
     END IF;
     IF :NEW.pr_dug IS NULL THEN
        :NEW.pr_dug := 0;
     END IF;
     IF :NEW.pr_pot IS NULL THEN
        :NEW.pr_pot := 0;
     END IF;
     BEGIN
       SELECT DECODE(SIGN(NVL(:NEW.pr_dug,0)-nvl(:NEW.pr_pot,0)),
                         1,NVL(:NEW.pr_dug,0)-nvl(:NEW.pr_pot,0),
                           0)
         INTO :NEW.sa_dug
         FROM sys.dual;
     EXCEPTION
        WHEN OTHERS THEN
          raise_application_error( -20030,
          'Nije azuriran saldo duguje konta!'||'-'||:NEW.kon_sifra);
     END;
     BEGIN
        SELECT DECODE(SIGN(NVL(:NEW.pr_dug,0)-nvl(:NEW.pr_pot,0)),
                         -1,NVL(:NEW.pr_pot,0)-nvl(:NEW.pr_dug,0),
                            0)
         INTO :NEW.sa_pot
         FROM sys.dual;
     EXCEPTION
        WHEN OTHERS THEN
          raise_application_error( -20031,
          'Nije azuriran saldo potrazuje konta!'||'-'||:NEW.kon_sifra);
     END;
  END;



/

