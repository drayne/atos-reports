create PaCKAGE BODY POLISA_PRENOS is 
Function c_date(u_str varchar2, u_fm varchar2) return date is 
i date; 
u varchar2(1022); 
begin 
greska := null; 
u :=ltrim(rtrim(u_str)); 
if (length(u) is null) then 
return null; 
end if; 
i := to_date(u_str,u_fm); 
return i; 
exception when others then 
greska := sqlerrm; 
logit('>'||u_str||'< ' || greska); 
return null; 
end; 
Function c_numb(u_str varchar2) return number is 
i number; 
u varchar2(1022); 
begin 
greska := null; 
u := ltrim(rtrim(u_str)); 
if ((length(u) is null) or (u = '.')) then 
return null; 
end if; 
i := to_number(u_str); 
return i; 
exception when others then 
greska := sqlerrm; 
logit('>'||u_str||'< ' || greska); 
return null; 
end; 
PROCEDURE logit(st number, en number) is 
begin 
utl_file.put_line(logfl,to_char(linija,'09999')||':'||substr(komad,st,en) || ':'); 
utl_file.put_line(logfl,greska); 
end; 
procedure logit(ms varchar2) is 
begin 
utl_file.put_line(logfl,to_char(linija,'09999')||':'|| ms); 
end; 
------------------------------------------------------------------------------------------------ 
PROCEDURE konvertuj (put_do_fajla varchar2) IS 
 pol polisa_radna%ROWTYPE; 
 iznos_premije polisa_radna.ukpremija%TYPE; 
 nastavi boolean := TRUE; 
 postoji number; 
 br_upisanih number; 
 postoje_obrisani number := 0; 
 za_brisanje boolean := false; 
 upisani_radna number := 0; 
 update_radna number := 0; 
 upisan number := 0; 
 polisa_upis boolean := FALSE; 
 polao2_upis boolean := FALSE; 
 polao3_upis boolean := FALSE; 
 rate_upis boolean := FALSE; 
 vraca_zastup number; 
 vraca_oj number; 
 prov_vraca number; 
 woja_brojac number; 
 CURSOR prenos IS select * from polisa_radna where upisano = 'N'; 
BEGIN 
 EOF:=FALSE; 
 dbms_output.enable(100000); 
 begin 
  ulaz := utl_file.fopen(put_do_fajla,'polisa1.dat','r'); 
  ulaz2 := utl_file.fopen(put_do_fajla,'polisa2.dat','r'); 
  logfl:= utl_file.fopen(put_do_fajla,'polisa.log','w'); 
  logit('otvoren.'); 
 exception when utl_file.invalid_path then 
  logit('FOPEN:invalid_path'); 
 when utl_file.invalid_mode then 
  logit('FOPEN:invalid_mode'); 
 when utl_file.invalid_operation then 
  logit('FOPEN:invalid_operation'); 
 end; 
 if (utl_file.is_open(ulaz)) then 
   logit('citam...'); 
   br_upisanih := 0; 
   loop 
     begin 
        utl_file.get_line(ulaz,komad); 
        utl_file.get_line(ulaz2,komad2); 
-- POLISA1 
                pol.AO2_BRPOL := ltrim(rtrim(substr(komad,1,11))); 
                pol.ZAMPOL := ltrim(rtrim(substr(komad,12,11))); 
                pol.OJ := ltrim(rtrim(substr(komad,23,13))); 
                pol.MBRZASTUP := ltrim(rtrim(substr(komad,36,13))); 
                pol.BROSK := ltrim(rtrim(substr(komad,49,11))); 
                pol.STATUS := ltrim(rtrim(substr(komad,60,2))); 
                pol.VROS := ltrim(rtrim(substr(komad,62,5))); 
                pol.TAR := 10; 
-- woja 15.12.2008 pocetak novog 1.deo
--              if pol.ao2_brpol < 3001 or 
--                   pol.ao2_brpol > 903000 then 
--                   pol.vsdok := 4; 
--              else 
--                   pol.vsdok := 1; 
--              end if; 
-- woja 15.12.2008 kraj novog 1.deo
--              pol.VSDOK := ltrim(rtrim(substr(komad,67,5))); 
        select pttm 
        into pol.pttm 
        from zastup  
        where zas_sifra = pol.mbrzastup; 
--              pol.PTTM := ltrim(rtrim(substr(komad,72,10))); 
                pol.JMBG := ltrim(rtrim(substr(komad,82,13))); 
                pol.NAZIVUGOV := ltrim(rtrim(substr(komad,95,50))); 
--              pol.PTTMUG := ltrim(rtrim(substr(komad,145,10))); 
                pol.PTTMUG := pol.pttm; 
                pol.ADRESA := ltrim(rtrim(substr(komad,155,35))); 
                pol.ZONR := ltrim(rtrim(substr(komad,190,2))); 
                pol.SEKTOR := ltrim(rtrim(substr(komad,192,1))); 
                pol.DATPOC := c_date ( ltrim(rtrim(substr(komad,193,8))), 'rrrrmmdd' ); 
                pol.DATIST := c_date ( ltrim(rtrim(substr(komad,201,8))), 'rrrrmmdd' ); 
                pol.MARKA := ltrim(rtrim(substr(komad,209,25))); 
                pol.TIP := ltrim(rtrim(substr(komad,234,25))); 
                pol.MODEL := ltrim(rtrim(substr(komad,259,25))); 
                pol.NAMENA := ltrim(rtrim(substr(komad,284,25))); 
                pol.SIFRAVOZILA := ltrim(rtrim(substr(komad,309,13))); 
                pol.REGBROJ := ltrim(rtrim(substr(komad,322,25))); 
                pol.BROJSASIJE := ltrim(rtrim(substr(komad,347,25))); 
                pol.BROJMOTORA := ltrim(rtrim(substr(komad,372,25))); 
                pol.GODPROIZV := ltrim(rtrim(substr(komad,397,4))); 
                pol.SNAGAKW := ltrim(rtrim(substr(komad,401,5))); 
                pol.ZAPREMINACCM := ltrim(rtrim(substr(komad,406,5))); 
                pol.NOSIVOSTKG := ltrim(rtrim(substr(komad,411,6))); 
                pol.BROJMESTA := ltrim(rtrim(substr(komad,417,3))); 
                pol.TARGRUPA := ltrim(rtrim(substr(komad,420,2)));
-- woja 15.12.2008 pocetak novog 2. deo
                if pol.TARGRUPA = 8  then 
                     pol.vsdok := 4; 
                else 
                     pol.vsdok := 1; 
                end if; 
-- woja 15.12.2008 kraj novog 2. deo
                pol.TARPODGRUPA := ltrim(rtrim(substr(komad,422,2))); 
                pol.BONUSMALUS := ltrim(rtrim(substr(komad,424,2)));
                pol.SIF_DOPLATAK := ltrim(rtrim(substr(komad,426,2)));
                pol.SIF_POPUST := ltrim(rtrim(substr(komad,428,2))); 
                pol.VOZ_AMAT_PROF := ltrim(rtrim(substr(komad,430,2))); 
                pol.BROJPUTNIKA := ltrim(rtrim(substr(komad,432,3))); 
                pol.DATDOK := c_date ( ltrim(rtrim(substr(komad,435,8))), 'rrrrmmdd' ); 
                pol.DATPRIP := c_date ( ltrim(rtrim(substr(komad,776,8))), 'rrrrmmdd' ); 
                pol.VRSTAPLAC := ltrim(rtrim(substr(komad,451,5))); 
                pol.NAP1 := ltrim(rtrim(substr(komad,456,80))); 
                pol.NAP2 := ltrim(rtrim(substr(komad,536,80))); 
                pol.NAP3 := ltrim(rtrim(substr(komad,616,80))); 
                pol.NAP4 := ltrim(rtrim(substr(komad,696,80))); 
                pol.DATUMOBRADE := c_date ( ltrim(rtrim(substr(komad,776,8))), 'rrrrmmdd' ); 
                pol.SIFOPERAT := ltrim(rtrim(substr(komad,784,8))); 
                pol.DATUM := c_date ( ltrim(rtrim(substr(komad,776,8))), 'rrrrmmdd' ); 
--              pol.DATUMFAKTURE := c_date ( ltrim(rtrim(substr(komad,776,8))), 'rrrrmmdd' ); 
                pol.DATUMFAKTURE := null; 
-- POLISA2 
                pol.SUMAAO := ltrim(rtrim(substr(komad2,12,17))); 
                pol.SUMASMRTI := ltrim(rtrim(substr(komad2,29,17))); 
                pol.SUMAINVALID := ltrim(rtrim(substr(komad2,46,17))); 
                pol.OSNPREMAO := ltrim(rtrim(substr(komad2,63,17))); 
                pol.IZNOSBONMAL := ltrim(rtrim(substr(komad2,80,17)));
                if pol.bonusmalus > 9 then
                	 pol.iznosbonmal := (-1) * pol.iznosbonmal;
                end if;
                pol.IZN_DOPLATAK := ltrim(rtrim(substr(komad2,97,17)));
                pol.IZN_POPUST := ltrim(rtrim(substr(komad2,114,17))); 
                if pol.izn_popust > 0 then
                  pol.izn_popust := (-1) * pol.izn_popust;
                end if;
                pol.UK_PREM_AO := ltrim(rtrim(substr(komad2,131,17))); 
                pol.PREMVOZAC := ltrim(rtrim(substr(komad2,148,17))); 
                pol.PREMPUTNICI := ltrim(rtrim(substr(komad2,165,17))); 
                pol.UK_PREM_AND := ltrim(rtrim(substr(komad2,182,17))); 
                pol.PREMIJA := ltrim(rtrim(substr(komad2,199,17))); 
                pol.UKPREMIJA := ltrim(rtrim(substr(komad2,199,17))); 
                pol.IZNODM := ltrim(rtrim(substr(komad2,216,17))); 
                pol.POREZ_AO := ltrim(rtrim(substr(komad2,233,17))); 
                pol.POREZ_AND := ltrim(rtrim(substr(komad2,233,17))); 
                pol.POREZ_UKUP := ltrim(rtrim(substr(komad2,233,17))); 
                pol.IZNPOREZ := ltrim(rtrim(substr(komad2,233,17))); 
                pol.BRRATA := ltrim(rtrim(substr(komad2,250,3))); 
                pol.RAT_BRSTAVKE1 := 1; 
                pol.VROS1 := 800; 
                pol.RAT_BRSTAVKE2 := 2; 
                pol.VROS2 := 850; 
                pol.IZNOS1 := ltrim(rtrim(substr(komad2,131,17))); 
                pol.IZNOS2 := ltrim(rtrim(substr(komad2,182,17))); 
                pol.STATUSRATE := 0; 
                pol.BRFAKTURE := NULL; 
          select count(*) into postoji from polisa_radna where ao2_brpol = pol.ao2_brpol; 
        if postoji = 0 then 
            insert into polisa_radna ( AO2_BRPOL, ZAMPOL, OJ, MBRZASTUP, 
                                 BROSK, STATUS, VROS, TAR, 
         VSDOK, PTTM, JMBG, NAZIVUGOV, PTTMUG, ADRESA, 
         ZONR, SEKTOR, DATPOC, DATIST, MARKA, 
         TIP, MODEL, NAMENA, SIFRAVOZILA, 
         REGBROJ, BROJSASIJE, BROJMOTORA, GODPROIZV, SNAGAKW, 
         ZAPREMINACCM, NOSIVOSTKG, BROJMESTA, TARGRUPA, TARPODGRUPA, 
         BONUSMALUS, VOZ_AMAT_PROF, BROJPUTNIKA, DATDOK, DATPRIP, 
         VRSTAPLAC, NAP1, NAP2, NAP3, 
         NAP4, DATUMOBRADE, SIFOPERAT, UPISANO, SUMAAO, SUMASMRTI, 
         SUMAINVALID, OSNPREMAO, IZNOSBONMAL, UK_PREM_AO, PREMVOZAC, 
         PREMPUTNICI, UK_PREM_AND, PREMIJA, UKPREMIJA, IZNODM, 
         POREZ_AO, POREZ_AND, POREZ_UKUP, IZNPOREZ, BRRATA, RAT_BRSTAVKE1, 
         VROS1, RAT_BRSTAVKE2, VROS2, IZNOS1, IZNOS2, STATUSRATE, 
         BRFAKTURE, DATUM, DATUMFAKTURE, DATUMRADA, BROJVRATA, SIF_DOPLATAK, SIF_POPUST, IZN_DOPLATAK, IZN_POPUST )
                                  values ( pol.AO2_BRPOL, pol.ZAMPOL, pol.OJ, pol.MBRZASTUP, 
                                 pol.BROSK, pol.STATUS, pol.VROS, pol.TAR, 
         pol.VSDOK, pol.PTTM, pol.JMBG, yu852lat ( pol.NAZIVUGOV ), pol.PTTMUG, yu852lat ( pol.ADRESA ), 
         pol.ZONR, pol.SEKTOR, pol.DATPOC, pol.DATIST, yu852lat ( pol.MARKA ), 
         yu852lat ( pol.TIP ), yu852lat ( pol.MODEL ), yu852lat ( pol.NAMENA ), pol.SIFRAVOZILA, 
         yu852lat ( pol.REGBROJ ), pol.BROJSASIJE, pol.BROJMOTORA, pol.GODPROIZV, pol.SNAGAKW, 
         pol.ZAPREMINACCM, pol.NOSIVOSTKG, pol.BROJMESTA,   pol.TARGRUPA,   pol.TARPODGRUPA, 
         pol.BONUSMALUS, pol.VOZ_AMAT_PROF, pol.BROJPUTNIKA, pol.DATDOK, pol.DATPRIP, 
         pol.VRSTAPLAC, yu852lat ( pol.NAP1 ), yu852lat ( pol.NAP2 ), yu852lat ( pol.NAP3 ), 
         yu852lat ( pol.NAP4 ), pol.DATUMOBRADE, yu852lat ( pol.SIFOPERAT ),    'N', pol.SUMAAO, pol.SUMASMRTI, 
         pol.SUMAINVALID,   pol.OSNPREMAO,  pol.IZNOSBONMAL, pol.UK_PREM_AO,    pol.PREMVOZAC, 
         pol.PREMPUTNICI,   pol.UK_PREM_AND,    pol.PREMIJA,    pol.UKPREMIJA,  pol.IZNODM, 
         pol.POREZ_AO, pol.POREZ_AND,   pol.POREZ_UKUP, pol.IZNPOREZ,   pol.BRRATA, pol.RAT_BRSTAVKE1, 
         pol.VROS1, pol.RAT_BRSTAVKE2,  pol.VROS2,  pol.IZNOS1, pol.IZNOS2, pol.STATUSRATE, 
         pol.BRFAKTURE, pol.DATUM, pol.DATUMFAKTURE, 
                 pol.DATUMRADA, 0 , pol.SIF_DOPLATAK, pol.SIF_POPUST, pol.IZN_DOPLATAK, pol.IZN_POPUST); 
          if sql%found then 
            upisan := upisan + 1; 
                upisani_radna := upisani_radna + 1; 
            end if; 
        elsif postoji > 0 then 
            update polisa_radna set AO2_BRPOL= pol.AO2_BRPOL, 
                                ZAMPOL= pol.ZAMPOL, 
                                OJ= pol.OJ, 
                    MBRZASTUP= pol.MBRZASTUP, 
                    BROSK= pol.BROSK, 
                    STATUS= pol.STATUS, 
                    VROS= pol.VROS, 
                    TAR= pol.TAR, 
                    VSDOK= pol.VSDOK, 
                    PTTM= pol.PTTM, 
                    JMBG= pol.JMBG, 
                    NAZIVUGOV= yu852lat ( pol.NAZIVUGOV ), 
                    PTTMUG= pol.PTTMUG, 
                    ADRESA= yu852lat ( pol.ADRESA ), 
                    ZONR= pol.ZONR, 
                    SEKTOR= pol.SEKTOR, 
                    DATPOC= pol.DATPOC, 
                    DATIST= pol.DATIST, 
                    MARKA= yu852lat ( pol.MARKA ), 
                    TIP= yu852lat ( pol.TIP ), 
                    MODEL= yu852lat ( pol.MODEL ), 
                    NAMENA= yu852lat ( pol.NAMENA ), 
                    SIFRAVOZILA=    pol.SIFRAVOZILA, 
                    REGBROJ= yu852lat ( pol.REGBROJ ), 
                    BROJSASIJE= pol.BROJSASIJE, 
                    BROJMOTORA= pol.BROJMOTORA, 
                    GODPROIZV= pol.GODPROIZV, 
                    SNAGAKW= pol.SNAGAKW, 
                    ZAPREMINACCM= pol.ZAPREMINACCM, 
                    NOSIVOSTKG= pol.NOSIVOSTKG, 
                    BROJMESTA= pol.BROJMESTA, 
                    TARGRUPA= pol.TARGRUPA, 
                    TARPODGRUPA= pol.TARPODGRUPA, 
                    BONUSMALUS= pol.BONUSMALUS, 
                    VOZ_AMAT_PROF= pol.VOZ_AMAT_PROF, 
                    BROJPUTNIKA=    pol.BROJPUTNIKA, 
                    DATDOK= pol.DATDOK, 
                    DATPRIP= pol.DATPRIP, 
                    VRSTAPLAC= pol.VRSTAPLAC, 
                    NAP1= pol.NAP1, 
                    NAP2= pol.NAP2, 
                    NAP3= pol.NAP3, 
                    NAP4= pol.NAP4, 
                    DATUMOBRADE= pol.DATUMOBRADE, 
                    SIFOPERAT= yu852lat ( pol.SIFOPERAT ), 
                    SUMAAO= pol.SUMAAO, 
                    SUMASMRTI= pol.SUMASMRTI, 
                    SUMAINVALID= pol.SUMAINVALID, 
                    OSNPREMAO= pol.OSNPREMAO, 
                    IZNOSBONMAL= pol.IZNOSBONMAL, 
                    UK_PREM_AO= pol.UK_PREM_AO, 
                    PREMVOZAC= pol.PREMVOZAC, 
                    PREMPUTNICI= pol.PREMPUTNICI, 
                    UK_PREM_AND= pol.UK_PREM_AND, 
                    UKPREMIJA= pol.UKPREMIJA, 
                    IZNODM= pol.IZNODM, 
                    POREZ_AO= pol.POREZ_AO, 
                    POREZ_AND= pol.POREZ_AND, 
                    POREZ_UKUP= pol.POREZ_UKUP, 
                    IZNPOREZ= pol.IZNPOREZ, 
                    BRRATA= pol.BRRATA, 
                    RAT_BRSTAVKE1= pol.RAT_BRSTAVKE1, 
                    VROS1= pol.VROS1, 
                    RAT_BRSTAVKE2= pol.RAT_BRSTAVKE2, 
                    VROS2= pol.VROS2, 
                    IZNOS1= pol.IZNOS1, 
                    IZNOS2= pol.IZNOS2, 
                    STATUSRATE= pol.STATUSRATE, 
                    BRFAKTURE= pol.BRFAKTURE, 
                    DATUM= pol.DATUM, 
                    DATUMFAKTURE= pol.DATUMFAKTURE, 
                    DATUMRADA= pol.DATUMRADA,
                    SIF_DOPLATAK = pol.SIF_DOPLATAK,
                    SIF_POPUST = pol.SIF_POPUST,
                    IZN_DOPLATAK = pol.IZN_DOPLATAK,
                    IZN_POPUST = pol.IZN_POPUST 
        where ao2_brpol = pol.ao2_brpol and 
                upisano = 'N'; 
            if sql%found then 
                  upisan := upisan + 1; 
              update_radna := update_radna + 1; 
            end if; 
        end if; 
                  commit; 
     exception 
        when no_data_found then EOF := TRUE; 
        when others then 
       logit ( sqlerrm || ' ' ||komad); 
     end; 
     exit when EOF; 
     end loop; 
 else 
   logit ( 'FGETLINE:Nije otvoren file' ); 
 end if; 
 commit; 
 utl_file.fclose ( ulaz ); 
 utl_file.fclose ( ulaz2 ); 
 for cur_rec in prenos loop 
 begin 
    Insert into polisa ( POL_BRPOL, OJ, BROSK, 
                             ZAMPOL, STATUS, VROS, TAR, VSDOK, 
                     PTTM, SEKTOR, DATPOC, DATIST, 
                             DATDOK, DATPRIP, PREMIJA, 
                 IZNPOREZ, UKPREMIJA, IZNODM, 
                             BRRATA, NAP1, NAP2, NAP3, 
                     NAP4, MBRZASTUP, VRSTAPLAC, 
                             JMBG, NAZIVUGOV, PTTMUG, 
                             ADRESA, DATUMOBRADE, SIFOPERAT ) 
                Values ( cur_rec.AO2_BRPOL, cur_rec.OJ, cur_rec.MBRZASTUP || to_char ( cur_rec.DATDOK, 'rrrrmmdd' ), 
                       cur_rec.ZAMPOL, cur_rec.STATUS, cur_rec.VROS, cur_rec.TAR, cur_rec.VSDOK, 
                 cur_rec.PTTM, cur_rec.SEKTOR, cur_rec.DATPOC, cur_rec.DATIST, 
                             cur_rec.DATDOK, cur_rec.DATPRIP, cur_rec.PREMIJA, 
                 cur_rec.IZNPOREZ, cur_rec.UKPREMIJA, cur_rec.IZNODM, 
                        cur_rec.BRRATA, cur_rec.NAP1, cur_rec.NAP2, cur_rec.NAP3, 
                 cur_rec.NAP4, cur_rec.MBRZASTUP, cur_rec.VRSTAPLAC, 
                             cur_rec.JMBG, cur_rec.NAZIVUGOV, cur_rec.PTTMUG, 
                 cur_rec.ADRESA, cur_rec.DATUMOBRADE, cur_rec.SIFOPERAT ); 
        polisa_upis := true; 
      exception when others then 
         if sqlcode <> -1 then 
           begin 
            select ukpremija into iznos_premije from polisa where pol_brpol = pol.AO2_BRPOL; 
            if iznos_premije <> pol.ukpremija then 
             logit ( sqlerrm || ' Polisa:' ||cur_rec.AO2_BRPOL || ' Zastupnik: ' || cur_rec.mbrzastup || ' - Promenjena premija !!!' ); 
            else 
             logit ( sqlerrm || ' Polisa:' ||cur_rec.AO2_BRPOL); 
            end if; 
           exception when others then null; 
           end; 
         else 
           za_brisanje := true; 
         end if; 
         polisa_upis := false; 
      end; 
    if polisa_upis then 
      begin 
    Insert into polao2 ( ao2_brpol, regbroj, sifravozila, 
                             marka, tip, model, 
                     brojsasije, brojmotora, snagakw, 
                             nosivostkg, 
                     brojmesta, zapreminaccm, godproizv, 
                             brojvrata, 
                     datumobrade, sifoperat, vsdok ) 
            values ( cur_rec.ao2_brpol, cur_rec.regbroj, cur_rec.sifravozila, 
                             cur_rec.marka, cur_rec.model, cur_rec.tip, 
                 cur_rec.brojsasije, cur_rec.brojmotora, cur_rec.snagakw, 
                             cur_rec.nosivostkg, 
                 cur_rec.brojmesta, cur_rec.zapreminaccm, cur_rec.godproizv, 
                             cur_rec.brojvrata, 
                 cur_rec.datumobrade, cur_rec.sifoperat, cur_rec.vsdok ); 
          polao2_upis := true; 
       exception when others then 
          logit ( sqlerrm || ' Polao2:' ||cur_rec.AO2_BRPOL); 
          polao2_upis := false; 
      end; 
    end if; 
    if polisa_upis and polao2_upis then 
      begin 
        insert into polao3 ( ao3_brpol, sumaao, zonr, 
                             targrupa, tarpodgrupa, osnpremao, 
                             bonusmalus, iznosbonmal, uk_prem_ao, 
                             sumasmrti, sumainvalid, 
                 brojputnika, voz_amat_prof, premvozac, 
                             premputnici, uk_prem_and, 
                 porez_ao, porez_and, porez_ukup, 
                             datumobrade, sifoperat, vsdok, sif_doplatka, izn_doplatka, sif_popusta, izn_popusta) 
                values ( cur_rec.ao2_brpol, cur_rec.sumaao, cur_rec.zonr, 
                 cur_rec.targrupa, cur_rec.tarpodgrupa, cur_rec.osnpremao, 
                 cur_rec.bonusmalus, cur_rec.iznosbonmal, cur_rec.uk_prem_ao, 
                 cur_rec.sumasmrti, cur_rec.sumainvalid, 
                 cur_rec.brojputnika, cur_rec.voz_amat_prof, cur_rec.premvozac, 
                 cur_rec.premputnici, cur_rec.uk_prem_and, 
                 cur_rec.porez_ao, cur_rec.porez_and, cur_rec.porez_ukup, 
                 cur_rec.datumobrade, cur_rec.sifoperat, cur_rec.vsdok , cur_rec.sif_doplatak, cur_rec.izn_doplatak, cur_rec.sif_popust, cur_rec.izn_popust); 
        polao3_upis := true; 
       exception when others then 
          logit ( sqlerrm || ' Polao3:' || cur_rec.AO2_BRPOL); 
          polao3_upis := false; 
      end; 
    end if; 
    if polisa_upis and polao2_upis and polao3_upis then 
    if cur_rec.iznos1 <> 0 then 
          begin 
            insert into rate ( rat_brpol, rat_brstavke, vros, 
                               datum, iznos, statusrate, 
                   brfakture, datumfakture, 
                               datumobrade, sifoperat, vsdok ) 
                  values ( cur_rec.ao2_brpol, cur_rec.rat_brstavke1, cur_rec.vros1, 
                               cur_rec.datum, cur_rec.iznos1, cur_rec.statusrate, 
                   cur_rec.brfakture, cur_rec.datumfakture, 
                               cur_rec.datumobrade, cur_rec.sifoperat, cur_rec.vsdok ); 
        rate_upis := true; 
        exception when others then 
          logit ( sqlerrm || ' Rate1:' ||cur_rec.AO2_BRPOL); 
          rate_upis := false; 
        end; 
 end if; 
     if cur_rec.iznos2 <> 0 and rate_upis then 
        begin 
          insert into rate ( rat_brpol, rat_brstavke, vros, 
                             datum, iznos, statusrate, 
                 brfakture, datumfakture, 
                             datumobrade, sifoperat, vsdok ) 
            values ( cur_rec.ao2_brpol, cur_rec.rat_brstavke2, cur_rec.vros2, 
                             cur_rec.datum, cur_rec.iznos2, cur_rec.statusrate, 
                 cur_rec.brfakture, cur_rec.datumfakture, 
                             cur_rec.datumobrade, cur_rec.sifoperat, cur_rec.vsdok ); 
        rate_upis := true; 
        exception when others then 
          logit ( sqlerrm || ' Rate2:' ||cur_rec.AO2_BRPOL); 
          rate_upis := false; 
        end; 
    end if; 
  end if; 
        if polao2_upis and polao3_upis and 
           polisa_upis and rate_upis then 
                    prov_vraca := prov_dokument ( cur_rec.vsdok, 
                                                  cur_rec.ao2_brpol, 
                                                  vraca_zastup, 
                                                  vraca_oj ); 
                    if cur_rec.mbrzastup = vraca_zastup and cur_rec.oj = vraca_oj then 
                     update polisa_radna set upisano = 'D' 
              where ao2_brpol = cur_rec.ao2_brpol; 
                   if prov_vraca = 0 then 
                      insert into stroga (str_vsdok, 
                                   str_brojdok, 
                                   str_datumpromene, 
                                   str_rednibroj, 
                                   mbrzastupprima, 
                                   mbrzastupdaje, 
                                   svsprom, 
                                   brojreversa, 
                                   opisreversa, 
                                   datumobrade, 
                                   sifoperat 
                                   ) 
                       values ( cur_rec.vsdok, 
                                cur_rec.ao2_brpol, 
                                  cur_rec.datdok, 
                                  4, 
                                  cur_rec.mbrzastup, 
                                  null, 
                                  21, 
                                  null, 
                                  null, 
                                  sysdate, 
                                  user 
                                  ); 
              end if; 
             commit; 
             br_upisanih := br_upisanih + 1; 
                    else 
                    logit( 'Nije saglasno sa strogom evidencijom! Zastupnik:' || to_char ( cur_rec.mbrzastup ) || 
               ' ; OJ:' || to_char ( cur_rec.oj ) || ' ' ||cur_rec.AO2_BRPOL); 
                        rollback; 
                    end if; 
        else 
            rollback; 
        end if; 
        if za_brisanje then 
          delete from polisa_radna 
            where ao2_brpol = cur_rec.ao2_brpol; 
          commit; 
          postoje_obrisani := postoje_obrisani + 1; 
          za_brisanje := false; 
        end if; 
 end loop; 
 delete from polisa_radna where upisano='D'; 
 commit; 
--finalize 
 logit( 'zatvoren.' ); 
 logit( 'Upisano novih slogova u radnu tabelu: ' || to_char( upisani_radna ) || ' zapisa!' ); 
 logit( 'Izmenjeno slogova u radnoj tabeli: ' || to_char ( update_radna ) || ' zapisa!' ); 
 logit( 'Upisano u tabelu polisa: ' || to_char ( br_upisanih ) || ' zapisa!' ); 
 logit( 'Nije upisano u tabelu polisa zato sto vec postoji: ' || to_char ( postoje_obrisani ) || ' zapisa!' ); 
utl_file.fclose(logfl); 
exception when others then 
 utl_file.fclose_all; 
 raise; 
END; 
END;
/

