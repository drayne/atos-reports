create trigger TAR2_1ID_PREINS
  before insert
  on TARIFA2_1
  for each row
  begin
 select tar2_1seq.nextval into :new.id from dual;
end;



/

