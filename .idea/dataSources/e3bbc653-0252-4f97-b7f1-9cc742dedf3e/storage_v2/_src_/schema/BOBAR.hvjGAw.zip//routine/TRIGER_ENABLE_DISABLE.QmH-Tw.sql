create PROCEDURE TRIGER_ENABLE_DISABLE (p_trigger_name IN varchar,p_enable_disable in varchar )
 AS 
BEGIN
  execute immediate 'ALTER TRIGGER '||p_trigger_name||' '||p_enable_disable;  
END TRIGER_ENABLE_DISABLE;

/

