create FUNCTION OBRACUN_PREMIJE_AO 
( p_datdok IN DATE
, p_zonriz IN NUMBER
, p_targru IN NUMBER
, p_limit IN NUMBER
, p_broj_dana IN NUMBER
, p_trajosig IN VARCHAR2
, p_tarpgr IN OUT NUMBER
, p_tarpgr_naziv OUT VARCHAR2
, p_brojmesta IN NUMBER DEFAULT 0 ) RETURN number AS

  l_premija     number;
  l_rezultat    number;
  proc_proskala number;
  w_proc        number;
  l_decimale    number;

BEGIN
  for red in (select to_number(vrijednost) as decim from parametri WHERE lower(naziv)='decimale') loop
    l_decimale:=red.decim;
  end loop;
  if p_targru not in ( 3, 5, 10, 11 ) then
    select cao_tarpgr, naziv, iznprem
      into p_tarpgr, p_tarpgr_naziv, l_premija
      from cenao
     where cao_datum = ( select max ( cao_datum )
                           from cenao	 											 
                          where cao_datum <= p_datdok and
                                cao_zonr 	= p_zonriz and
                                cao_targru = p_targru and
                                limit = ( select min ( limit ) 
                                            from cenao
                                           where cao_zonr 	= p_zonriz and
                                                 cao_targru = p_targru and
                                                 limit >= p_limit ) ) and
           cao_zonr 	= p_zonriz and
           cao_targru = p_targru and
           limit = ( select min ( limit ) 
                       from cenao
                      where cao_zonr 	= p_zonriz and
                            cao_targru = p_targru and
                            limit >= p_limit and
                            cao_datum = ( select max ( cao_datum )
                                            from cenao	 											 
                                           where cao_datum <= p_datdok and
                                                 cao_zonr 	= p_zonriz and
                                                 cao_targru = p_targru ));
  elsif p_targru in ( 3, 11 ) then
    select nvl ( iznprem, 0 ) + ( nvl ( premputnik, 0 ) * nvl ( p_brojmesta, 0 ) )
      into l_premija
      from cenao
     where cao_datum = ( select max ( cao_datum )
                           from cenao	 											 
                          where cao_datum <= p_datdok and
                                cao_zonr 	= p_zonriz and
                                cao_targru = p_targru and
                                cao_tarpgr = p_tarpgr ) and
           cao_zonr 	= p_zonriz and
           cao_targru = p_targru and
           cao_tarpgr = p_tarpgr;
  elsif p_targru in ( 5, 10 ) then
    select nvl ( iznprem, 0 )
      into l_premija
      from cenao
     where cao_datum = ( select max ( cao_datum )
                           from cenao	 											 
                          where cao_datum <= p_datdok and
                                cao_zonr 	= p_zonriz and
                                cao_targru = p_targru and
                                cao_tarpgr = p_tarpgr ) and
           cao_zonr 	= p_zonriz and
           cao_targru = p_targru and
           cao_tarpgr = p_tarpgr;
    
  end if;

  if upper ( p_trajosig ) like '%PROBA%' then	
 	  daj_proba_tab ( p_datdok, p_targru, p_broj_dana, p_zonriz, l_premija, l_rezultat );
    --l_premija := round ( l_premija, 2);
    l_premija := round ( l_premija, l_decimale);
  else
    if upper ( p_trajosig ) like '%PROSKALA%' then	
      daj_proskala ( p_datdok, 10, p_broj_dana, 800, proc_proskala, l_rezultat );
      --l_premija := round ( l_premija * proc_proskala / 100, 2);
      l_premija := round ( l_premija * proc_proskala / 100, l_decimale);
    else
      daj_prorata ( p_broj_dana, w_proc, l_rezultat );
      --l_premija := round ( l_premija * w_proc / 100, 2);
      l_premija := round ( l_premija * w_proc / 100, l_decimale);
    end if;
  end if;
  
  return l_premija;
exception when others then
 raise_application_error ( -20101, 'Greška prilikom obračuna premije.' || sqlerrm );
END OBRACUN_PREMIJE_AO;


/

