create PACKAGE BODY STORNOPOLISA   IS

Function c_date(u_str varchar2, u_fm varchar2) return date is
 i date;
 u varchar2(1022);
begin
 greska := null;
 u :=ltrim(rtrim(u_str));
 if (length(u) is null) then
  return null;
 end if;
 i := to_date(u_str,u_fm);
 return i;
 exception when others then
  greska := sqlerrm;
  logit('>'||u_str||'< ' || greska);
  return null;
 end;

Function c_numb(u_str varchar2) return number is
 i number;
 u varchar2(1022);
begin
 greska := null;
 u := ltrim(rtrim(u_str));
 if ((length(u) is null) or (u = '.')) then
  return null;
 end if;
 i := to_number(u_str);
 return i;
exception when others then
  greska := sqlerrm;
  logit('>'||u_str||'< ' || greska);
  return null;
end;

PROCEDURE logit(st number, en number) is
begin
 utl_file.put_line(logfl,to_char(linija,'09999')||':'||substr(komad,st,en) || ':');
 utl_file.put_line(logfl,greska);
end;

procedure logit(ms varchar2) is
begin
 utl_file.put_line(logfl,to_char(linija,'09999')||':'|| ms);
end;
------------------------------------------------------------------------------------------------
PROCEDURE storniraj (put_do_fajla varchar2) IS
 pol polisa%ROWTYPE;
 pol_2 polao2%ROWTYPE;
 pol_3 polao3%ROWTYPE;
 nastavi boolean := TRUE;
 br_upisanih number;
 nesto number;

BEGIN
 EOF:=FALSE;
 dbms_output.enable(1000000);

 begin
  ulaz := utl_file.fopen(put_do_fajla,'stornopol.dat','r');
  logfl:= utl_file.fopen(put_do_fajla,'stornopol.log','w');
  logit('otvoren.');
 exception when utl_file.invalid_path then
  logit('FOPEN:invalid_path');
 when utl_file.invalid_mode then
  logit('FOPEN:invalid_mode');
 when utl_file.invalid_operation then
  logit('FOPEN:invalid_operation');
 end;


  if (utl_file.is_open(ulaz)) then
   logit('citam...');
   br_upisanih := 0;
   loop
     begin
       utl_file.get_line(ulaz,komad);
       pol.pol_brpol := ltrim(rtrim(substr(komad,1,10)));
       pol.oj := ltrim(rtrim(substr(komad,11,3)));
       pol.mbrzastup := pol.oj || ltrim(rtrim(substr(komad,14,4)));
       pol.nazivugov := ltrim(rtrim(substr(komad,18,40)));
       pol.adresa := ltrim(rtrim(substr(komad,58,40)));
			 pol.datpoc := c_date ( ltrim(rtrim(substr(komad,98,8))), 'rrrrmmdd' );
			 pol.datist := c_date ( ltrim(rtrim(substr(komad,106,8))), 'rrrrmmdd' );
       pol_2.tip := ltrim(rtrim(substr(komad,114,12)));
       pol_2.marka := ltrim(rtrim(substr(komad,126,20)));
       pol_2.model := ltrim(rtrim(substr(komad,146,20)));
       pol_2.regbroj := ltrim(rtrim(substr(komad,166,10)));
       pol_2.brojsasije := ltrim(rtrim(substr(komad,176,20)));
       pol_2.godproizv := ltrim(rtrim(substr(komad,196,4)));
       pol_2.snagakw := ltrim(rtrim(substr(komad,200,3)));
       pol_2.zapreminaccm := ltrim(rtrim(substr(komad,203,5)));
       pol_2.nosivostkg := ltrim(rtrim(substr(komad,208,5)));
       pol_2.brojmesta := ltrim(rtrim(substr(komad,213,3)));
       pol_3.targrupa := ltrim(rtrim(substr(komad,216,2)));
       pol_3.tarpodgrupa := ltrim(rtrim(substr(komad,218,2)));
       pol_3.osnpremao := ltrim(rtrim(substr(komad,220,18)));
       pol_3.sumaao := ltrim(rtrim(substr(komad,238,18)));
       pol_3.uk_prem_ao := ltrim(rtrim(substr(komad,256,18)));
       pol_3.premvozac := ltrim(rtrim(substr(komad,274,18)));
       pol_3.premputnici := ltrim(rtrim(substr(komad,292,18)));
       pol.datdok := c_date ( ltrim(rtrim(substr(komad,328,8))), 'rrrrmmdd' );
       pol.ukpremija := ltrim(rtrim(substr(komad,336,18)));
       pol.datumobrade := c_date ( ltrim(rtrim(substr(komad,354,8))), 'rrrrmmdd' );
       pol.jmbg := ltrim(rtrim(substr(komad,362,13)));

			 pol_3.uk_prem_and := nvl ( pol_3.premvozac, 0 ) + nvl ( pol_3.premputnici, 0 );

			 pol.vros := 800;
			 if pol.pol_brpol < 900000 then
			 	pol.vsdok := 1;
			 else
			 	pol.vsdok := 4;
			 end if;

		select count(*) into nesto
			from polisa
		 where polisa.pol_brpol = pol.pol_brpol;

    if nesto > 0 then
	    update polisa set polisa.status = 3, datumobrade = sysdate, sifoperat = 'sasaprenos'
  	              where polisa.pol_brpol = pol.pol_brpol;

			insert into stroga ( str_vsdok, str_brojdok, str_datumpromene, str_rednibroj, mbrzastupprima,
													 svsprom, datumobrade, sifoperat, id )
									values ( pol.vsdok, pol.pol_brpol, pol.datumobrade, 5, pol.mbrzastup,
													 24, sysdate, 'sasaprenos', stroga_seq.nextval );

    else

    	insert into polisa ( pol_brpol, oj, mbrzastup, nazivugov, adresa, datpoc, datist,
    											 datdok, ukpremija, datumobrade, jmbg, sifoperat, vros, vsdok, status )
    							values ( pol.pol_brpol, pol.oj, pol.mbrzastup, pol.nazivugov, pol.adresa, pol.datpoc, pol.datist,
    											 pol.datdok, pol.ukpremija, sysdate, pol.jmbg, 'sasaprenos', pol.vros, pol.vsdok, 3 );

    	insert into polao2 ( ao2_brpol, tip, marka, model, regbroj, brojsasije, godproizv,
    											 snagakw, zapreminaccm, nosivostkg, brojmesta, datumobrade, sifoperat )
    							values ( pol.pol_brpol, pol_2.tip, pol_2.marka, pol_2.model, pol_2.regbroj, pol_2.brojsasije, pol_2.godproizv,
    											 pol_2.snagakw, pol_2.zapreminaccm, pol_2.nosivostkg, pol_2.brojmesta, sysdate, 'sasaprenos' );

    	insert into polao3 ( ao3_brpol, targrupa, tarpodgrupa, osnpremao, sumaao, uk_prem_ao, uk_prem_and,
    											 premvozac, premputnici, datumobrade, sifoperat )
    							values ( pol.pol_brpol, pol_3.targrupa, pol_3.tarpodgrupa, pol_3.osnpremao, pol_3.sumaao, pol_3.uk_prem_ao,
    											 pol_3.uk_prem_and, pol_3.premvozac, pol_3.premputnici, sysdate, 'sasaprenos' );

			insert into stroga ( str_vsdok, str_brojdok, str_datumpromene, str_rednibroj, mbrzastupprima,
													 svsprom, datumobrade, sifoperat, id )
									values ( pol.vsdok, pol.pol_brpol, pol.datumobrade, 5, pol.mbrzastup,
													 24, sysdate, 'sasaprenos', stroga_seq.nextval );

  	end if;

  	commit;
    br_upisanih := br_upisanih + 1;

/*    if br_upisanih = 63 then
      commit;
      br_upisanih := 0;
    end if;
*/
--    logit(greska || ' ' ||komad);

    exception when no_data_found then
			EOF := true;
			rollback;
    when others then
			rollback;
			greska := sqlerrm;
      logit(greska || ' ' || komad);
    end;
   	exit when EOF;
   end loop;
--  commit;
  else
   logit('FGETLINE:Nije otvoren file');
  end if;

--finalize
 utl_file.fclose(ulaz);
 logit ( 'Upisanop polisa ' || ' ' || br_upisanih );
 logit('zatvoren.');
-- logit('Insertovano: ' || to_char(br_upisanih) || ' zapisa!');
 utl_file.fclose(logfl);
exception when others then
 utl_file.fclose_all;
 raise;
END;
------------------------------------------------------------------------------------------------
 PROCEDURE za_voju_pol ( put_do_fajla varchar2 ) IS
 pol polisa%ROWTYPE;
 pol_2 polao2%ROWTYPE;
 pol_3 polao3%ROWTYPE;
 broj_polise polisa.pol_brpol%type; -- Broj polise
 broj_zk zelkarton.sifra%type; -- Broj zelenog kartona
 sifra_zastupnika polisa.mbrzastup%type; -- Šifra zastupnika
 zastupnik zastup.naziv%type; -- Naziv zastupnika
 status varchar2(20); -- Status polise ( storno ili ne )
 sifra_dokumenta polisa.vsdok%type; -- Šifra dokumenta
 naziv_dokumenta vrstadok.naziv%type; -- Naziv dokumenta
 datum_dokumenta polisa.datdok%type; -- Datum dokumenta
 datum_pripadnosti polisa.datprip%type; -- Datum pripadnosti
 broj_pol number := 0; -- koliko ima polisa sa tim brojem i tom vrstom dokumenta
 brojac1 number := 0; -- broj polisa sa neproknjiženim ratama
 brojac2 number := 0; -- broj polisa sa proknjiženim ratama
 brojac3 number := 0; -- broj polisa bez rata
 brojac4 number := 0; -- broj polisa koje smo sada označili kao stornirane u tabeli polisa
 brojac5 number := 0; -- broj polisa bez slogova u strogoj
 brojac6 number := 0; -- broj polisa koje već imaju slog storna u strogoj
 brojac7 number := 0; -- broj polisa za koje smo sada upisali slog storna u strogoj
 brojac8 number := 0; -- broj polisa koje su zadućene kod jednog zastupnika, a došao zahtev za storno od drugog zastupnika
 brojac11 number := 0; -- broj polisa koje smo sada upisali u tabelu polisa
 brojac12 number := 0; -- broj polisa koje nemaju slogove u strogoj
 brojac13 number := 0; -- broj polisa koje već imaju slog storna u strogoj
 brojac14 number := 0; -- broj polisa za koje smo sada upisali slog storna u strogoj
 brojac15 number := 0; -- broj polisa koje su zadućene kod jednog zastupnika, a došao zahtev za storno od drugog zastupnika
 kps_status number := 0; -- Da li su rate proknjižene ( kps_status > 0 znači da jesu )
 ima_storno number := 0; -- Da li je dokument do sada storniran ( ima_storno > 0 znači da jeste )
 sifra_promene stroga.svsprom%type; -- Šifra vrste promene u strogoj
 naziv_promene strgprom.naziv%type; -- Naziv vrste promene u strogoj
 zastupnik_prima stroga.mbrzastupprima%type; -- Šifra zastupnika koji je primio dokument po poslednoj promeni u strogoj
 ima_polisa boolean := true; -- Da li postoji traženi broj polise u evidenciji polisa
 ima_stroga boolean := true; -- Da li traženi broj polise postoji u strogoj evidenciji
 ima_zk boolean := true; -- Da li postoji traženi broj zelenog kartona u evidenciji zelenih kartona
 nastavi boolean := TRUE;
 br_slogova number;
 nesto number;
 zbir number;

BEGIN
 EOF:=FALSE;
 dbms_output.enable(1000000);

 begin
  ulaz := utl_file.fopen(put_do_fajla,'storpol.dat','r');
  logfl:= utl_file.fopen(put_do_fajla,'storpol.log','w');
  logit('otvoren.');
 exception when utl_file.invalid_path then
  logit('FOPEN:invalid_path');
 when utl_file.invalid_mode then
  logit('FOPEN:invalid_mode');
 when utl_file.invalid_operation then
  logit('FOPEN:invalid_operation');
 end;

  if (utl_file.is_open(ulaz)) then
   logit('citam...');
   br_slogova := 0;
   loop
     begin
       utl_file.get_line(ulaz,komad);

-- Početak za polise
       broj_polise := ltrim(rtrim(substr(komad,1,11)));
       zastupnik := ltrim(rtrim(substr(komad,36,13)));
       status := ltrim(rtrim(substr(komad,60,2)));

       pol.pol_brpol := ltrim(rtrim(substr(komad,1,11)));
       pol.oj := ltrim(rtrim(substr(komad,23,13)));
       pol.mbrzastup := ltrim(rtrim(substr(komad,36,13)));
			 pol.vros := 800;
			 if pol.pol_brpol < 900000 then
			 	 pol.vsdok := 1;
			 else
			 	 pol.vsdok := 4;
			 end if;
       pol.vrstaplac := 40;
       pol.tar := 10;
       pol.brrata := 1;
       pol.nap3 := 'STORNO';
       pol_3.zonr := 1;

       pol.nazivugov := ltrim(rtrim(substr(komad,95,50)));
       pol.adresa := ltrim(rtrim(substr(komad,155,35)));
       pol.pttm := ltrim(rtrim(substr(komad,72,10)));
       pol.pttmug := ltrim(rtrim(substr(komad,145,10)));
			 pol.datpoc := c_date ( ltrim(rtrim(substr(komad,193,8))), 'rrrrmmdd' );
			 pol.datist := c_date ( ltrim(rtrim(substr(komad,201,8))), 'rrrrmmdd' );
       pol.datdok := c_date ( ltrim(rtrim(substr(komad,435,8))), 'rrrrmmdd' );
       pol.ukpremija := ltrim(rtrim(substr(komad,979,17)));
       pol.datumobrade := c_date ( ltrim(rtrim(substr(komad,776,8))), 'rrrrmmdd' );
       pol.datprip := c_date ( ltrim(rtrim(substr(komad,443,8))), 'rrrrmmdd' );
       pol.jmbg := ltrim(rtrim(substr(komad,82,13)));
       pol.iznodm := ltrim(rtrim(substr(komad,996,17)));
       pol.nap1 := ltrim(rtrim(substr(komad,456,80)));

       pol_2.tip := ltrim(rtrim(substr(komad,234,25)));
       pol_2.marka := ltrim(rtrim(substr(komad,209,25)));
       pol_2.model := ltrim(rtrim(substr(komad,259,25)));
       pol_2.regbroj := ltrim(rtrim(substr(komad,322,25)));
       pol_2.brojsasije := ltrim(rtrim(substr(komad,347,25)));

       pol_3.targrupa := ltrim(rtrim(substr(komad,420,2)));
       pol_3.tarpodgrupa := ltrim(rtrim(substr(komad,422,2)));
       pol_3.uk_prem_ao := ltrim(rtrim(substr(komad,911,17)));
       pol_3.premvozac := ltrim(rtrim(substr(komad,928,17)));
       pol_3.premputnici := ltrim(rtrim(substr(komad,945,17)));
			 pol_3.uk_prem_and := nvl ( pol_3.premvozac, 0 ) + nvl ( pol_3.premputnici, 0 );
       pol_3.porez_ukup := ltrim(rtrim(substr(komad,1013,10)));

      ima_polisa := true;
      ima_stroga := true;

      select count(*)
      into broj_pol
      from polisa
      where vsdok = pol.vsdok and
            pol_brpol = broj_polise;

      if broj_pol != 1 then
        ima_polisa := false;
      end if;

      if ima_polisa then

        kps_status := 0;
        select count(*)
        into kps_status
        from rate
        where rat_brpol = broj_polise;

        if kps_status > 0 then

          kps_status := 0;
          select count (*)
          into kps_status
          from rate
          where rat_brpol = broj_polise and
                statusrate = 1;

          if kps_status = 0 then
            brojac1 := brojac1 + 1;
-- ww            logit ( 'Polisa broj: ' || broj_polise || ' ima neproknjižene stavke! ' );
          else
            brojac2 := brojac2 + 1;
            zbir := 0;
            select sum(nvl(dev_duguje, 0)) into zbir from anlanl
            where anl_radnja = 2 and 
                  anl_vlasnik = 1 and 
                  konto = '2012' and 
                  pol_brpol = broj_polise;            
            logit ( 'Polisa broj: ' || broj_polise || ' ' || ZASTUPNIK ||' ima proknjižene stavke, traži nalog, zaduženje = ' || zbir );
          end if;
        else
            brojac3 := brojac3 + 1;
-- ww          logit ( 'Polisa broj: ' || broj_polise || ' nema stavki! ' );
          kps_status := 99;
        end if;

-- ww        logit ( 'Polisa broj: ' || broj_polise || ' je sada označena kao stornirana! ' );
-- update polisu u tabelu polisa - stavi 2 u polje status (da je stornirana)
        update polisa set status = 2
        where polisa.pol_brpol = pol.pol_brpol and
              polisa.vsdok = pol.vsdok;
        update polisa set NAP3 = 'STORNO'
        where polisa.pol_brpol = pol.pol_brpol and
              polisa.vsdok = pol.vsdok;

            brojac4 := brojac4 + 1;

        ima_storno := 0;
        select count (*)
        into ima_storno
        from stroga
        where str_vsdok = pol.vsdok and
              str_brojdok = broj_polise;

        if ima_storno = 0 then
            brojac5 := brojac5 + 1;
-- ww          logit ( 'Polisa broj: ' || broj_polise || ' ne postoji u strogoj evidenciji! ' );

--  nista se ne radi, jer nema ni ulaza od stampara ni bilo sta u strogoj

        else
          ima_storno := 0;
          select count (*)
          into ima_storno
          from stroga
          where svsprom in ( 22, 24 ) and
                str_vsdok = pol.vsdok and
                str_brojdok = broj_polise;

          if ima_storno > 0 then
-- ww            logit ( 'Polisa broj: ' || broj_polise || ' je već stornirana u strogoj! ' );
            brojac6 := brojac6 + 1;

--  nista se ne radi jer je polisa vec stornirana u strogoj

          else
            select svsprom, mbrzastupprima, strgprom.naziv
            into sifra_promene, zastupnik_prima, naziv_promene
            from stroga, strgprom
            where id = ( select max ( id )
--            where str_rednibroj = ( select max ( str_rednibroj )
                                     from stroga
                                    where str_vsdok = pol.vsdok and
                                          str_brojdok = broj_polise ) and
                 str_vsdok = pol.vsdok and
                 str_brojdok = broj_polise and
                 svsp_sifra = svsprom;
            if zastupnik_prima = zastupnik then
-- ww              logit ( 'Polisu broj: ' || broj_polise || ' sada smo stornirali u strogoj' );
            brojac7 := brojac7 + 1;

--  napraviti storno stavku za strogu evidenciju
			insert into stroga ( str_vsdok, str_brojdok, str_datumpromene, str_rednibroj, mbrzastupprima,
													 svsprom, datumobrade, sifoperat, id )
									values ( pol.vsdok, pol.pol_brpol, pol.datumobrade, 5, pol.mbrzastup,
													 24, sysdate, 'ljilja', stroga_seq.nextval );

            else
              logit ( 'Polisom broj: ' || broj_polise || ' zadužen je zastupnik '|| zastupnik_prima || ' sa šifrom ' || sifra_promene || ' a stornira je zastupnik ' || zastupnik );
              brojac8 := brojac8 + 1;

-- nista se ne radi jer zastupnici nisu isti, samo obavestenje

            end if;
          end if;
        end if;
        else
-- ww          logit ( 'Polisa broj: ' || broj_polise || ' je sada upisana u tabelu polisa kao stornirana! ');
          brojac11 := brojac11 + 1;

-- upisi polisu u tabelu polisa         sa oznakom 2 (da je stornirana)

    	insert into polisa ( pol_brpol, oj, mbrzastup, nazivugov, adresa, datpoc, datist,
    											 datdok, ukpremija, datumobrade, jmbg, sifoperat, vros, vsdok, status,
    											 tar, iznodm, vrstaplac, datprip, nap1, nap3, brrata,
    											 pttmug, pttm, brosk )
    							values ( pol.pol_brpol, pol.oj, pol.mbrzastup, pol.nazivugov, pol.adresa, pol.datpoc, pol.datist,
    											 pol.datdok, pol.ukpremija, sysdate, pol.jmbg, 'ljilja', pol.vros, pol.vsdok, 2,
    											 pol.tar, pol.iznodm, pol.vrstaplac, pol.datprip, pol.nap1, pol.nap3, pol.brrata,
    											 pol.pttmug, pol.pttm, pol.mbrzastup || to_char ( pol.datdok, 'rrrrmmdd' ) );

    	insert into polao2 ( ao2_brpol, tip, marka, model, regbroj, brojsasije,
    											 datumobrade, sifoperat, vsdok )
    							values ( pol.pol_brpol, pol_2.tip, pol_2.marka, pol_2.model, pol_2.regbroj, pol_2.brojsasije,
    											 sysdate, 'ljilja', pol.vsdok );

    	insert into polao3 ( ao3_brpol, targrupa, tarpodgrupa, uk_prem_ao, uk_prem_and,
    	                     porez_ukup, zonr,
    											 premvozac, premputnici, datumobrade, sifoperat, vsdok )
    							values ( pol.pol_brpol, pol_3.targrupa, pol_3.tarpodgrupa, pol_3.uk_prem_ao, pol_3.uk_prem_and,
    							         pol_3.porez_ukup, pol_3.zonr,
    											 pol_3.premvozac, pol_3.premputnici, sysdate, 'ljilja', pol.vsdok );
        ima_storno := 0;
        select count (*)
        into ima_storno
        from stroga
        where str_vsdok = pol.vsdok and
              str_brojdok = broj_polise;

        if ima_storno = 0 then
-- ww          logit ( 'Polisa broj: ' || broj_polise || ' ne postoji u strogoj evidenciji! ' );
            brojac12 := brojac12 + 1;

--  nista se ne radi, jer nema ni ulaza od stampara ni bilo sta u strogoj

        else
          ima_storno := 0;
          select count (*)
          into ima_storno
          from stroga
          where svsprom in ( 22, 24 ) and
                str_vsdok = pol.vsdok and
                str_brojdok = broj_polise;

          if ima_storno > 0 then
-- ww            logit ( 'Polisa broj: ' || broj_polise || ' je već stornirana u strogoj! ' );
            brojac13 := brojac13 + 1;

--  nista se ne radi jer je polisa vec stornirana u strogoj

          else
            select svsprom, mbrzastupprima, strgprom.naziv
            into sifra_promene, zastupnik_prima, naziv_promene
            from stroga, strgprom
            where id = ( select max ( id )
--            where str_rednibroj = ( select max ( str_rednibroj )
                                     from stroga
                                    where str_vsdok = pol.vsdok and
                                          str_brojdok = broj_polise ) and
                 str_vsdok = pol.vsdok and
                 str_brojdok = broj_polise and
                 svsp_sifra = svsprom;
            if zastupnik_prima = zastupnik then
-- ww            	 logit ( 'Polisu broj: ' || broj_polise || ' sada smo stornirali u strogoj! ' );
            brojac14 := brojac14 + 1;

--  napraviti storno stavku za strogu evidenciju
			insert into stroga ( str_vsdok, str_brojdok, str_datumpromene, str_rednibroj, mbrzastupprima,
													 svsprom, datumobrade, sifoperat, id )
									values ( pol.vsdok, pol.pol_brpol, pol.datumobrade, 5, pol.mbrzastup,
													 24, sysdate, 'ljilja', stroga_seq.nextval );

            else
              logit ( 'Polisom broj: ' || broj_polise || ' zadužen je zastupnik '|| zastupnik_prima || ' sa šifrom ' || sifra_promene || ' a stornira je zastupnik ' || zastupnik );
            brojac15 := brojac15 + 1;

-- nista se ne radi jer zastupnici nisu isti, samo obavestenje

            end if;
          end if;
        end if;
      end if;

-- Kraj za polise

    br_slogova := br_slogova + 1;

    exception when no_data_found then
          			EOF := true;
              when others then
                br_slogova := br_slogova + 1;
			          greska := sqlerrm;
                logit(greska || ' ' || komad);
    end;
   	exit when EOF;
   end loop;
  else
   logit('FGETLINE:Nije otvoren file');
  end if;

  commit;

 utl_file.fclose(ulaz);
 logit ( 'Obrađeno slogova ' || br_slogova );
 logit (' ');
 logit ( 'POLISE KOJE SU DOŠLE NA STORNIRANJE, A POSTOJE U TABELI POLISA ');
 logit (' ');
 logit ( 'broj polisa sa neproknjiženim stavkama                            ' || brojac1 );
 logit ( 'broj polisa sa proknjiženim stavkama                              ' || brojac2 );
 logit ( 'broj polisa bez stavki                                            ' || brojac3 );
 logit ( 'broj polisa koje smo sada označili kao stornirane u tabeli polisa ' || brojac4 );
 logit ( 'broj polisa bez slogova u strogoj                                 ' || brojac5 );
 logit ( 'broj polisa koje već imaju slog storna u strogoj                  ' || brojac6 );
 logit ( 'broj polisa za koje smo sada upisali slog storna u strogoj        ' || brojac7 );
 logit ( 'broj polisa kojim je zadužen jedan zastupnik,');
 logit ( 'a došao zahtev za storno od drugog zastupnika                     ' || brojac8 );
 logit (' ');
 logit ( 'POLISE KOJE SU DOŠLE NA STORNIRANJE, A NEMA IH U TABELI POLISA ');
 logit (' ');
 logit ( 'broj polisa koje smo sada upisali u tabelu polisa                 ' || brojac11 );
 logit ( 'broj polisa koje nemaju slogove u strogoj                         ' || brojac12 );
 logit ( 'broj polisa koje već imaju slog storna u strogoj                  ' || brojac13 );
 logit ( 'broj polisa za koje smo sada upisali slog storna u strogoj        ' || brojac14 );
 logit ( 'broj polisa kojim je zadužen jedan zastupnik,');
 logit ( 'a došao zahtev za storno od drugog zastupnika                     ' || brojac15 );

 logit('zatvoren.');
 utl_file.fclose(logfl);
exception when others then
			          greska := sqlerrm;
                logit(greska);
 utl_file.fclose_all;
 raise;
END;
------------------------------------------------------------------------------------------------
PROCEDURE za_voju_zk ( put_do_fajla varchar2 ) IS
 pol zelkarton%ROWTYPE;
 broj_polise polisa.pol_brpol%type; -- Broj polise
 broj_zk zelkarton.sifra%type; -- Broj zelenog kartona
 sifra_zastupnika polisa.mbrzastup%type; -- Šifra zastupnika
 zastupnik zastup.naziv%type; -- Naziv zastupnika
 status varchar2(20); -- Status polise ( storno ili ne )
 sifra_dokumenta polisa.vsdok%type; -- Šifra dokumenta
 naziv_dokumenta vrstadok.naziv%type; -- Naziv dokumenta
 datum_dokumenta polisa.datdok%type; -- Datum dokumenta
 datum_pripadnosti polisa.datprip%type; -- Datum pripadnosti
 broj_pol number := 0; -- koliko ima polisa sa tim brojem i tom vrstom dokumenta
 brojac1 number := 0; -- broj polisa sa neproknjiženim ratama
 brojac2 number := 0; -- broj polisa sa proknjiženim ratama
 brojac3 number := 0; -- broj polisa bez rata
 brojac4 number := 0; -- broj polisa koje smo sada označili kao stornirane u tabeli polisa
 brojac5 number := 0; -- broj polisa bez slogova u strogoj
 brojac6 number := 0; -- broj polisa koje već imaju slog storna u strogoj
 brojac7 number := 0; -- broj polisa za koje smo sada upisali slog storna u strogoj
 brojac8 number := 0; -- broj polisa koje su zadućene kod jednog zastupnika, a došao zahtev za storno od drugog zastupnika
 brojac11 number := 0; -- broj polisa koje smo sada upisali u tabelu polisa
 brojac12 number := 0; -- broj polisa koje nemaju slogove u strogoj
 brojac13 number := 0; -- broj polisa koje već imaju slog storna u strogoj
 brojac14 number := 0; -- broj polisa za koje smo sada upisali slog storna u strogoj
 brojac15 number := 0; -- broj polisa koje su zadućene kod jednog zastupnika, a došao zahtev za storno od drugog zastupnika
 kps_status number := 0; -- Da li su rate proknjižene ( kps_status > 0 znači da jesu )
 ima_storno number := 0; -- Da li je dokument do sada storniran ( ima_storno > 0 znači da jeste )
 sifra_promene stroga.svsprom%type; -- Šifra vrste promene u strogoj
 naziv_promene strgprom.naziv%type; -- Naziv vrste promene u strogoj
 zastupnik_prima stroga.mbrzastupprima%type; -- Šifra zastupnika koji je primio dokument po poslednoj promeni u strogoj
 ima_polisa boolean := true; -- Da li postoji traženi broj polise u evidenciji polisa
 ima_stroga boolean := true; -- Da li traženi broj polise postoji u strogoj evidenciji
 ima_zk boolean := true; -- Da li postoji traženi broj zelenog kartona u evidenciji zelenih kartona
 nastavi boolean := TRUE;
 br_slogova number;
 nesto number;

BEGIN
 EOF:=FALSE;
 dbms_output.enable(1000000);

 begin
  ulaz := utl_file.fopen(put_do_fajla,'storzk.dat','r');
  logfl:= utl_file.fopen(put_do_fajla,'storzk.log','w');
  logit('otvoren.');
 exception when utl_file.invalid_path then
  logit('FOPEN:invalid_path');
 when utl_file.invalid_mode then
  logit('FOPEN:invalid_mode');
 when utl_file.invalid_operation then
  logit('FOPEN:invalid_operation');
 end;

  if (utl_file.is_open(ulaz)) then
   logit('citam...');
   br_slogova := 0;
   loop
     begin
       utl_file.get_line(ulaz,komad);
       
-- Početak za zelene kartone
       broj_zk := ltrim(rtrim(substr(komad,1,11)));
       pol.POLISA_BROJ := ltrim(rtrim(substr(komad,12,11)));
       pol.DATUM_POCETKA := c_date ( ltrim(rtrim(substr(komad,23,8))), 'rrrrmmdd' );          
       pol.DATUM_ISTEKA  := c_date ( ltrim(rtrim(substr(komad,31,8))), 'rrrrmmdd' );
       pol.REG_BROJ      := ltrim(rtrim(substr(komad,39,25)));         
       pol.MARKA      := ltrim(rtrim(substr(komad,64,25)));         
       pol.TIP      := ltrim(rtrim(substr(komad,89,25)));         
       pol.MODEL      := ltrim(rtrim(substr(komad,114,25)));   
       pol.nazivugov     := ltrim(rtrim(substr(komad,139,50)));
       pol.MESTO     := ltrim(rtrim(substr(komad,189,50)));
       pol.adresa        := ltrim(rtrim(substr(komad,239,50)));
       pol.datumobrade := c_date ( ltrim(rtrim(substr(komad,289,8))), 'rrrrmmdd' );
       pol.SIFOPERAT   := ltrim(rtrim(substr(komad,297,8)));
       pol.OJ        := ltrim(rtrim(substr(komad,305,13)));
       zastupnik := ltrim(rtrim(substr(komad,318,13)));
       pol.mbrzastup := ltrim(rtrim(substr(komad,318,13)));
       pol.PREMZK        := ltrim(rtrim(substr(komad,331,17)));
       pol.PTTMUG        := ltrim(rtrim(substr(komad,348,10)));        
       pol.DATDOK        := c_date ( ltrim(rtrim(substr(komad,358,8))), 'rrrrmmdd' );        
             
       POL.status := 2;
       pol.vsdok := 2;
       pol.vros := 800;
       pol.napOMENA := 'STORNO';

      ima_zk := true;
      ima_stroga := true;

      select count(*)
      into broj_pol
      from zelkarton
      where vsdok = pol.vsdok and
            zelkarton.sifra = broj_zk;

      if broj_pol != 1 then
        ima_zk := false;
      end if;

      if ima_zk then
-- ww        logit ( 'ZK broj: ' || broj_zk || ' je sada označen kao storniran! ' );
-- update ZK u tabeli ZELKARTON - stavi 2 u polje status (da je storniran)

        update zelkarton set status = 2
        where zelkarton.sifra = broj_zk and
              zelkarton.vsdok = pol.vsdok;
        update zelkarton set NAPOMENA = 'STORNO'
        where zelkarton.sifra = broj_zk and
              zelkarton.vsdok = pol.vsdok;
        update zelkarton set datumobrade = trunc(sysdate) 
        where zelkarton.sifra = broj_zk and
              zelkarton.vsdok = pol.vsdok;

            brojac4 := brojac4 + 1;

        ima_storno := 0;
        select count (*)
        into ima_storno
        from stroga
        where str_vsdok = pol.vsdok and
              str_brojdok = broj_zk;

        if ima_storno = 0 then
            brojac5 := brojac5 + 1;
-- ww          logit ( 'ZK broj: ' || broj_zk || ' ne postoji u strogoj evidenciji! ' );

--  nista se ne radi, jer nema ni ulaza od stampara ni bilo sta u strogoj

        else
          ima_storno := 0;
          select count (*)
          into ima_storno
          from stroga
          where svsprom in ( 22, 24 ) and
                str_vsdok = pol.vsdok and
                str_brojdok = broj_zk;

          if ima_storno > 0 then
-- ww            logit ( 'ZK broj: ' || broj_zk || ' je već stornirana u strogoj! ' );
            brojac6 := brojac6 + 1;

--  nista se ne radi jer je ZK vec storniran u strogoj

          else
            select svsprom, mbrzastupprima, strgprom.naziv
            into sifra_promene, zastupnik_prima, naziv_promene
            from stroga, strgprom
            where id = ( select max ( id )
--            where str_rednibroj = ( select max ( str_rednibroj )
                                     from stroga
                                    where str_vsdok = pol.vsdok and
                                          str_brojdok = broj_zk ) and
                 str_vsdok = pol.vsdok and
                 str_brojdok = broj_zk and
                 svsp_sifra = svsprom;
            if zastupnik_prima = zastupnik then
-- ww              logit ( 'ZK broj: ' || broj_zk || ' sada smo stornirali u strogoj' );
            brojac7 := brojac7 + 1;

--  napraviti storno stavku za strogu evidenciju

			insert into stroga ( str_vsdok, str_brojdok, str_datumpromene, str_rednibroj, mbrzastupprima,
													 svsprom, datumobrade, sifoperat, id )
									values ( pol.vsdok, broj_zk, pol.datumobrade, 5, pol.mbrzastup,
													 24, trunc(sysdate), 'ljilja', stroga_seq.nextval );

            else
              logit ( 'ZK broj: ' || broj_zk || ' zadužio je zastupnik '|| zastupnik_prima || ' sa šifrom ' || sifra_promene || ' a stornira ga zastupnik ' || zastupnik );
              brojac8 := brojac8 + 1;

-- nista se ne radi jer zastupnici nisu isti, samo obavestenje

            end if;
          end if;
        end if;
        else
-- ww          logit ( 'ZK broj: ' || broj_zk || ' je sada upisan u tabelu ZK kao storniran! ');
          brojac11 := brojac11 + 1;
                



-- upisi ZK u tabelu zk         sa oznakom 2 (da je storniran)

    	insert into zelkarton ( sifra, oj, mbrzastup, nazivugov, adresa, datum_pocetka, datum_isteka,
    											 datdok, premzk, datumobrade, sifoperat, vros, vsdok, status,
    											 napomena, polisa_broj,reg_broj, marka, tip, model, mesto, 
    											 pttmug, stroga, brosk )
    							values ( broj_zk, pol.oj, pol.mbrzastup, pol.nazivugov, pol.adresa, pol.datum_pocetka, pol.datum_isteka,
    											 pol.datdok, pol.premzk, trunc(sysdate), 'ljilja', pol.vros, pol.vsdok, 2,
    											 pol.napomena, pol.polisa_broj, pol.reg_broj, pol.marka, pol.tip, pol.model, pol.mesto,
    											 pol.pttmug, 1, pol.mbrzastup || to_char ( pol.datdok, 'rrrrmmdd' ) );

        ima_storno := 0;
        select count (*)
        into ima_storno
        from stroga
        where str_vsdok = pol.vsdok and
              str_brojdok = broj_zk;

        if ima_storno = 0 then
-- ww          logit ( 'ZK broj: ' || broj_zk || ' ne postoji u strogoj evidenciji! ' );
            brojac12 := brojac12 + 1;

--  nista se ne radi, jer nema ni ulaza od stampara ni bilo sta u strogoj

        else
          ima_storno := 0;
          select count (*)
          into ima_storno
          from stroga
          where svsprom in ( 22, 24 ) and
                str_vsdok = pol.vsdok and
                str_brojdok = broj_zk;

          if ima_storno > 0 then
-- ww            logit ( 'ZK broj: ' || broj_zk || ' je već storniran u strogoj! ' );
            brojac13 := brojac13 + 1;

--  nista se ne radi jer je ZK vec storniran u strogoj

          else
            select svsprom, mbrzastupprima, strgprom.naziv
            into sifra_promene, zastupnik_prima, naziv_promene
            from stroga, strgprom
            where id = ( select max ( id )
--            where str_rednibroj = ( select max ( str_rednibroj )
                                     from stroga
                                    where str_vsdok = pol.vsdok and
                                          str_brojdok = broj_zk ) and
                 str_vsdok = pol.vsdok and
                 str_brojdok = broj_zk and
                 svsp_sifra = svsprom;
            if zastupnik_prima = zastupnik then
-- ww            	 logit ( 'ZK broj: ' || broj_zk || ' sada smo stornirali u strogoj! ' );
            brojac14 := brojac14 + 1;

--  napraviti storno stavku za strogu evidenciju

			insert into stroga ( str_vsdok, str_brojdok, str_datumpromene, str_rednibroj, mbrzastupprima,
													 svsprom, datumobrade, sifoperat, id )
									values ( pol.vsdok, broj_zk, pol.datumobrade, 5, pol.mbrzastup,
													 24, trunc(sysdate), 'ljilja', stroga_seq.nextval );

            else
              logit ( 'ZK broj: ' || broj_zk || ' zadužen je zastupnik '|| zastupnik_prima || ' sa šifrom ' || sifra_promene || ' a stornira ga zastupnik ' || zastupnik );
            brojac15 := brojac15 + 1;

-- nista se ne radi jer zastupnici nisu isti, samo obavestenje

            end if;
          end if;
        end if;
      end if;


-- Kraj za zelene kartone */


    br_slogova := br_slogova + 1;

    exception when no_data_found then
          			EOF := true;
              when others then
                br_slogova := br_slogova + 1;
			          greska := sqlerrm;
                logit(greska || ' ' || komad);
    end;
   	exit when EOF;
   end loop;
  else
   logit('FGETLINE:Nije otvoren file');
  end if;
  
  commit;

 utl_file.fclose(ulaz);
 logit ( 'Obrađeno slogova ' || br_slogova );
 
 logit (' ');
 logit ( 'ZK KOJI SU DOŠLI NA STORNIRANJE, A POSTOJE U TABELI ZELKARTON ');
 logit (' ');
 logit ( 'broj ZK sa neproknjiženim stavkama                            ' || brojac1 );
 logit ( 'broj ZK sa proknjiženim stavkama                              ' || brojac2 );
 logit ( 'broj ZK bez stavki                                            ' || brojac3 );
 logit ( 'broj ZK koje smo sada označili kao stornirane u tabeli        ' || brojac4 );
 logit ( 'broj ZK bez slogova u strogoj                                 ' || brojac5 );
 logit ( 'broj ZK koje već imaju slog storna u strogoj                  ' || brojac6 );
 logit ( 'broj ZK za koje smo sada upisali slog storna u strogoj        ' || brojac7 );
 logit ( 'broj ZK kojim je zadužen jedan zastupnik,');
 logit ( 'a došao zahtev za storno od drugog zastupnika                 ' || brojac8 );
 logit (' ');
 logit ( 'ZK KOJI SU DOŠLI NA STORNIRANJE, A NEMA IH U TABELI ZELKARTON ');
 logit (' ');
 logit ( 'broj ZK koje smo sada upisali u tabelu ZK                     ' || brojac11 );
 logit ( 'broj ZK koje nemaju slogove u strogoj                         ' || brojac12 );
 logit ( 'broj ZK koje već imaju slog storna u strogoj                  ' || brojac13 );
 logit ( 'broj ZK za koje smo sada upisali slog storna u strogoj        ' || brojac14 );
 logit ( 'broj ZK kojim je zadužen jedan zastupnik,');
 logit ( 'a došao zahtev za storno od drugog zastupnika                 ' || brojac15 );
 
 logit('zatvoren.');
 utl_file.fclose(logfl);
exception when others then
 utl_file.fclose_all;
 raise;
END;
end;

/

