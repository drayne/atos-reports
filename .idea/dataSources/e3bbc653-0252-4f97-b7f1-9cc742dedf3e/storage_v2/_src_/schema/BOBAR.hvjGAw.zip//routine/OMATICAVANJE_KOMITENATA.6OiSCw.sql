create PROCEDURE OMATICAVANJE_KOMITENATA AS
BEGIN
  for red in (select * from bobar.parametri) loop
  null;
  end loop;
END OMATICAVANJE_KOMITENATA;


/

