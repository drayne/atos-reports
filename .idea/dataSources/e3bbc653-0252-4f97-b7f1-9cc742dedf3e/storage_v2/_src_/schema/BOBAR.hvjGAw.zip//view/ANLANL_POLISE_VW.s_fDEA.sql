create view ANLANL_POLISE_VW as
  SELECT A.POL_BRPOL,
            SUM (A.DEV_DUGUJE) dospjelo,
            SUM (a.dev_potrazuje) naplaceno,
            SUM (A.DEV_DUGUJE) - SUM (A.DEV_POTRAZUJE) nenaplaceno,
            A.ANL_VSDOK,
            A.DATNAL
       FROM anlanl a
      WHERE                             --A.DATNAL between :p_d_od and :p_d_do
            --and A.ANL_VSDOK = :vsdok
            a.POL_BRPOL IS NOT NULL
   GROUP BY A.POL_BRPOL, A.ANL_VSDOK, A.DATNAL

/

