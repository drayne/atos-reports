create trigger TARIFA5ID_PREINS
  before insert
  on TARIFA5
  for each row
  begin
 select tarifa5seq.nextval into :new.id from dual;
end;



/

