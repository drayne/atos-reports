create trigger AIR_TOSNSREDSTVO
  after insert
  on TOSNSREDSTVO
  for each row
  BEGIN
insert into TOsnKartica (
   ID                ,
   TABLEMANAGER      ,
   VLASNIK           ,
   LOKACIJA          ,
   INVENTARSKIBROJ   ,
   VD                ,
   GODINAPROMENE     ,
   MESECPROMENE      ,
   NABAVNAVREDNOST   ,
   ISPRAVKAVREDNOSTI ,
   METODAMORTIZACIJE ,
   STOPA             ,
   VARIJABILNASTOPA  ,
   DATUMOBRADE       ,
   SIFOPERAT
)
values (
    null,                   -- ID
    null,                   -- TABLEMANAGER
    :new.vlasnik,           -- VLASNIK
    :new.lokacija,          -- LOKACIJA
    :new.inventarskibroj,   -- INVENTARSKIBROJ
    :new.vd,                -- VD
    :new.godinaaktiviranja, -- GODINAPROMENE
    :new.mesecaktiviranja,  -- MESECPROMENE
    :new.nabavnavrednost,   -- NABAVNAVREDNOST
    :new.ispravkavrednosti, -- ISPRAVKAVREDNOSTI
    null,                   -- METODAMORTIZACIJE
    null,                   -- STOPA
    null,                   -- VARIJABILNASTOPA
    :new.datumobrade,       -- DATUMOBRADE
    :new.sifoperat          -- SIFOPERAT
);
END;



/

