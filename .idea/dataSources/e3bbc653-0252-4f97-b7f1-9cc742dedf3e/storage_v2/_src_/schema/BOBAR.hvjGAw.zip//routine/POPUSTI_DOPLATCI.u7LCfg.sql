create function popusti_doplatci (p_vsdok number,p_pol_brpol number) return varchar2 as 
  zapis varchar(100):='_';
  popust number:=0;
  doplatak number:=0;
begin
  select sif_doplatka,sif_popusta into doplatak,popust from polao3 where vsdok=p_vsdok and ao3_brpol=p_pol_brpol;
  for red in (select * from popdop where pd_vros=800 and aktivan='D' order by id asc) loop
    if (red.pd_sifra=popust or red.pd_sifra=doplatak) then
        if trim(zapis)='_' then
          zapis:=red.sifra_azors;
        else
         zapis:=zapis||'.'||red.sifra_azors;
        end if;
      else
        if trim(zapis)='_' then
          zapis:=' ';
        else
         zapis:=zapis||'.';
        end if;
    end if;
  end loop;
  return TRIM(zapis);
END POPUSTI_DOPLATCI;

/

