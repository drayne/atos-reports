create trigger TAR3_ID_PREINS
  before insert
  on TARIFA_3
  for each row
  begin
select tar3_seq.nextval into :new.tar3_id from dual;
end;



/

