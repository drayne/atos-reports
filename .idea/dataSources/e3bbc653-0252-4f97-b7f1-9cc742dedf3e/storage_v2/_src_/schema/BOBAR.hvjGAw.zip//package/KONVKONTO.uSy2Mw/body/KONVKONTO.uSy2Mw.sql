create PACKAGE BODY        konvkonto IS
Function c_date(u_str varchar2, u_fm varchar2) return date is
 i date;
 u varchar2(1022);
begin
 greska := null;
 u :=ltrim(rtrim(u_str));
 if (length(u) is null) then
  return null;
 end if;
 i := to_date(u_str,u_fm);
 return i;
 exception when others then
  greska := sqlerrm;
  logit('>'||u_str||'< ' || greska);
  return null;
end;

Function c_numb(u_str varchar2) return number is
 i number;
 u varchar2(1022);
begin
 greska := null;
 u := ltrim(rtrim(u_str));
 if ((length(u) is null) or (u = '.')) then
  return null;
 end if;
 i := to_number(u_str);
 return i;
exception when others then
  greska := sqlerrm;
  logit('>'||u_str||'< ' || greska);
  return null;
end;

PROCEDURE logit(st number, en number) is
begin
 utl_file.put_line(logfl,to_char(linija,'09999')||':'||substr(komad,st,en) || ':');
 utl_file.put_line(logfl,greska);
end;

procedure logit(ms varchar2) is
begin
 utl_file.put_line(logfl,to_char(linija,'09999')||':'|| ms);
end;
------------------------------------------------------------------------------------------------
PROCEDURE konvertuj (put_do_fajla varchar2) IS
 pol konto%ROWTYPE;
 nastavi boolean := TRUE;
 br_upisanih number;

BEGIN
 EOF:=FALSE;
 dbms_output.enable(100000);

 begin
  ulaz := utl_file.fopen(put_do_fajla,'konto.dat','r');
  logfl:= utl_file.fopen(put_do_fajla,'konto.log','w');
  logit('otvoren.');
 exception when utl_file.invalid_path then
  logit('FOPEN:invalid_path');
 when utl_file.invalid_mode then
  logit('FOPEN:invalid_mode');
 when utl_file.invalid_operation then
  logit('FOPEN:invalid_operation');
 end;


  if (utl_file.is_open(ulaz)) then
   logit('citam...');
   br_upisanih := 0;
   loop
     begin
       utl_file.get_line(ulaz,komad);
       pol.kon_sifra := ltrim(rtrim(substr(komad,1,6)));
       pol.naziv := ltrim(rtrim(substr(komad,7,52)));
       pol.kon_oj := ltrim(rtrim(substr(komad,76,1)));

    update konto set konto.naziv = yu852lat(pol.naziv)
                  where konto.kon_sifra = pol.kon_sifra and
                        konto.kon_oj = pol.kon_oj;
 

    br_upisanih := br_upisanih + 1;

    if br_upisanih = 63 then
      commit;
      br_upisanih := 0;
    end if;  

    logit(greska || ' ' ||komad);

    exception when no_data_found then EOF := TRUE;
    when others then
      greska := sqlerrm;
      logit(greska || ' ' ||komad);
    end;
    exit when EOF;
   end loop;
  else
   logit('FGETLINE:Nije otvoren file');
  end if;

--finalize
 utl_file.fclose(ulaz);
 logit('zatvoren.');
-- logit('Insertovano: ' || to_char(br_upisanih) || ' zapisa!');
 utl_file.fclose(logfl);
exception when others then
 utl_file.fclose_all;
 raise;
END;  
END;
/

