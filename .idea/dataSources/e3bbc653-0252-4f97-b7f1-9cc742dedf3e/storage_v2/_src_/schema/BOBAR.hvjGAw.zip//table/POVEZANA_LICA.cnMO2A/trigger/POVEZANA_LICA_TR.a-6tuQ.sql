create trigger POVEZANA_LICA_TR
  before insert
  on POVEZANA_LICA
  for each row
  begin
 select POVEZANA_LICA_SEQ.nextval into :new.id from dual;
end;
/

