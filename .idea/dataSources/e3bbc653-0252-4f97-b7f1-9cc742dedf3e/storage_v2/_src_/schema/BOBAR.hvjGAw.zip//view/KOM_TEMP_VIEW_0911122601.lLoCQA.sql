create view KOM_TEMP_VIEW_0911122601 as
  select k.kom_sifra, k.naziv, m.mes_sifra||' '|| m.mesto as mesto, k.adresa, k.delat delatnost, to_char(m.mes_sifra)||' '||m.mesto as adresa1, 0 donos_dug, 0 donos_pot from komitent k, mesto m, vrstasvoj v where k.kom_sifra between 1313 and 1313 and k.pttm = m.mes_sifra and k.vrstasvojine = v.vrs_sifra(+) and k.kom_sifra in ( select komitent from anlanl where komitent between 1313 and 1313 and anl_vlasnik between 2 and 2 and anl_radnja between 2 and 2 and anl_vsdok not in (300) and trunc(datnal) between to_date('01.01.17') and to_date('11.09.17') and konto between '46420' and '46420')

/

