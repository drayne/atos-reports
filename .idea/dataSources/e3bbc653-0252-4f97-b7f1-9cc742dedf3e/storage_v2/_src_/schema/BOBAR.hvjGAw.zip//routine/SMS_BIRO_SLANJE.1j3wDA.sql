create PROCEDURE       SMS_BIRO_SLANJE AS
    sedmica number;    
    dan number;
    dan_u_mesecu number;
    
begin

    select to_char (sysdate, 'IW')
    into sedmica 
    from dual;
    
    select to_char (sysdate, 'D')
    into dan 
    from dual;

    select to_char (sysdate, 'DD')
    into dan_u_mesecu 
    from dual;
    
    --Biro ZK, polise AO, granicne, probne (sedmicno) + ZK (od 01.02.2014) + dodat je broj Gorana Stevica (03.04.2014)
    if dan = 4 then --cetvrtak
        if mod(sedmica+dan, 2) = 1 then --neparan, Brano, Mitric, Stevic i Bojicic
            --insert into tep.sms_slanje (receiver,msg,vrsta,operater,napomena)
            --values ('065405951', 'Biro ZK - slanje podataka - Polise AO, granicne, probne, ZK.', 0, sysdate, 'Oracle');
            insert into tep.sms_slanje (receiver,msg,vrsta,operater,napomena)
            values ('066610734', 'Biro ZK - slanje podataka - Polise AO, granicne, probne, ZK. Have a nice day! :-)', 0, sysdate, 'Oracle');
            insert into tep.sms_slanje (receiver,msg,vrsta,operater,napomena)
            values ('065046323', 'Biro ZK - slanje podataka - Polise AO, granicne, probne, ZK. Have a nice day! :-)', 0, sysdate, 'Oracle');
            insert into tep.sms_slanje (receiver,msg,vrsta,operater,napomena)
            values ('065809123', 'Biro ZK - slanje podataka - Polise AO, granicne, probne, ZK. Have a nice day! :-)', 0, sysdate, 'Oracle');
            commit;
        else --paran, Brano, Mitric, Stevic i Bojicic
            --insert into tep.sms_slanje (receiver,msg,vrsta,operater,napomena)
            --values ('065405951', 'Biro ZK - slanje podataka - Polise AO, granicne, probne, ZK.', 0, sysdate, 'Oracle');            
            insert into tep.sms_slanje (receiver,msg,vrsta,operater,napomena)
            values ('066610734', 'Biro ZK - slanje podataka - Polise AO, granicne, probne, ZK. Have a nice day! :-)', 0, sysdate, 'Oracle');
            insert into tep.sms_slanje (receiver,msg,vrsta,operater,napomena)
            values ('065046323', 'Biro ZK - slanje podataka - Polise AO, granicne, probne, ZK. Have a nice day! :-)', 0, sysdate, 'Oracle');
            insert into tep.sms_slanje (receiver,msg,vrsta,operater,napomena)
            values ('065809123', 'Biro ZK - slanje podataka - Polise AO, granicne, probne, ZK. Have a nice day! :-)', 0, sysdate, 'Oracle');
            commit;
        end if;
    end if;
    
-- od 01.02.2014 (iako je trebalo od 01.07.2013) se ZK salju sedmicno, cetvrtkom
/*
    --Biro ZK, Zeleni kartoni (mesecno)
    if dan_u_mesecu = 15 then --15-ti u mesecu
        insert into tep.sms_slanje (receiver,msg,vrsta,operater,napomena)
        values ('065831921', 'Biro ZK - slanje podataka za prethodni mjesec - Zeleni kartoni. NAPOMENA: Iskljuciti/Ukljuciti DSE', 0, sysdate, 'Oracle');
        insert into tep.sms_slanje (receiver,msg,vrsta,operater,napomena)
        values ('066610734', 'Biro ZK - slanje podataka za prethodni mjesec - Zeleni kartoni. NAPOMENA: Iskljuciti/Ukljuciti DSE', 0, sysdate, 'Oracle');
        commit;
    end if;
*/  
  exception
  when others then
  null;
  
end SMS_BIRO_SLANJE;

/

