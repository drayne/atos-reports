create PROCEDURE job_NALOG_TOTAL_SALDO AS
BEGIN
  update nalog
  set total_duguje = ( select sum(dev_duguje) from anlanl where
                     nal_vlasnik = anl_vlasnik and
                     nal_radnja = anl_radnja and
                     nal_vsdok = anl_vsdok and
                     nal_nalog = anl_nalog )
  where
                   ( select sum(dev_duguje) from anlanl where
                     nal_vlasnik = anl_vlasnik and
                     nal_radnja = anl_radnja and
                     nal_vsdok = anl_vsdok and
                     nal_nalog = anl_nalog ) is not null
  ;

  update nalog
  set total_potrazuje = ( select sum(dev_potrazuje) from anlanl where
                        nal_vlasnik = anl_vlasnik and
                        nal_radnja = anl_radnja and
                        nal_vsdok = anl_vsdok and
                        nal_nalog = anl_nalog )
  where
                      ( select sum(dev_potrazuje) from anlanl where
                        nal_vlasnik = anl_vlasnik and
                        nal_radnja = anl_radnja and
                        nal_vsdok = anl_vsdok and
                        nal_nalog = anl_nalog ) is not null
  ;

  commit;


  update nalog
  set saldo_duguje = 0;

  update nalog
  set saldo_potrazuje = 0;

  commit;

  update nalog set saldo_duguje = total_duguje - total_potrazuje
  where
  total_duguje > total_potrazuje;

  update nalog set saldo_potrazuje = total_potrazuje - total_duguje
  where
  total_potrazuje > total_duguje;

  commit;

END job_NALOG_TOTAL_SALDO;

/

