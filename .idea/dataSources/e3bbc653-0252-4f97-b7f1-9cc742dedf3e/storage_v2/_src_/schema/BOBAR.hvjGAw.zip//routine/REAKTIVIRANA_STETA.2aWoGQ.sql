create FUNCTION REAKTIVIRANA_STETA (pid number) RETURN VARCHAR2 AS 
  datum varchar2(10);
  reakt number;
  maxgodina varchar2(4);
BEGIN
  select count(distinct(to_char(datum_statusa,'rrrr'))) into reakt
  from (
  select prijstet_id id,status_stete,sta_datum_od datum_statusa from statstet where prijstet_id=pid 
  union all
  select id,status_stete,datum_statusa from prijstet where id=pid
  )
  where status_stete between 10 and 59;
  if reakt=2 then
    select max(distinct(to_char(datum_statusa,'rrrr'))) into maxgodina
    from (
    select prijstet_id id,status_stete,sta_datum_od datum_statusa from statstet where prijstet_id=pid
    union all
    select id,status_stete,datum_statusa from prijstet where id=pid
    )
    where status_stete between 10 and 59;
    if maxgodina is not null then 
      select to_char(min(datum_statusa)) into datum
      from (
      select prijstet_id id,status_stete,sta_datum_od datum_statusa from statstet where prijstet_id=pid
      union all
      select id,status_stete,datum_statusa from prijstet where id=pid
      )
      where status_stete between 10 and 59 and to_char(datum_statusa,'rrrr')=maxgodina;
    end if;  
  end if;  
  return datum;
END REAKTIVIRANA_STETA;

/

