create PROCEDURE SALDO
 (PR_DUG_IN IN NUMBER
 ,PR_POT_IN IN NUMBER
 ,SA_DUG_OUT IN OUT NUMBER
 ,SA_POT_OUT IN OUT NUMBER
 )
 IS
BEGIN
     BEGIN
       SELECT DECODE(SIGN(NVL(pr_dug_in,0)-nvl(pr_pot_in,0)),
                         1,NVL(pr_dug_in,0)-nvl(pr_pot_in,0),
                           0)
         INTO sa_dug_out
         FROM sys.dual;
     EXCEPTION
        WHEN OTHERS THEN
          raise_application_error( -20030,
          'Nije izra?unat saldo duguje!');
     END;
     BEGIN
        SELECT DECODE(SIGN(NVL(pr_dug_in,0)-nvl(pr_pot_in,0)),
                         -1,NVL(pr_pot_in,0)-nvl(pr_dug_in,0),
                            0)
         INTO sa_pot_out
         FROM sys.dual;
     EXCEPTION
        WHEN OTHERS THEN
          raise_application_error( -20031,
          'Nije izra?unat saldo potrazuje!');
     END;
  END;


/

