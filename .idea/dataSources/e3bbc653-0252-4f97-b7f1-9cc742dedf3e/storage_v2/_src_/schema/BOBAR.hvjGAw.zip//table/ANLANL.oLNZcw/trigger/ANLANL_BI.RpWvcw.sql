create trigger ANLANL_BI
  before insert or update
  on ANLANL
  for each row
  BEGIN
  if inserting then
    if :new.id is null then
      select anl_seq.nextval into :new.id from dual;
    end if;
  end if;
  :new.datnal := trunc ( :new.datnal );
  :new.datdok := trunc ( :new.datdok );
  :new.datval := trunc ( :new.datval );
END;



/

