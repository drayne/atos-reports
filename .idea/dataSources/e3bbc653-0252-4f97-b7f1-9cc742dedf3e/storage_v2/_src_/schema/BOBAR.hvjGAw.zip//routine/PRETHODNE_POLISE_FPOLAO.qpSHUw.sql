create function       prethodne_polise_fpolao (p_broj_polise number ) return varchar2 as
  broj_prethodne_polise varchar2(100);
  polisa_bm varchar2(20); polisa_bm_osig varchar2(20);
  polisa_prethodna varchar2(20); polisa_prethodna_osig varchar2(20);
  polisa_zampol varchar2(20); polisa_zampol_osig varchar2(20);
BEGIN
 select p.BM_PRENOS_POLISA, nvl(D.KODDR,'') 
       into polisa_bm, polisa_bm_osig
       from polisa p, tep.ddor d
      where P.POL_BRPOL = p_broj_polise
      and P.VSDOK=1
      and d.sifra = p.BM_PRENOS_OSIG_KUCA;
      
 select p.zampol, nvl(D.KODDR,'')
       into polisa_zampol, polisa_zampol_osig
       from polisa p, tep.ddor d
      where P.POL_BRPOL = p_broj_polise
      and P.VSDOK=1
      and D.SIFRA=890;
      
 select p.brpol_ostali, nvl(D.KODDR,'')
                into polisa_prethodna, polisa_prethodna_osig
                from polisa p, tep.ddor d
               where P.POL_BRPOL = p_broj_polise
               and P.VSDOK=1
               and d.sifra = P.OSIG_OSTALI;          

if       polisa_zampol is not null then
            broj_prethodne_polise := polisa_zampol_osig || ' - ' || polisa_zampol;
elsif   polisa_bm is not null then
            broj_prethodne_polise := polisa_bm_osig || ' - ' || polisa_bm;
elsif   polisa_prethodna is not null then
            broj_prethodne_polise := polisa_prethodna_osig || ' - ' || polisa_prethodna;
else    broj_prethodne_polise := ' ';
end if;
              
               
    return broj_prethodne_polise;
END prethodne_polise_fpolao;

/

