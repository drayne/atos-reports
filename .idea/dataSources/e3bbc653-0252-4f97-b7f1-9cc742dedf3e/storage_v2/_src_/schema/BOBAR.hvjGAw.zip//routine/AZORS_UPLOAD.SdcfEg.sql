create FUNCTION         "AZORS_UPLOAD" (p_datum_od date,p_datum_do date) RETURN VARCHAR2 AS 
	fajl utl_file.file_type;
  broj_paketa varchar(6);
  broj_polisa number:=0;
  kontakt   varchar(200):='zvjezdan.paravac@bobar.com';
  delimeter varchar(200):=';';
  gdje_je_problem varchar(100):='';
  --PRAGMA AUTONOMOUS_TRANSACTION;
begin
  --execute immediate 'alter session set nls_numeric_characters=''.,''';
  --redni broj paketa u tekucoj godini
  select lpad(nvl(max(to_number(substr(azors_slanje_id,instr(azors_slanje_id,'-')+1))),0)+1,6,0) into broj_paketa
  from polisa
  where substr(azors_slanje_id,0,instr(azors_slanje_id,'-')-1)=to_char(sysdate,'rrrr');
  --ukupan broj polisa
  select count(p.vsdok) into broj_polisa
              from polisa p, tarifa t, polao3 p3, zastup z, tep.ddor,mesto mi,opstina o,bonus_malus bm, mesto mu, opstina ou, polao2 p2, bonus_malus bm1, cenao ca
              --,(select polisa_broj,sifra from zelkarton zk1 where sifra in (select max(zk2.sifra) from zelkarton zk2 where zk1.polisa_broj=zk2.polisa_broj )) zk
              where (p.pttm = mi.mes_sifra(+) and mi.opst = o.ops_sifra(+)) and 
              (p3.bonusmalus = bm.sifra(+)) and 
              --(zk.polisa_broj(+)=to_char(p.pol_brpol)) and
              (p.bm_prenos_procenat = bm1.sifra(+)) and
              (ca.cao_zonr(+)=p3.zonr and ca.cao_targru(+)=p3.targrupa and ca.cao_tarpgr(+)=p3.tarpodgrupa) and
              (p.pttmug=mu.mes_sifra(+) and mu.opst = ou.ops_sifra(+)) and
              (p.osig_ostali = ddor.sifra(+)) and 
              (p.mbrzastup=z.zas_sifra) and 
              (p.vros=t.tar_vros and p.tar=t.tar_tar) and 
              (p.vsdok=p3.vsdok and p.pol_brpol=p3.ao3_brpol) and
              (p.vsdok=p2.vsdok and p.pol_brpol=p2.ao2_brpol) and
              not exists  (select * from stroga s where s.str_brojdok=p.pol_brpol and s.str_vsdok=p.vsdok and s.svsprom in (22,24)) and
              p.vsdok in (1,4) 
              and p.datdok >= '01.01.2010'
              and p.datdok between p_datum_od and p_datum_do and p.azors_slanje_id is null /*and p.pol_brpol=968403 and p.vsdok=1*/;
              
  fajl:= utl_file.fopen('c:\bobar\osiguranje','P-RD-7-'||to_char(sysdate,'rrrr')||'-'||broj_paketa||'.txt','W');
  utl_file.put_line( fajl,'0'||delimeter||'RD-7'||delimeter||to_char ( sysdate, 'rrrr-mm-dd' ) || 'T' || to_char ( systimestamp, 'hh24:mi:ss.ff7TZH:TZM' )||delimeter||to_char(sysdate,'rrrr')||'-'||broj_paketa||delimeter||broj_polisa||delimeter||kontakt);
  for rb in (select rownum rb,insurancecompanycode,sourcerecordidentifier,sourcepolicyidentifier,insurancetypecode,insurancesubtypecode,premiumgroupcode,
              premiumsubgroupcode, BasicPremiumSum,insurancepolicynumber,greencardnumber,agentcode,previousinsurancecompanycode,previousinsurancepolicynumber,
              previousinsurancepremiumclass,insurancecontractdate,insurancecontractplace,insurancestartdate,insuranceexpirydate,insurancepremiumclass,insurancepremiumrate,
              insurancepremiumsum,insurancepremiumcurrency,discountandadditions,assetinsurancesum,assetinsurancecurrency,injuryinsurancesum,injuryinsurancecurrency,
              insurancestatuscode,insurancestatusdate,dataimportdate,bonusmaluspolicynumber,bonusmalustransferred,name,typeofentity,firstname,lastname,identificationnumber,
              taxidentificationnumber,companyregistrationnumber,housenumber,street,city,postcode,municipalitycode,municipalityname,country,vehicleregistrationnumber,
              vehicletypecode,manufacturername,ModelName,vehicleidentificationnumber,productionyear,maxpower,maxload,seatingcapacity,vehiclepurpose,enginecapacity,EngineNumber 
              from (
              select 'RD-7' InsuranceCompanyCode,
              p.rowid sourcerecordidentifier,
              p.pol_brpol||'-'||p.vsdok sourcepolicyidentifier,
              substr ( nbs, 1, 2 ) insurancetypecode,
              substr ( nbs, 3) insurancesubtypecode,
              --lpad ( to_char ( p3.targrupa ), 2, '0' ) premiumgroupcode,
              substr((case when p.vsdok=4 and ca.sifra_azors is null then '0801' else ca.sifra_azors end),0,2) premiumgroupcode,
              --decode ( p.vsdok, 4, '01', lpad ( to_char ( decode ( p3.targrupa, 2, decode ( p3.tarpodgrupa, 10, 9, p3.tarpodgrupa ), p3.tarpodgrupa )), 2, '0' ) ) premiumsubgroupcode,
              substr((case when p.vsdok=4 and ca.sifra_azors is null then '0801' else ca.sifra_azors end),3,2) premiumsubgroupcode,
              ltrim ( to_char ( osnpremao, '9999990.00' ) ) BasicPremiumSum,
              p.pol_brpol insurancepolicynumber,
              --decode(p.vsdok,1,zk.polisa_broj,null) greencardnumber,
              p.broj_zk greencardnumber,
              --decode(p.vsdok,1,(select max(z.sifra) from zelkarton z where z.polisa_broj=to_char(p.pol_brpol)),null) greencardnumber,
              nvl(z.sifra_azors,'RZ-1-000') agentcode,
              --decode ( nvl ( p.zampol, '0' ), '0', decode ( p.brpol_ostali, null, null, ddor.sifra_azors ),  'RD-7'  ) previousinsurancecompanycode,
              --case when provjeri_broj(p.zampol)='TRUE' and p.zampol>0 then 'RD-7' else ddor.sifra_azors end previousinsurancecompanycode,
              case when provjeri_broj(p.zampol)='TRUE' and p.zampol>0 then 'RD-7' else (case when provjeri_broj(p.brpol_ostali)='TRUE' and p.brpol_ostali>0 then ddor.sifra_azors else null end)  end previousinsurancecompanycode,
              --decode ( nvl ( p.zampol, '0' ), '0', decode ( p.brpol_ostali, null, null, p.brpol_ostali  ), p.zampol  ) previousinsurancepolicynumber,
              --case when provjeri_broj(p.zampol)='TRUE' and p.zampol>0 then p.zampol else p.brpol_ostali end previousinsurancepolicynumber,
              izbaci_simbol_string(substr(case when provjeri_broj(p.zampol)='TRUE' and p.zampol>0 then p.zampol else (case when provjeri_broj(p.brpol_ostali)='TRUE' and p.brpol_ostali>0 then p.brpol_ostali else null end)  end,0,15)) previousinsurancepolicynumber,
              decode(p.bm_prenos_polisa,null,null,nvl(lpad(bm1.premijski_razred,2,0),'01')) previousinsurancepremiumclass,
              to_char ( p.datdok, 'rrrr-mm-dd' ) || 'T'||nvl(to_char(p.vreme_izdavanja,'hh24:mi:ss'),'08:00:00')||'.0000000' || to_char ( systimestamp, 'TZH:TZM' ) insurancecontractdate,
              o.sifra_azors insurancecontractplace,
              to_char ( p.datpoc, 'rrrr-mm-dd' ) || 'T23:59:00.0000000' || to_char ( systimestamp, 'TZH:TZM' ) insurancestartdate,
              to_char ( p.datist , 'rrrr-mm-dd' ) || 'T23:59:00.0000000' || to_char ( systimestamp, 'TZH:TZM' ) insuranceexpirydate,
              --premijski_razred_polise(p.vsdok,p.pol_brpol,null) insurancepremiumclass,
              nvl(lpad(bm.premijski_razred,2,0),'06') insurancepremiumclass,
              decode(nvl(p3.bonusmalus,0),0,100,decode ( bm.bonus_malus, 'B', 100 - bm.procenat, 'M', 100 + bm.procenat, 100 )) insurancepremiumrate,
              --ltrim ( to_char ( p3.uk_prem_ano + nvl ( p3.izn_doplatka, 0 ) + nvl ( p3.izn_popusta, 0 ), '9999990.00' ) ) insurancepremiumsum,
              ltrim ( to_char ( nvl(premija(p.vsdok,p.pol_brpol),0), '9999990.00' ) ) insurancepremiumsum,
              'BAM' insurancepremiumcurrency,
              case when (p3.sif_popusta is null and p3.sif_doplatka is 
              null) then '................' else popusti_doplatci(p.vsdok,p.pol_brpol) end discountandadditions,
               '350000.00' AssetInsuranceSum,
              'BAM' AssetInsuranceCurrency,
              '1000000.00' injuryinsurancesum,
              'BAM' injuryinsurancecurrency,
              decode ( p.datum_prestanka_vazenja, null, 'A', 'S' ) insurancestatuscode,
              decode ( p.datum_prestanka_vazenja, null, to_char ( p.datpoc, 'rrrr-mm-dd' ), to_char ( p.datist, 'rrrr-mm-dd' ) ) insurancestatusdate,
              to_char ( sysdate, 'rrrr-mm-dd' ) dataimportdate,
              izbaci_simbol_string(substr(decode ( p.bm_prenos_polisa, null, null, p.bm_prenos_polisa ),0,15)) bonusmaluspolicynumber,
              decode ( p.bm_prenos_polisa, null, 'N', 'Y') bonusmalustransferred,
              convert ( p.nazivugov, 'UTF8' ) name,
              decode ( p.sektor, 1, 'P', 2, 'F', 'F' ) typeofentity,
              '' firstname,
              '' lastname,
              lpad ( nvl ( p.jmbg, '1' ), 13, '0' )  identificationnumber,
              '' taxidentificationnumber,
              '' companyregistrationnumber,
              '' housenumber,
              convert ( p.adresa, 'UTF8' ) Street,
              convert ( mu.mesto, 'UTF8' ) City,
              pttmug postcode,
              ou.sifra_azors municipalitycode,
              convert(ou.naziv,'UTF8') municipalityname,
              '' country,
              substr(nvl(convert ( p2.regbroj, 'UTF8' ),'NE'),0,10) vehicleregistrationnumber,
              case when p.vsdok=1 then lpad ( to_char ( targrupa ), 2, '0' ) else lpad ( nvl ( p2.sifravozila, '1' ), 2, '0' ) end vehicletypecode,
              convert(p2.marka,'UTF8') manufacturername,
              convert(p2.tip,'UTF8') ModelName,
              convert  ( nvl ( brojsasije, '1' ), 'UTF8' ) vehicleidentificationnumber,
              p2.godproizv productionyear,
              case when nvl ( p2.snagakw, 0 )>9999 then 9999 else nvl ( p2.snagakw, 0 ) end maxpower,
              --nvl ( p2.nosivostkg, 0 ) maxload,
              nvl((case when nvl(p2.nosivostkg,0)<0.5 and nvl(p2.nosivostkg,0)>0 then 1 else round(p2.nosivostkg) end),0) maxload,
              nvl ( p2.brojmesta, 0 ) seatingcapacity,
              '' vehiclepurpose,
              decode( p2.zapreminaccm,null, 0,decode(round(p2.zapreminaccm,0),0,1,round(p2.zapreminaccm,0)) ) enginecapacity,
              convert ( p2.brojmotora, 'UTF8' ) EngineNumber
                            
              from polisa p, tarifa t, polao3 p3, zastup z, tep.ddor,mesto mi,opstina o,bonus_malus bm, mesto mu, opstina ou, polao2 p2, bonus_malus bm1, cenao ca
              --,(select polisa_broj,sifra from zelkarton zk1 where sifra in (select max(zk2.sifra) from zelkarton zk2 where zk1.polisa_broj=zk2.polisa_broj )) zk
              where (p.pttm = mi.mes_sifra(+) and mi.opst = o.ops_sifra(+)) and 
              (p3.bonusmalus = bm.sifra(+)) and 
              --(zk.polisa_broj(+)=to_char(p.pol_brpol)) and
              (p.bm_prenos_procenat = bm1.sifra(+)) and
              (ca.cao_zonr(+)=p3.zonr and ca.cao_targru(+)=p3.targrupa and ca.cao_tarpgr(+)=p3.tarpodgrupa) and
              (p.pttmug=mu.mes_sifra(+) and mu.opst = ou.ops_sifra(+)) and
              (p.osig_ostali = ddor.sifra(+)) and 
              (p.mbrzastup=z.zas_sifra) and 
              (p.vros=t.tar_vros and p.tar=t.tar_tar) and 
              (p.vsdok=p3.vsdok and p.pol_brpol=p3.ao3_brpol) and
              (p.vsdok=p2.vsdok and p.pol_brpol=p2.ao2_brpol) and
              not exists  (select * from stroga s where s.str_brojdok=p.pol_brpol and s.str_vsdok=p.vsdok and s.svsprom in (22,24)) and
              p.vsdok in (1,4) 
              and p.datdok >= '01.01.2010'
              and p.datdok between p_datum_od and p_datum_do and p.azors_slanje_id is null/*and p.pol_brpol=968403 and p.vsdok=1*/
              order by p.pol_brpol||p.vsdok asc
              )
              ) loop
    gdje_je_problem:=rb.sourcepolicyidentifier;
    utl_file.put_line( fajl,'1'||delimeter||rb.rb||delimeter||rb.insurancecompanycode||delimeter||rb.sourcerecordidentifier||delimeter||rb.sourcepolicyidentifier||delimeter||rb.insurancetypecode||delimeter||rb.insurancesubtypecode
    ||delimeter||rb.premiumgroupcode||delimeter||rb.premiumsubgroupcode||delimeter||rb.basicpremiumsum||delimeter||rb.insurancepolicynumber||delimeter||rb.greencardnumber
    ||delimeter||rb.agentcode||delimeter||rb.previousinsurancecompanycode||delimeter||rb.previousinsurancepolicynumber||delimeter||rb.previousinsurancepremiumclass
    ||delimeter||rb.insurancecontractdate||delimeter||rb.insurancecontractplace||delimeter||rb.insurancestartdate||delimeter||rb.insuranceexpirydate
    ||delimeter||rb.insurancepremiumclass||delimeter||rb.insurancepremiumrate||delimeter||rb.insurancepremiumsum||delimeter||rb.insurancepremiumcurrency
    ||delimeter||rb.discountandadditions||delimeter||rb.assetinsurancesum||delimeter||rb.assetinsurancecurrency||delimeter||rb.injuryinsurancesum||delimeter||rb.injuryinsurancecurrency
    ||delimeter||rb.insurancestatuscode||delimeter||rb.insurancestatusdate||delimeter||rb.dataimportdate||delimeter||''||delimeter||rb.bonusmaluspolicynumber||delimeter||rb.bonusmalustransferred);
    
    utl_file.put_line( fajl,'2'||delimeter||rb.rb||delimeter||rb.name||delimeter||rb.typeofentity||delimeter||rb.firstname||delimeter||rb.lastname
    ||delimeter||rb.identificationnumber||delimeter||rb.taxidentificationnumber||delimeter||rb.companyregistrationnumber||delimeter||rb.housenumber||delimeter||rb.street
    ||delimeter||rb.city||delimeter||rb.postcode||delimeter||rb.municipalitycode||delimeter||rb.municipalityname||delimeter||rb.country);
    
    utl_file.put_line( fajl,'4'||delimeter||rb.rb||delimeter||rb.vehicleregistrationnumber||delimeter||rb.vehicletypecode||delimeter||rb.manufacturername
    ||delimeter||rb.modelname||delimeter||rb.vehicleidentificationnumber||delimeter||rb.productionyear||delimeter||rb.maxpower||delimeter||rb.maxload
    ||delimeter||rb.seatingcapacity||delimeter||rb.vehiclepurpose||delimeter||rb.enginecapacity||delimeter||rb.EngineNumber);
  end loop;    
 	utl_file.fclose( fajl );  
  return(broj_polisa);
exception when utl_file.invalid_path then
  return('FOPEN:invalid_path');
when utl_file.invalid_mode then
  return('FOPEN:invalid_mode');
when utl_file.invalid_operation then
  return('FOPEN:invalid_operation');
when others then
  utl_file.put_line(fajl,sqlerrm);
  utl_file.put_line(fajl,gdje_je_problem);
  return 'Problem je sledeća polisa iza '||gdje_je_problem;
  utl_file.fclose( fajl );
END AZORS_UPLOAD;

/

