create trigger TARIFA4ID_PREINS
  before insert
  on TARIFA4
  for each row
  begin
 select tarifa4seq.nextval into :new.id from dual;
end;



/

