create FUNCTION pocetno_stanje_brisi ( p_radnja number, p_vlasnik number, p_datum date ) RETURN number IS
BEGIN

 	DELETE FROM ANLANL 
	WHERE ANL_VSDOK = 301 AND
	      DATNAL = p_datum and
	 			anl_radnja = p_radnja and
	 			anl_vlasnik = p_vlasnik;

	DELETE FROM NALOG 
	WHERE NAL_VSDOK = 301 AND
	      DATNAL = p_datum  and
	 			nal_radnja = p_radnja and
	 			nal_vlasnik = p_vlasnik;
	
	COMMIT;
	RETURN 1;
exception when others then
	RETURN -1;
END;

/

