create function odbijena_steta (pid number) return varchar2 as 
  datum varchar2(10);  
begin
  for red in (select distinct(to_char(datum_statusa,'dd.mm.rrrr')) datum
              from (
              select prijstet_id id,status_stete,sta_datum_od datum_statusa from statstet where prijstet_id=pid 
              union all
              select id,status_stete,datum_statusa from prijstet where id=pid
              )
              where status_stete between 70 and 79) loop
    return red.datum;
  end loop;  
END ODBIJENA_STETA;

/

