create PROCEDURE MAC_SNIMI (p_korisnik varchar2 ,p_host varchar2,p_mac varchar2) AS 
BEGIN
  insert into mac_log (korisnik,host,mac)
  values
  (trim(p_korisnik),trim(p_host),trim(p_mac));
  commit;
END MAC_SNIMI;

/

