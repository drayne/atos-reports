create trigger VALIDACIJA_DATUMA_REZERVACIJE
  before insert
  on PRIJSTET_REZERVACIJE
  for each row
  begin
  if to_char(:new.datum_rezervacije,'ddmm') not in ('3103','3006','3108','3009','3112') then
    raise_application_error(-20000, 'Morate unijeti ispravan datum rezervacije');
  end if;
end;


/

