create PROCEDURE POSLEDNJA_PROMENA (
    l_vsdok number, l_brdok varchar2, l_svsprom out number,
 					l_dao out number, l_primio out number ) IS
BEGIN
  select svsprom, mbrzastupdaje, mbrzastupprima
	into l_svsprom, l_dao, l_primio
						             from stroga
           							where id = ( select max ( s.id )
                                 from stroga s
                                where s.str_vsdok = stroga.str_vsdok and
                                      s.str_brojdok = stroga.str_brojdok  ) and
                     					stroga.str_vsdok = l_vsdok and
                     					stroga.str_brojdok = l_brdok and --between :prvibroj and :poslednjibroj and
				                     	svsprom in ( 1, 3, 11 );
END;


/

