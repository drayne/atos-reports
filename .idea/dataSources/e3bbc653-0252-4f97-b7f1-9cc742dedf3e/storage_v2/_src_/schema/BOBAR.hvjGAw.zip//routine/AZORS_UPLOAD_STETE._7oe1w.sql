create FUNCTION         "AZORS_UPLOAD_STETE" (p_datum_od date,p_datum_do date) RETURN VARCHAR2 AS 
	fajl utl_file.file_type;
  broj_paketa varchar(6);
  broj_steta number:=0;
  kontakt   varchar(200):='zvjezdan.paravac@bobar.com';
  delimeter varchar(200):=';';
  gdje_je_problem varchar(100):='';
  --PRAGMA AUTONOMOUS_TRANSACTION;
begin
  --execute immediate 'alter session set nls_numeric_characters=''.,''';
  --redni broj paketa u tekucoj godini
  select lpad(nvl(max(to_number(substr(azors_slanje_id,instr(azors_slanje_id,'-')+1))),0)+1,6,0) into broj_paketa
  from prijstet
  where substr(azors_slanje_id,0,instr(azors_slanje_id,'-')-1)=to_char(sysdate,'rrrr');
  --ukupan broj polisa
  select count(p.id) into broj_steta              
  from prijstet p, tarifa t, polisa p1, cenao ca, polao3 p3, knjigastao kao, polao2 p2, mesto m1, opstina o1, mesto m2, opstina o2, ststete st
  where (t.tar_tar=p.tarifa and t.tar_vros=p.vros) and (p.brpolise=p1.pol_brpol and p1.vsdok=nvl(p.vsdok,1)) and (st.sts_sifra=p.status_stete)
  and (kao.prijstet_id=p.id) and (kao.pttmvozosi = m1.mes_sifra(+) and m1.opst = o1.ops_sifra(+))
  and (kao.pttmostec = m2.mes_sifra(+) and m2.opst = o2.ops_sifra(+))
  and (p1.vsdok=p3.vsdok and p1.pol_brpol=p3.ao3_brpol) and (p2.ao2_brpol=p1.pol_brpol and p2.vsdok=p1.vsdok) 
  and (ca.cao_zonr(+)=p3.zonr and ca.cao_targru(+)=p3.targrupa and ca.cao_tarpgr(+)=p3.tarpodgrupa) 
  and p.datumprijave >= '01.01.2007'
  and p.datumprijave between p_datum_od and p_datum_do and p.vros in (800) and (p.azors_slanje_id is null) --and p.id=102404
  ;
              
  fajl:= utl_file.fopen('c:\bobar\osiguranje','S-RD-7-'||to_char(sysdate,'rrrr')||'-'||broj_paketa||'.txt','W');
  utl_file.put_line( fajl,'0'||delimeter||'RD-7'||delimeter||to_char ( sysdate, 'rrrr-mm-dd' ) || 'T' || to_char ( systimestamp, 'hh24:mi:ss.ff7TZH:TZM' )||delimeter||to_char(sysdate,'rrrr')||'-'||broj_paketa||delimeter||broj_steta||delimeter||kontakt);
  for rb in (select rownum rb,id,insurancecompanycode,insurancetypecode,insurancesubtypecode,premiumgroupcode,premiumsubgroupcode,insurancepolicynumber,insurancecontractdate,
  insurancestartdate,insuranceexpirydate,Name,IdentificationNumber,VehicleRegistrationNumber,VehicleIdentificationNumber,ClaimFileCurrentYearIdentifier,CurrentYearIdentifier,ClaimFileInitiallIdentifier,
  ClaimFileInitialYear,SubClaimFileIdentifier,ClaimFileOpenedDate,IncidentDate,IncidentPlace,ClaimCause,RejectClaimDate,LegalBasisDate,InsuranceCompanyClaimRate,AppealResponseDate,
  AppealDate,AppealResolvedDate,ArchivedDate,ComplaintOpenDate,ComplaintSum,ComplaintJudgmentDate,AnalysticCard,CalculationDate,ClaimPersonSum,ClaimMaterialSum,InterestSum,OtherCostsSum,
  ClaimFileAdactaDate,ClaimReservedDate,ReservedMaterialSum,ReservedPersonSum,ReservedInterestSum,ReservedCostsSum,ClaimStatus,IsReopenedClaim,IsRedemptionClaim,IsInRentalClaim,
  IsInRegressionClaim,InternacionalClaim,AffectsBonusMalus,IsDisputeClaim,IsPoliceInvestigation,InternationalElements,Name1,TypeOfEntity1,FirstName,LastName,IdentificationNumber1,TaxIdentificationNumber1,
  CompanyIdentificationNumber1,HouseNumber,Street,City,PostCode,MunicipalityCode,MunicipalityName,Country,Name2,TypeOfEntity,FirstName1,LastName1,IdentificationNumber2,TaxIdentificationNumber,CompanyIdentificationNumber,
  HouseNumber1,Street1,City1,PostCode1,MunicipalityCode1,MunicipalityName1,Country1,VehicleRegistrationNumber1,VehicleTypeCode,ManufacturerName,ModelName,VehicleIdentificationNumber1,
  InsuranceCompanyCode1,InsuranceCompanyName
from (
select p.id,'RD-7' InsuranceCompanyCode, substr ( t.nbs, 1, 2 ) insurancetypecode, substr ( t.nbs, 3) insurancesubtypecode,
substr((case when p1.vsdok=4 and ca.sifra_azors is null then '0801' else ca.sifra_azors end),0,2) premiumgroupcode,
substr((case when p1.vsdok=4 and ca.sifra_azors is null then '0801' else ca.sifra_azors end),3,2) premiumsubgroupcode,
p1.pol_brpol/*||'-'||p.id*/ insurancepolicynumber,
to_char ( p1.datdok, 'rrrr-mm-dd' ) || 'T'||nvl(to_char(p1.vreme_izdavanja,'hh24:mi:ss'),'08:00:00')||'.0000000' || to_char ( systimestamp, 'TZH:TZM' ) insurancecontractdate,
to_char ( p1.datpoc, 'rrrr-mm-dd' ) || 'T23:59:00.0000000' || to_char ( systimestamp, 'TZH:TZM' ) insurancestartdate,
to_char ( nvl(p1.datum_prestanka_vazenja,p1.datist) , 'rrrr-mm-dd' ) || 'T23:59:00.0000000' || to_char ( systimestamp, 'TZH:TZM' ) insuranceexpirydate,
convert(p1.nazivugov,'UTF8') Name,lpad ( nvl ( p1.jmbg, '1' ), 13, '0' ) IdentificationNumber, p2.regbroj VehicleRegistrationNumber, nvl(p2.brojsasije,0) VehicleIdentificationNumber,p.prst_brstete ClaimFileCurrentYearIdentifier,
to_char(p.datumprijave,'rr') CurrentYearIdentifier, bobar.broj_stetnog_dogadjaja(p.id) ClaimFileInitiallIdentifier,
to_char(bobar.prva_prijava_stete(p.id,kao.zapisnikmupa),'rr') ClaimFileInitialYear, lpad(bobar.broj_stetnog_dogadjaja(p.id),2,'0') SubClaimFileIdentifier, to_char(p.datumprijave,'rrrr-mm-dd') ClaimFileOpenedDate,
to_char(nvl(p.datumnastanka,p.datumprijave),'rrrr-mm-dd') IncidentDate, convert(p.mestonezgode,'UTF8') IncidentPlace, '01' ClaimCause, to_char(bobar.istorija_stete(p.id,70,79),'rrrr-mm-dd') RejectClaimDate,
to_char(bobar.istorija_stete(p.id,20,39),'rrrr-mm-dd') LegalBasisDate, '0' InsuranceCompanyClaimRate, to_char(bobar.istorija_stete(p.id,60,60),'rrrr-mm-dd') AppealResponseDate, '' AppealDate, '' AppealResolvedDate,
'' ArchivedDate, '' ComplaintOpenDate, '0' ComplaintSum, '' ComplaintJudgmentDate, '' AnalysticCard, '' CalculationDate,
'' ClaimPersonSum, '' ClaimMaterialSum, '' InterestSum, '' OtherCostsSum, '' ClaimFileAdactaDate, '' ClaimReservedDate, '' ReservedMaterialSum, '' ReservedPersonSum, 
'' ReservedInterestSum, '' ReservedCostsSum,lpad( st.sifra_azors,2,'0') ClaimStatus,

(case when (bobar.istorija_stete(p.id,44,44) is not null or bobar.istorija_stete(p.id,34,34) is not null) then 'Y' else 'N' end) IsReopenedClaim,
(case when (trim(upper(kao.napomena)) like '%OTKUPLJENA%') then 'Y' else 'N' end) IsRedemptionClaim, 
(case when bobar.istorija_stete(p.id,82,82) is not null then 'Y' else 'N' end) IsInRentalClaim, 
(case when bobar.istorija_stete(p.id,89,89) is not null then 'Y' else 'N' end) IsInRegressionClaim, 
'N' InternacionalClaim, 
(case when (trim(upper(kao.napomena)) like '%OTKUPLJENA%' or bobar.istorija_stete(p.id,70,79) is not null) then 'N' else 'Y' end) AffectsBonusMalus, 
(case when bobar.istorija_stete(p.id,40,49) is not null then 'Y' else 'N' end) IsDisputeClaim, 
(case when kao.zapisnikmupa is null then 'N' else 'Y' end) IsPoliceInvestigation, 
(case when nvl(kao.drz_sifra,6)=6 then 'N' else 'Y' end) InternationalElements,



convert(kao.nazivvozosi,'UTF8') Name1,'F' TypeOfEntity1,'' FirstName,'' LastName,'' IdentificationNumber1,'' TaxIdentificationNumber1,'' CompanyIdentificationNumber1,'' HouseNumber, convert(kao.adresavozosi,'UTF8') Street,
convert(m1.mesto,'UTF8') City, o1.pttops PostCode, o1.sifra_azors MunicipalityCode, convert(o1.naziv,'UTF8') MunicipalityName, '' Country,

convert(kao.nazivostec,'UTF8') Name2, decode ( kao.sektorostec, 1, 'P', 2, 'F', 'F' )  TypeOfEntity,'' FirstName1,'' LastName1,
kao.mbrostec IdentificationNumber2,lpad(nvl(kao.mbrostec,1),13,'0')  TaxIdentificationNumber, '' CompanyIdentificationNumber, '' HouseNumber1, convert(kao.adresaostec,'UTF8') Street1,
convert(m2.mesto,'UTF8') City1,o2.pttops PostCode1, o2.sifra_azors MunicipalityCode1, convert(o2.naziv,'UTF8') MunicipalityName1, '' Country1,

substr(kao.regbrostec,0,10) VehicleRegistrationNumber1, lpad ( to_char ( kao.targrupa ), 2, '0' )  VehicleTypeCode, convert(kao.markaostec,'UTF8') ManufacturerName,
convert( kao.tipostec ,'UTF8') ModelName, nvl(kao.sasija,0) VehicleIdentificationNumber1, '' InsuranceCompanyCode1, '' InsuranceCompanyName


from prijstet p, tarifa t, polisa p1, cenao ca, polao3 p3, knjigastao kao, polao2 p2, mesto m1, opstina o1, mesto m2, opstina o2, ststete st
where (t.tar_tar=p.tarifa and t.tar_vros=p.vros) and (p.brpolise=p1.pol_brpol and p1.vsdok=nvl(p.vsdok,1)) and (st.sts_sifra=p.status_stete)
and (kao.prijstet_id=p.id) and (kao.pttmvozosi = m1.mes_sifra(+) and m1.opst = o1.ops_sifra(+))
and (kao.pttmostec = m2.mes_sifra(+) and m2.opst = o2.ops_sifra(+))
and (p1.vsdok=p3.vsdok and p1.pol_brpol=p3.ao3_brpol) and (p2.ao2_brpol=p1.pol_brpol and p2.vsdok=p1.vsdok) 
and (ca.cao_zonr(+)=p3.zonr and ca.cao_targru(+)=p3.targrupa and ca.cao_tarpgr(+)=p3.tarpodgrupa) 
and p.datumprijave >= '01.01.2007'
and p.datumprijave between p_datum_od and p_datum_do and p.vros in (800) and (p.azors_slanje_id is null) --and p.id=102404
order by p.id asc              )
              ) loop
    gdje_je_problem:=rb.id;
    utl_file.put_line( fajl,'1'||delimeter||rb.rb||delimeter||rb.insurancecompanycode||delimeter||rb.insurancetypecode||delimeter||rb.insurancesubtypecode||delimeter||rb.premiumgroupcode
    ||delimeter||rb.premiumsubgroupcode||delimeter||rb.insurancepolicynumber||delimeter||rb.insurancecontractdate||delimeter||rb.insurancestartdate||delimeter||rb.insuranceexpirydate
    ||delimeter||rb.Name||delimeter||rb.IdentificationNumber||delimeter||rb.VehicleRegistrationNumber||delimeter||rb.VehicleIdentificationNumber||delimeter||rb.ClaimFileCurrentYearIdentifier||delimeter||rb.CurrentYearIdentifier
    ||delimeter||rb.ClaimFileInitiallIdentifier||delimeter||rb.ClaimFileInitialYear||delimeter||rb.SubClaimFileIdentifier||delimeter||rb.ClaimFileOpenedDate||delimeter||rb.IncidentDate
    ||delimeter||rb.IncidentPlace||delimeter||rb.ClaimCause||delimeter||rb.RejectClaimDate||delimeter||rb.LegalBasisDate||delimeter||rb.InsuranceCompanyClaimRate||delimeter||rb.AppealResponseDate
    ||delimeter||rb.AppealDate||delimeter||rb.AppealResolvedDate||delimeter||rb.ArchivedDate||delimeter||rb.ComplaintOpenDate||delimeter||rb.ComplaintSum||delimeter||rb.ComplaintJudgmentDate
    ||delimeter||rb.AnalysticCard||delimeter||rb.CalculationDate||delimeter||rb.ClaimPersonSum||delimeter||rb.ClaimMaterialSum||delimeter||rb.InterestSum||delimeter||rb.OtherCostsSum
    ||delimeter||rb.ClaimFileAdactaDate||delimeter||rb.ClaimReservedDate||delimeter||rb.ReservedMaterialSum||delimeter||rb.ReservedPersonSum||delimeter||rb.ReservedInterestSum
    ||delimeter||rb.ReservedCostsSum||delimeter||rb.ClaimStatus||delimeter||rb.IsReopenedClaim||delimeter||rb.IsRedemptionClaim||delimeter||rb.IsInRentalClaim||delimeter||rb.IsInRegressionClaim
    ||delimeter||rb.InternacionalClaim||delimeter||rb.AffectsBonusMalus||delimeter||rb.IsDisputeClaim||delimeter||rb.IsPoliceInvestigation||delimeter||rb.InternationalElements);
    
    utl_file.put_line( fajl,'2'||delimeter||rb.rb||delimeter||rb.Name1||delimeter||rb.TypeOfEntity1||delimeter||rb.FirstName||delimeter||rb.LastName||delimeter||rb.IdentificationNumber1||delimeter||rb.TaxIdentificationNumber1||delimeter||rb.CompanyIdentificationNumber1||delimeter||rb.HouseNumber
    ||delimeter||rb.Street||delimeter||rb.City||delimeter||rb.PostCode||delimeter||rb.MunicipalityCode||delimeter||rb.MunicipalityName||delimeter||rb.Country);
    
    utl_file.put_line( fajl,'3'||delimeter||rb.rb||delimeter||rb.Name2||delimeter||rb.TypeOfEntity||delimeter||rb.FirstName1||delimeter||rb.LastName1||delimeter||rb.IdentificationNumber2
    ||delimeter||rb.TaxIdentificationNumber||delimeter||rb.CompanyIdentificationNumber||delimeter||rb.HouseNumber1||delimeter||rb.Street1||delimeter||rb.City1
    ||delimeter||rb.PostCode1||delimeter||rb.MunicipalityCode1||delimeter||rb.MunicipalityName1||delimeter||rb.Country1);
    
    utl_file.put_line( fajl,'4'||delimeter||rb.rb||delimeter||rb.VehicleRegistrationNumber1||delimeter||rb.VehicleTypeCode||delimeter||rb.ManufacturerName
    ||delimeter||rb.ModelName||delimeter||rb.VehicleIdentificationNumber1||delimeter||rb.InsuranceCompanyCode1||delimeter||rb.InsuranceCompanyName);
    
  end loop;    
 	utl_file.fclose( fajl );  
  return(broj_steta);
exception when utl_file.invalid_path then
  return('FOPEN:invalid_path');
when utl_file.invalid_mode then
  return('FOPEN:invalid_mode');
when utl_file.invalid_operation then
  return('FOPEN:invalid_operation');
when others then
  utl_file.put_line(fajl,sqlerrm);
  utl_file.put_line(fajl,gdje_je_problem);
  return 'Problem je sledeća polisa iza '||gdje_je_problem;
  utl_file.fclose( fajl );
END AZORS_UPLOAD_STETE;

/

