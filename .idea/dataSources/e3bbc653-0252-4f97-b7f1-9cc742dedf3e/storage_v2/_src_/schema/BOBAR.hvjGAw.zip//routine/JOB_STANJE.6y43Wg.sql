create procedure job_stanje as 
prod  number:=0;
data  number:=0;
begin
    select count(vsdok) into prod from bobar.polisa;
    select count(vsdok) into data from bobar.polisa@database;
    if prod<>data then
        for red in (select 'ANLANL: PROD '||(select count(anl_vsdok) from bobar.anlanl)||' DB '||(select count(anl_vsdok) from bobar.anlanl@database) 
            ||'     POLISA: PROD '||(select count(vsdok) from bobar.polisa)||' DB '||(select count(vsdok) from bobar.polisa@database) 
            ||'     STROGA: PROD '||(select count(str_vsdok) from bobar.stroga)||' DB '||(select count(str_vsdok) from bobar.stroga@database) stanje
          from dual) loop
            bobar.posalji_sms('066903255',red.stanje);
         end loop;
   end if;
   exception
   when others then
    bobar.posalji_sms('066903255','Greška!');
end JOB_STANJE;

/

