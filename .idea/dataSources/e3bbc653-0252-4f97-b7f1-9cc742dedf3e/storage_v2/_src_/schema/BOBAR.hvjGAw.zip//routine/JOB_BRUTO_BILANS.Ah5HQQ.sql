create PROCEDURE JOB_BRUTO_BILANS AS 
BEGIN
  for red in (
            SELECT anlanl.anl_radnja,
            SUM(ANLANL.DEV_DUGUJE),
            SUM(ANLANL.DEV_POTRAZUJE),
            SUM(ANLANL.DEV_DUGUJE - ANLANL.DEV_POTRAZUJE) suma
            FROM KONTO, ANLANL
            WHERE (ANLANL.KONTO = KONTO.KON_SIFRA
            AND 2 = KONTO.KON_OJ)
            --AND ANLANL.ANL_RADNJA = :P_PREDUZECE 
            -- AND TO_DATE(:P_DATUMOD) <= --TO_DATE(ANLANL.DATDOK)
            -- AND TO_DATE(:P_DATUMDO) >= --TO_DATE(ANLANL.DATDOK) 
             AND TRUNC( ANLANL.DATDOK ) BETWEEN to_date('01.01.'||to_char(sysdate,'rrrr'),'dd.mm.rrrr') AND sysdate-1
             and anlanl.konto between '0' and '9999999999'
            GROUP BY ANLANL.anl_radnja
            having SUM(ANLANL.DEV_DUGUJE - ANLANL.DEV_POTRAZUJE)<>0
            ) loop
  posalji_sms('065850120','Na dan '||to_char(sysdate-1,'dd.mm.rrrr')||', za preduzece '||red.anl_radnja||' bruto bilans se ne slaze za '||red.suma|| ' KM');
  posalji_sms('066903255','Na dan '||to_char(sysdate-1,'dd.mm.rrrr')||', za preduzece '||red.anl_radnja||' bruto bilans se ne slaze za '||red.suma|| ' KM');
end loop;
END JOB_BRUTO_BILANS;

/

