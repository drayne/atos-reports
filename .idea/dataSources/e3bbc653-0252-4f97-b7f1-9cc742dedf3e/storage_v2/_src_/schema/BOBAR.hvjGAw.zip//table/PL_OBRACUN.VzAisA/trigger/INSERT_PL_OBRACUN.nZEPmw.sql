create trigger INSERT_PL_OBRACUN
  before insert
  on PL_OBRACUN
  for each row
  BEGIN
  insert into pl_obracun_porezi 
  
  (select :new.firma, :new.radnik, :new.rbob, :new.mjesec, :new.godina, p.id porez_sifra, p.procenat procenat, 
round(case when upper(trim(p.porez))='D' then (:new.bruto-nvl(:new.OSLOBODJENI_IZNOS,0)-(select sum(p.procenat*:new.bruto/100) 
from pl_porezi p, pl_radnici r
where r.id=:new.radnik and upper(p.porez)<>'D'))*p.procenat/100 else p.procenat*:new.bruto/100 end,2) iznos, 
case when upper(p.porez)='D' then r.opstina_por else r.opstina_fzo end opstina, null as nalog,
:new.operater_unosa,sysdate,case when upper(trim(p.porez))='D' then round(nvl(:new.OSLOBODJENI_IZNOS,0)*p.procenat/100,2) else 0 end ,
:new.vrsta_sati
from pl_porezi p, pl_radnici r
where r.id=:new.radnik and trim(upper(p.aktivan))='D');
END;


/

