create PACKAGE BODY                             "PK_EL_NALOG" 
    is
  function formiraj_el_nalog ( p_el_nal_id number ) return number is
    l_output        utl_file.file_type;
    l_log						utl_file.file_type;
    l_cnt number := 0;
    cursor l_cur is select * 
                      from elektronski_nalozi_stavke
                     where el_nal_id = p_el_nal_id;
    l_naziv_uplatilac orgjed.naziv%type;
    l_mesto_uplatilac mesto.mesto%type;
    l_ziro_racun_uplatilac orgjed.ziror%type;
    l_nalog_iznos number;
    l_nalog_broj_stavki number;
    l_broj_naloga number;
  begin

    select elektronski_nalozi.broj_naloga
      into l_broj_naloga
      from elektronski_nalozi
     where id = p_el_nal_id;
     
    l_output := utl_file.fopen( 'EL_NALOG', 'UvozVirmana' || l_broj_naloga || '.txt', 'w' );
    l_log := utl_file.fopen( 'EL_NALOG', 'UvozVirmana' || l_broj_naloga || '.log', 'w' );

    begin
      select upper ( orgjed.naziv ), 
             upper ( mesto.mesto ), 
             orgjed.ziror
        into l_naziv_uplatilac,
             l_mesto_uplatilac,
             l_ziro_racun_uplatilac
        from orgjed,
             mesto,
             elektronski_nalozi
       where orgjed.pttm = mesto.mes_sifra
         and elektronski_nalozi.vlasnik = orgjed.oj_sifra
         and elektronski_nalozi.radnja = orgjed.firma
         and elektronski_nalozi.id = p_el_nal_id;
    exception 
      when no_data_found then
        utl_file.put_line ( l_log, 'Ne postoje uneti podaci o uplatiocu u šifarniku organizacionih delova.' );
        utl_file.fclose( l_output );
        utl_file.fclose( l_log );
        return l_cnt;
      when too_many_rows then
        utl_file.put_line ( l_log, 'Neispravno uneti podaci za uplatioca u šifarniku organizacionih delova.' );
        utl_file.fclose( l_output );
        utl_file.fclose( l_log );
        return l_cnt;
    end;

    begin
      select ltrim ( rtrim ( to_char ( sum ( iznos ), '999999990D00' ) ) ), 
             ltrim ( rtrim ( to_char ( count ( * ) ) ) )
        into   l_nalog_iznos
             , l_nalog_broj_stavki
        from elektronski_nalozi_stavke
       where el_nal_id = p_el_nal_id;
    exception when no_data_found then
      utl_file.put_line ( l_log, 'Ne postoje stavke elektronskog naloga.' );
      utl_file.fclose( l_output );
      utl_file.fclose( l_log );
      return l_cnt;
    end;      
        
/* Adresna stavka */    
    utl_file.put ( l_output, rpad ( ltrim ( rtrim ( l_ziro_racun_uplatilac ) ), 18, ' ' ) );
    utl_file.put ( l_output, rpad ( ltrim ( rtrim ( l_naziv_uplatilac ) ), 35, ' ' ) );
    utl_file.put ( l_output, rpad ( ltrim ( rtrim ( l_mesto_uplatilac ) ), 10, ' ' ) );
    utl_file.put ( l_output, rpad ( ' ', 6, ' ' ) );
    utl_file.put ( l_output, rpad ( ' ', 254, ' ' ) );
    utl_file.put ( l_output, 'MULTI E-BANK' );
    utl_file.put ( l_output, '1' );
    utl_file.put ( l_output, chr (10) );
/* Sabirna stavka */    
    utl_file.put ( l_output, rpad ( ltrim ( rtrim ( l_ziro_racun_uplatilac ) ), 18, ' ' ) );
    utl_file.put ( l_output, rpad ( ltrim ( rtrim ( l_naziv_uplatilac ) ), 35, ' ' ) );
    utl_file.put ( l_output, rpad ( ltrim ( rtrim ( l_mesto_uplatilac ) ), 10, ' ' ) );
    utl_file.put ( l_output, lpad ( substr ( l_nalog_iznos, 1, instr ( l_nalog_iznos, ',' ) - 1 ), 13, '0' ) );
    utl_file.put ( l_output, substr ( l_nalog_iznos, instr ( l_nalog_iznos, ',' ) + 1 ) );
    utl_file.put ( l_output, lpad ( l_nalog_broj_stavki, 5, '0' ) );
    utl_file.put ( l_output, rpad ( ' ', 252, ' ' ) );
    utl_file.put ( l_output, '9' );
    utl_file.put ( l_output, chr (10) );
/* Individualne stavke */    
    for cur_rec in l_cur loop
      utl_file.put ( l_output, rpad ( ltrim ( rtrim ( cur_rec.broj_racuna_primaoca ) ), 18, ' ' ) );
      utl_file.put ( l_output, rpad ( ltrim ( rtrim ( cur_rec.naziv_primaoca ) ), 35, ' ' ) );
      utl_file.put ( l_output, rpad ( ltrim ( rtrim ( cur_rec.mesto_primaoca ) ), 10, ' ' ) );
      utl_file.put ( l_output, '0' );
      utl_file.put ( l_output, lpad ( nvl ( ltrim ( rtrim ( cur_rec.model_zaduzenja ) ), ' ' ), 2, '0' ) );
      utl_file.put ( l_output, rpad ( nvl ( ltrim ( rtrim ( cur_rec.poziv_zaduzenja ) ), ' ' ), 22, ' ' ) );
      utl_file.put ( l_output, rpad ( nvl ( ltrim ( rtrim ( cur_rec.svrha_placanja ) ), ' ' ), 140, ' ' ) );
      utl_file.put ( l_output, '00000' );
      utl_file.put ( l_output, ' ' );
      utl_file.put ( l_output, nvl ( cur_rec.oblik_placanja1, '2' ) );
      utl_file.put ( l_output, lpad ( nvl ( cur_rec.sifra_placanja, '10' ), 2, '0' ) );
      utl_file.put ( l_output, nvl ( cur_rec.oblik_placanja2, '1' ) );
      utl_file.put ( l_output, ' ' );
      utl_file.put ( l_output, lpad ( substr ( ltrim ( rtrim ( to_char ( cur_rec.iznos, '999999990D00' ) ) ), 1, instr ( ltrim ( rtrim ( to_char ( cur_rec.iznos, '999999990D00' ) ) ), ',' ) - 1 ), 11, '0' ) );
      utl_file.put ( l_output, substr ( ltrim ( rtrim ( to_char ( cur_rec.iznos, '999999990D00' ) ) ), instr ( ltrim ( rtrim (  to_char ( cur_rec.iznos, '999999990D00' ) ) ), ',' ) + 1 ) );
      utl_file.put ( l_output, lpad ( nvl ( ltrim ( rtrim ( cur_rec.model_odobrenja ) ), ' ' ), 2, '0' ) );
      utl_file.put ( l_output, rpad ( nvl ( ltrim ( rtrim ( cur_rec.poziv_odobrenja ) ), ' ' ), 22, ' ' ) );
      utl_file.put ( l_output, nvl ( to_char ( cur_rec.datum_valute, 'DDMMRR' ), '      ' ) );
      utl_file.put ( l_output, nvl ( cur_rec.tip_dokumenta, '0' ) );
      utl_file.put ( l_output, rpad ( ' ', 52, ' ' ) );
      utl_file.put ( l_output, '1' );
      utl_file.put ( l_output, chr (10) );
      l_cnt := l_cnt + 1;
    end loop;       

    utl_file.put ( l_output, chr (13) || chr (10) );
    utl_file.fclose( l_output );
    utl_file.fclose( l_log );
    return l_cnt;
  exception when others then
    utl_file.fclose( l_output );
--    utl_file.put_line( l_log, sqlerrm );
    utl_file.fclose( l_log );
    return l_cnt;
  end;
end;
/

