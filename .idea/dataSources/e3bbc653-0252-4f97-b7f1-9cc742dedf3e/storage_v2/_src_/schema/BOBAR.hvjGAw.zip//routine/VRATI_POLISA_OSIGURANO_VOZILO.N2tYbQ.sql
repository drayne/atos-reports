create FUNCTION       "VRATI_POLISA_OSIGURANO_VOZILO" (p_polisa in number) RETURN VARCHAR2  AS 
r_podaci varchar2(64);
BEGIN

    select 
                 CASE
                WHEN  (select T.NAZIV  from targru t  where T.TGR_VROS=800  and T.TGR_TARGRU=P3.TARGRUPA)  = 'PUTNICKA VOZILA'    THEN 'Putničko'
                WHEN  (select T.NAZIV  from targru t  where T.TGR_VROS=800  and T.TGR_TARGRU=P3.TARGRUPA)  = 'TERETNA VOZILA'    THEN 'Teretno'
                WHEN  (select T.NAZIV  from targru t  where T.TGR_VROS=800  and T.TGR_TARGRU=P3.TARGRUPA)  = 'MOTOCIKLI'    THEN 'Motocikl'
                WHEN  (select T.NAZIV  from targru t  where T.TGR_VROS=800  and T.TGR_TARGRU=P3.TARGRUPA)  = 'PRIKLJUCNA VOZILA'    THEN 'Priključno'
                WHEN  (select T.NAZIV  from targru t  where T.TGR_VROS=800  and T.TGR_TARGRU=P3.TARGRUPA)  = 'RADNA VOZILA'    THEN 'Radno'
                WHEN  (select T.NAZIV  from targru t  where T.TGR_VROS=800  and T.TGR_TARGRU=P3.TARGRUPA)  = 'VUCNA VOZILA'    THEN 'Vučno'
                WHEN  (select T.NAZIV  from targru t  where T.TGR_VROS=800  and T.TGR_TARGRU=P3.TARGRUPA)  = 'SPECIJALNA VOZILA'    THEN 'Specijalno'
                WHEN  (select T.NAZIV  from targru t  where T.TGR_VROS=800  and T.TGR_TARGRU=P3.TARGRUPA)  = 'AUTOBUSI'    THEN 'Autobus'
                ELSE   (select T.NAZIV  from targru t  where T.TGR_VROS=800  and T.TGR_TARGRU=P3.TARGRUPA)
              END  
            ||' - ' ||
              p2.MARKA 
              ||' - ' ||
              CASE
                WHEN p2.tip IS NULL
                THEN p2.model
                ELSE p2.TIP
                  || ' '
                  || p2.MODEL
              END
    into r_podaci
    from polisa p, polao2 p2, polao3 p3
    where P.POL_BRPOL= p_polisa
    and P3.AO3_BRPOL=P.POL_BRPOL
    and P2.AO2_BRPOL=P.POL_BRPOL;
    
    return r_podaci;
  
 exception
        when NO_DATA_FOUND    then return 0;     
  
END;

/

