create function f_pozitivno(p_val in number) return number is
begin
  if p_val < 0 then
    return null;
  else
    return p_val;
  end if;
end;


/

