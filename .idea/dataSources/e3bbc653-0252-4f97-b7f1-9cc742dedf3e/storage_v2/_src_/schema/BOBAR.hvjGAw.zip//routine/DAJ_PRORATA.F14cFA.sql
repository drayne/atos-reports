create PROCEDURE DAJ_PRORATA (
                        p_brojdana in     number,
                        p_PROCENAT in out number,
                        p_rezultat in out number
                                             ) IS
w_PROCENAT NUMBER(17,7);

BEGIN
   p_rezultat := 99;
   p_procenat := 0;

      if P_brojdana = 0 then
         p_rezultat := 71;
         p_pROCENAT := 0;
/*
                                    broj dana ne može biti nula
*/
      ELSE

         if P_brojdana > 364 then
            p_rezultat := 0;
            P_procenat := 100;
         else
            W_PROCENAT := ROUND(((P_BROJDANA * 100 )/ 365), 7);
            if nvl(w_procenat, 0) = 0 then
               p_rezultat := 61;
               p_PROCENAT := 0;
/*
                                      nije prona?en PROCENAT za proRATA OBRA?UN KRATKORO?NE PREMIJE
*/
            else
               p_PROCENAT := W_PROCENAT;
               P_REZULTAT := 0;
            end if;
         end if;
      end if;
END;

/

