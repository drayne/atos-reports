create FUNCTION       vrati_jmbg_komitenta (p_sifra in number default 0) RETURN VARCHAR2 AS 
r_jmbg_komitenta varchar2(20);
BEGIN
  select nvl(matbr,1) into r_jmbg_komitenta from komitent where kom_sifra = p_sifra ;
  return r_jmbg_komitenta;
 exception
        when NO_DATA_FOUND    then return ' ';     
  
END;

/

