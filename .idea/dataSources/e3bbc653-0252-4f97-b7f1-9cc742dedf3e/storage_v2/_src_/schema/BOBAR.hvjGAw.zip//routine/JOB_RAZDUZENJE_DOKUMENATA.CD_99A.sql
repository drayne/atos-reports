create PROCEDURE JOB_RAZDUZENJE_DOKUMENATA AS
BEGIN
  for red in (select * from zelkarton where
to_char(datdok,'rrrr')>='2008'
and not EXISTS (select str_vsdok from stroga where str_vsdok=2 
and str_brojdok=zelkarton.sifra and svsprom in (21,22,23,24))) loop
														insert into stroga (str_vsdok, 
			                       str_brojdok,
			                       str_datumpromene,
			                       str_rednibroj,
			                       mbrzastupprima,
			                       mbrzastupdaje,
			                       svsprom,
			                       brojreversa,
			                       opisreversa,
			                       datumobrade,
			                       sifoperat 
			                       )
		          	   values ( 2,
		          	            red.sifra,
			                      red.datdok, 
			                      4,
			                      red.mbrzastup,
			                      null,
			                      21, 
			                      0,
			                      '_',
			                      sysdate,
			                      'sit'
			                      );  
                            posalji_sms('066903255','Razdužen ZK broj: '||red.sifra);
			                      commit;
			                      /*set_alert_property ( 'alert1', alert_message_text, 'Dokument je razdužen!');
														alert_id := show_alert ( 'alert1' );*/
													end loop;
END JOB_RAZDUZENJE_DOKUMENATA;

/

