create PACKAGE BRANA_STETE_TXT IS
       IZLAZ utl_file.FILE_TYPE;
       ulaz2 utl_file.file_type;
       logfl utl_file.FILE_TYPE;
       komad varchar2(1022);
       komad2 varchar2(1022);
       EOF boolean;
       greska varchar2(1024);
       linija number;
       PROCEDURE logit(st number, en number);
       PROCEDURE logit(ms varchar2);
       Function c_numb(u_str varchar2) return number;
       Function c_date(u_str varchar2, u_fm varchar2) return date;
       procedure brana_STETE_TXT (put_do_fajla varchar2, P_KONTO_OD VARCHAR2, P_KONTO_DO VARCHAR2, DATUM_OD DATE, DATUM_DO DATE);
END;


/

