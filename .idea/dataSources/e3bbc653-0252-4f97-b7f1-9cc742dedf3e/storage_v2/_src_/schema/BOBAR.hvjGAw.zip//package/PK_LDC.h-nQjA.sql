create package pk_ldc as
/******************************************************************************
   name:       pk_ldc
   purpose:    paket sadrzi funkcije i procedure koje se odnose na plate

******************************************************************************/

  /*
    Obracun plate za jednog radnika i jedan obracun.
    U parametru p_obracun je potrebno zadati sledeca polja:
    1. obr_vlasnik
    2. obr_lokacija
    3. obr_godina
    4. obr_mesec
    5. obr_broj
  */
  procedure p_obracun_radnika(p_obracun in tldc_obracun%rowtype, p_rad_sifra in tldc_radnik.rad_sifra%type);

  /*
    Obracun plata svih radnika za jedan obracun.
    U parametru p_obracun je potrebno zadati sledeca polja:
    1. obr_vlasnik
    2. obr_lokacija
    3. obr_godina
    4. obr_mesec
    5. obr_broj
  */
  procedure p_obracun(p_obracun in tldc_obracun%rowtype);

  /*
    Preuzimanje podataka iz prethodnog obracuna za jednog radnika
  */
  procedure p_preth_obracun_radnika(p_obracun in tldc_obracun%rowtype, p_rad_sifra in tldc_radnik.rad_sifra%type, p_operater in varchar2);

  /*
    Preuzimanje podataka iz prethodnog obracuna za sve radnike
  */
  procedure p_preth_obracun(p_obracun in tldc_obracun%rowtype, p_operater in varchar2);

  /*
    Dodavanje obustava u karticu obustava
  */
  procedure p_obustave_radnika(p_obracun in tldc_obracun%rowtype, p_rad_sifra in tldc_radnik.rad_sifra%type, p_operater in varchar2);

  /*
  	Kreiranje OD obrazca
  */
  procedure p_od_obrazac(p_obracun in tldc_obracun%rowtype);

end pk_ldc;


/

