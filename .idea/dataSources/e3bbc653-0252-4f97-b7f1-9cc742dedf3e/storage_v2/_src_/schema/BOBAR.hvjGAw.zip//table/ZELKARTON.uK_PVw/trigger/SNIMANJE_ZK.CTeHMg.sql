create trigger SNIMANJE_ZK
  before insert or update
  on ZELKARTON
  for each row
  declare 
privilegija number:=0;
nesto       number:=0;
datum       date;
zastupnik   number:=0;
zadnji_zk number:=0;
begin
  -- U slucaju da je slucajno unesen broj OSK obrasca
  if INSERTING then
    :new.brosk:=null;  
  end if;

  -- datum isteka mora biti veći od datuma početka
  if :new.datum_pocetka>=:new.datum_isteka then
    raise_application_error(-20000, 'Datum počeka mora biti manji od datuma isteka!');
  end if;
  -- za istog zastupnika ZK se unose hronološki
    for red5 in ( select * from parametri
                  where lower(trim(naziv))='hronoloski_unos_dse' and trim(lower(vrijednost))='1'
                  and not exists (select * from dse_izuzetci where vsdok=:new.vsdok and brojdok=:new.sifra )
                  ) loop
      if INSERTING then
        select nvl(max(sifra),0) into zadnji_zk
        from zelkarton
        where mbrzastup=:new.mbrzastup
        and (sifra) not in (select brojdok from dse_izuzetci where vsdok=:new.vsdok);
        if zadnji_zk>=:new.sifra then
          RAISE_APPLICATION_ERROR(-20000, 'Postoji ZK '||zadnji_zk||' koji je veći nego '||:new.sifra||' kojeg pokušavate da snimite!');
        end if;
      end if;    
    end loop;
  -- promjene koje nastaju u strogoj moraju biti datumski hronološki redane
  --if INSERTING then
    select nvl(max (str_datumpromene),sysdate) into datum
    from stroga 
    where str_vsdok=:new.vsdok and str_brojdok=:new.sifra;
    if to_char(datum,'rrrrmmdd')>to_char(:new.datdok,'rrrrmmdd') then
      RAISE_APPLICATION_ERROR(-20000, 'Prethodna promjena za dokument '||:new.vsdok||'/'||:new.sifra
      ||' je sa vecim datumom nego ovaj '||to_char(:new.datdok,'dd.mm.rrrr'));
    end if;
  --end if;
  -- promjene koje nastaju u strogoj moraju biti hronološki redane po zastupnicima
  --if INSERTING then
    select mbrzastupprima into zastupnik from stroga s
    where s.id=(select max(ss.id) from stroga ss where s.str_vsdok=ss.str_vsdok and s.str_brojdok=ss.str_brojdok)
    and str_vsdok=:new.vsdok and str_brojdok=:new.sifra;
    if zastupnik<>:new.mbrzastup then
      RAISE_APPLICATION_ERROR(-20000, 'Prethodna promjena za dokument '||:new.vsdok||'/'||:new.sifra
      ||' je na drugom zastupniku!');
    end if;
  --end if;
  -- provjera da li je zastupnik aktivan ili ne
  for red in (select * from zastup where zas_sifra in (:new.mbrzastup)) loop
   if red.aktivan=0 then
    RAISE_APPLICATION_ERROR(-20000, 'Zastupnik '|| :new.mbrzastup||'-'||red.naziv||' je neaktivan!'); 
   end if;   
  end loop;
  
  -- provjera da li je šifra privilegije = 1, ako jeste to znači da ne može snimati promjene  
  select count(zastupnik) into privilegija from operater o where trim(o.korisnik)=trim(:new.sifoperat)
  and nvl(o.zastupnik,0)=1;
  if privilegija = 1 then
    raise_application_error(-20000, 'Za operatera '||:new.sifoperat||' nije dozvoljeno razduzivanje zastupnika '||:new.mbrzastup||' !');
  end if;
  privilegija:=0;
  
  -- provjera da li operater može da razduži zasstupnika
  select count(zastupnik) into privilegija from operater o where trim(o.korisnik)=trim(:new.sifoperat)
  and nvl(o.zastupnik,0)<>0;
  if --:new.svsprom in (1,11,21,22,23,24) and
  privilegija>0 then  
    select count(*) into nesto from operater o, zastup_grupe zg
    where o.zastupnik=zg.grp_zastup 
    and trim(o.korisnik)=trim(:new.sifoperat) 
    and decode(nvl(zg.koga,0),99999,nvl(:new.mbrzastup,0),nvl(zg.koga,0))=nvl(:new.mbrzastup,0)  
    and 21 = zg.sta;
    if nesto=0 then
      raise_application_error(-20000, 'Za operatera '||:new.sifoperat||' nije dozvoljeno razduzivanje zastupnika '||:new.mbrzastup||' !'); 
    end if;
  end if;
  
  --duzina nazivugov ne smije biti veca od 40 karaktera zbog Biroa ZK
  if  length(:new.nazivugov)>40 then
    raise_application_error(-20000, 'Naziv ugovaraca ne smije biti veci od 40 karaktera!'); 
  end if;
  
  
  
  /*exception
  when others then
    RAISE_APPLICATION_ERROR(-20000, 'Greška prilikom određivanja privilegije za operatera '||:new.sifoperat);*/
end;


/

