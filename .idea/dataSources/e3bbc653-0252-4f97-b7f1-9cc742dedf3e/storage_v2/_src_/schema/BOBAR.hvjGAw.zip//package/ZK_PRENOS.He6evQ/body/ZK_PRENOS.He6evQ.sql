create PACKAGE BODY ZK_PRENOS
    is
  Function c_date(u_str varchar2, u_fm varchar2) return date is
 i date;
 u varchar2(1022);
begin
 greska := null;
 u :=ltrim(rtrim(u_str));
 if (length(u) is null) then
  return null;
 end if;
 i := to_date(u_str,u_fm);
 return i;
 exception when others then
  greska := sqlerrm;
  logit('>'||u_str||'< ' || greska);
  return null;
end;
Function c_numb(u_str varchar2) return number is
 i number;
 u varchar2(1022);
begin
 greska := null;
 u := ltrim(rtrim(u_str));
 if ((length(u) is null) or (u = '.')) then
  return null;
 end if;
 i := to_number(u_str);
 return i;
exception when others then
  greska := sqlerrm;
  logit('>'||u_str||'< ' || greska);
  return null;
end;
PROCEDURE logit(st number, en number) is
begin
 utl_file.put_line(logfl,to_char(linija,'09999')||':'||substr(komad,st,en) || ':');
 utl_file.put_line(logfl,greska);
end;
procedure logit(ms varchar2) is
begin
 utl_file.put_line(logfl,to_char(linija,'09999')||':'|| ms);
end;
------------------------------------------------------------------------------------------------
PROCEDURE prenos (put_do_fajla varchar2) IS
 pol zk_radna%ROWTYPE;
 nastavi boolean := TRUE;
 postoji number;
 za_brisanje boolean := false;
 br_upisanih number;
 postoje_obrisani number := 0;
 upisani_radna number := 0;
 update_radna number := 0;
 upisan number := 0;
 zk_upis boolean := false;
 vraca_zastup number;
 vraca_oj number;
 prov_vraca number;
 CURSOR zk_prenos IS select * from zk_radna where upisano = 'N';
BEGIN
 EOF:=FALSE;
 dbms_output.enable(100000);
 begin
  ulaz := utl_file.fopen(put_do_fajla,'zelkar.dat','r');
  logfl:= utl_file.fopen(put_do_fajla,'zelkar.log','w');
  logit('otvoren.');
 exception when utl_file.invalid_path then
  logit('FOPEN:invalid_path');
 when utl_file.invalid_mode then
  logit('FOPEN:invalid_mode');
 when utl_file.invalid_operation then
  logit('FOPEN:invalid_operation');
 end;
 if (utl_file.is_open(ulaz)) then
   logit('citam...');
   br_upisanih := 0;
   loop
     begin
       	utl_file.get_line(ulaz,komad);
				pol.sifra   			:= ltrim(rtrim(substr(komad,1,11)));
				pol.polisa_broj		:= ltrim(rtrim(substr(komad,12,11)));

				if pol.polisa_broj = 0 then
					 pol.polisa_broj := null;
				end if;

				pol.datum_pocetka := c_date ( ltrim(rtrim(substr(komad,23,8))), 'rrrrmmdd' );
				pol.datum_isteka  := c_date ( ltrim(rtrim(substr(komad,31,8))), 'rrrrmmdd' );
				pol.reg_broj			:= ltrim(rtrim(substr(komad,39,25)));
				pol.marka					:= ltrim(rtrim(substr(komad,64,25)));
				pol.tip           := ltrim(rtrim(substr(komad,89,25)));
				pol.model         := ltrim(rtrim(substr(komad,114,25)));
				pol.NAZIVUGOV     := ltrim(rtrim(substr(komad,139,50)));
				pol.mesto         := ltrim(rtrim(substr(komad,189,50)));
				pol.ADRESA        := ltrim(rtrim(substr(komad,239,50)));
				pol.datumobrade   := c_date ( ltrim(rtrim(substr(komad,289,8))), 'rrrrmmdd' );
				pol.sifoperat     := ltrim(rtrim(substr(komad,297,8)));
				pol.oj          	:= ltrim(rtrim(substr(komad,305,13)));
				pol.mbrzastup     := ltrim(rtrim(substr(komad,318,13)));
				pol.premzk        := ltrim(rtrim(substr(komad,331,17)));
				pol.pttmug        := ltrim(rtrim(substr(komad,348,10)));
				pol.datdok	      := c_date ( ltrim(rtrim(substr(komad,358,8))), 'rrrrmmdd' );
				pol.stroga        := ltrim(rtrim(substr(komad,366,1)));
				pol.VROS					:= ltrim(rtrim(substr(komad,367,5)));
				pol.VSDOK         := ltrim(rtrim(substr(komad,372,5)));


	      select count(*) into postoji from zk_radna where sifra = pol.sifra;
  	    if postoji = 0 then
    	    insert into zk_radna ( SIFRA, POLISA_BROJ, DATUM_POCETKA, DATUM_ISTEKA,
 					   REG_BROJ, MARKA, TIP, MODEL, NAZIVUGOV, MESTO,
 					   ADRESA, DATUMOBRADE, SIFOPERAT, OJ, MBRZASTUP,
 					   PREMZK, PTTMUG, DATDOK, STROGA, VROS, VSDOK, upisano, datumrada )
				values ( pol.SIFRA, pol.POLISA_BROJ, pol.DATUM_POCETKA, pol.DATUM_ISTEKA,
 			   		   yu852lat ( pol.REG_BROJ ), yu852lat ( pol.MARKA ), yu852lat ( pol.TIP ),
 					   yu852lat ( pol.MODEL ), yu852lat ( pol.NAZIVUGOV ), yu852lat ( pol.MESTO ),
 					   yu852lat ( pol.ADRESA ), pol.DATUMOBRADE, pol.SIFOPERAT, pol.OJ, pol.MBRZASTUP,
 					   pol.PREMZK, pol.PTTMUG, pol.DATDOK, pol.STROGA, pol.VROS, pol.VSDOK, 'N', sysdate );
      	  if sql%found then
	            upisan := upisan + 1;
	        	upisani_radna := upisani_radna + 1;
	    	  end if;
       elsif postoji > 0 then
        	update zk_radna set SIFRA = pol.SIFRA,
        	                    POLISA_BROJ = pol.POLISA_BROJ,
        	                    DATUM_POCETKA = pol.DATUM_POCETKA,
        	                    DATUM_ISTEKA = pol.DATUM_ISTEKA,
 		  			  REG_BROJ = yu852lat ( pol.REG_BROJ ),
 					  MARKA = yu852lat ( pol.MARKA ),
 					  TIP = yu852lat ( pol.TIP ),
 					  MODEL = yu852lat ( pol.MODEL ),
 					  NAZIVUGOV = yu852lat ( pol.NAZIVUGOV ),
 					  MESTO = yu852lat ( pol.MESTO ),
 					  ADRESA = yu852lat ( pol.ADRESA ),
 					  DATUMOBRADE = pol.DATUMOBRADE,
 					  SIFOPERAT = pol.SIFOPERAT,
 					  OJ = pol.OJ,
 					  MBRZASTUP = pol.MBRZASTUP,
 					  PREMZK = pol.PREMZK,
 					  PTTMUG = pol.PTTMUG,
 					  DATDOK = pol.DATDOK,
 					  STROGA = pol.STROGA,
 					  VROS = pol.VROS,
 					  VSDOK = pol.VSDOK,
 					  datumrada = sysdate
					  where sifra = pol.sifra and
					  upisano	= 'N';
         	if sql%found then
            upisan := upisan + 1;
					 	update_radna := update_radna + 1;
         	end if;
      	end if;
--				if upisan > 20 then
					commit;
--					upisan := 0;
--				end if;
     exception
     	when no_data_found then EOF := TRUE;
     	when others then
       logit ( sqlerrm || ' ' ||pol.sifra);
   	 end;
     exit when EOF;
	 end loop;
 else
   logit ( 'FGETLINE:Nije otvoren file' );
 end if;
 commit;
 utl_file.fclose ( ulaz );
 for cur_rec in zk_prenos loop

			begin
    	    insert into zelkarton ( SIFRA, POLISA_BROJ, DATUM_POCETKA, DATUM_ISTEKA,
 					    REG_BROJ, MARKA, TIP, MODEL, NAZIVUGOV, MESTO,
 					    ADRESA, DATUMOBRADE, SIFOPERAT, OJ, MBRZASTUP,
 					    PREMZK, PTTMUG, DATDOK, STROGA, VROS, VSDOK, BROSK )
				 values ( cur_rec.SIFRA, cur_rec.POLISA_BROJ, cur_rec.DATUM_POCETKA, cur_rec.DATUM_ISTEKA,
 					    yu852lat ( cur_rec.REG_BROJ ), yu852lat ( cur_rec.MARKA ), yu852lat ( cur_rec.TIP ),
 					    yu852lat ( cur_rec.MODEL ), yu852lat ( cur_rec.NAZIVUGOV ), yu852lat ( cur_rec.MESTO ),
 					    yu852lat ( cur_rec.ADRESA ), cur_rec.DATUMOBRADE, cur_rec.SIFOPERAT, cur_rec.OJ, cur_rec.MBRZASTUP,
 					   cur_rec.PREMZK, cur_rec.PTTMUG, cur_rec.DATDOK, cur_rec.STROGA, cur_rec.VROS, cur_rec.VSDOK, to_char ( cur_rec.MBRZASTUP ) || to_char ( cur_rec.DATDOK, 'rrrrmmdd' ) );
          zk_upis := true;
			exception when others then
          if sqlcode <> -1 then
            logit( 'Ne postoji polisa broj ' || cur_rec.polisa_broj || ' u tabeli polisa za zeleni karton broj ' || cur_rec.sifra ||' !' );
          else
            za_brisanje := true;
          end if;
          zk_upis := false;
			end;

      if zk_upis then

					prov_vraca := prov_dokument ( cur_rec.vsdok,
					                              cur_rec.sifra,
					                              vraca_zastup,
					                              vraca_oj );

		      if cur_rec.mbrzastup = vraca_zastup and cur_rec.oj = vraca_oj then

				     update zk_radna set upisano = 'D' where sifra = cur_rec.sifra;

     			   if prov_vraca = 0 then
--     			   if prov_vraca = 0 or prov_vraca = 5 then
			          insert into stroga (str_vsdok,
			                       str_brojdok,
			                       str_datumpromene,
			                       str_rednibroj,
			                       mbrzastupprima,
			                       mbrzastupdaje,
			                       svsprom,
			                       brojreversa,
			                       opisreversa,
			                       datumobrade,
			                       sifoperat
			                       )
		          	   values ( cur_rec.vsdok,
		          	            cur_rec.sifra,
			                      cur_rec.datdok,
			                      4,
			                      cur_rec.mbrzastup,
			                      null,
			                      21,
			                      null,
			                      null,
			                      sysdate,
			                      user
			                      );
              end if;

       	     commit;
       	     br_upisanih := br_upisanih + 1;

		      else

			    	logit( 'Nije saglasno sa strogom evidencijom! Zastupnik:' || to_char ( cur_rec.mbrzastup ) ||
    	       ' ; OJ:' || to_char ( cur_rec.oj ) || ' ' ||cur_rec.sifra);
						rollback;

					end if;

      else
       	rollback;
      end if;

      if za_brisanje then
        delete from zk_radna where sifra = cur_rec.sifra;
        commit;
        postoje_obrisani := postoje_obrisani + 1;
        za_brisanje := false;
      end if;

 end loop;
 delete from zk_radna where upisano='D';
 commit;
--finalize

 logit( 'zatvoren.' );
 logit( 'Upisano novih slogova u radnu tabelu: ' || to_char( upisani_radna ) || ' zapisa!' );
 logit( 'Izmenjeno slogova u radnoj tabeli: ' || to_char ( update_radna ) || ' zapisa!' );
 logit( 'Upisano u tabelu zelkarton: ' || to_char ( br_upisanih ) || ' zapisa!' );
 logit( 'Nije upisano u tabelu zelkarton zato sto vec postoji: ' || to_char ( postoje_obrisani ) || ' zapisa!' );
 utl_file.fclose(logfl);
exception when others then
 utl_file.fclose_all;
 raise;
END;

PROCEDURE zk (put_do_fajla varchar2) IS
 pol zk_radna%ROWTYPE;
 nastavi boolean := TRUE;
 postoji number;
 za_brisanje boolean := false;
 br_upisanih number;
 postoje_obrisani number := 0;
 upisani_radna number := 0;
 update_radna number := 0;
 upisan number := 0;
 zk_upis boolean := false;
 vraca_zastup number;
 vraca_oj number;
 prov_vraca number;
 l_zk varchar2(20);
BEGIN
 EOF:=FALSE;
 dbms_output.enable(100000);
 begin
  ulaz := utl_file.fopen(put_do_fajla,'zk.prn','r');
--  logit('otvoren.');
 exception when utl_file.invalid_path then
  logit('FOPEN:invalid_path');
 when utl_file.invalid_mode then
  logit('FOPEN:invalid_mode');
 when utl_file.invalid_operation then
  logit('FOPEN:invalid_operation');
 end;
 if (utl_file.is_open(ulaz)) then
--   logit('citam...');
   br_upisanih := 0;
   loop
     begin
       	utl_file.get_line(ulaz,komad);
				l_zk := ltrim(rtrim(substr(komad,1,8)));
    insert into zk_biro values ( l_zk );
     exception
     	when no_data_found then EOF := TRUE;
     	when others then
--       logit ( sqlerrm || ' ' ||pol.sifra);
  null; 	 end;
     exit when EOF;
	 end loop;
 end if;
 commit;
 utl_file.fclose ( ulaz );
exception when others then
 utl_file.fclose (ulaz);
 raise;
END;

END;
/

