create trigger TLDC_KAOB_AIUDR
  after insert or update or delete
  on TLDC_KARTICAOBUSTAVA
  for each row
  declare

  r_obustava tldc_obustava%rowtype;

begin

  select *
    into r_obustava
    from tldc_obustava
   where obu_radnik = nvl(:new.kob_radnik, :old.kob_radnik)
     and obu_rbr = nvl(:new.kob_rbr, :old.kob_rbr);

  if r_obustava.brojrata is not null then
    /*
      azuriranje ostatka duga u tabeli tldc_obustava
    */
    r_obustava.ostatakduga := r_obustava.ostatakduga - nvl(:new.iznos, 0) + nvl(:old.iznos, 0);
    if r_obustava.ostatakduga = 0 then
      r_obustava.status := null;
    else
      r_obustava.status := 'X';
    end if;
    update tldc_obustava
       set ostatakduga = r_obustava.ostatakduga,
           status      = r_obustava.status
     where obu_radnik = nvl(:new.kob_radnik, :old.kob_radnik)
       and obu_rbr    = nvl(:new.kob_rbr, :old.kob_rbr);
  end if;

end;



/

