create view POLISE_FEDERACIJA_VW as
  select polisa."POL_BRPOL",polisa."OJ",polisa."BROSK",polisa."ZAMPOL",polisa."STATUS",polisa."VROS",polisa."VSDOK",polisa."PTTM",polisa."SEKTOR",polisa."DATPOC",polisa."DATIST",polisa."DATDOK",polisa."DATPRIP",polisa."PREMIJA",polisa."IZNPOREZ",polisa."UKPREMIJA",polisa."IZNODM",polisa."BRRATA",polisa."NAP1",polisa."NAP2",polisa."NAP3",polisa."NAP4",polisa."MBRZASTUP",polisa."VRSTAPLAC",polisa."JMBG",polisa."NAZIVUGOV",polisa."PTTMUG",polisa."ADRESA",polisa."OSTALAADRESA",polisa."DATUMOBRADE",polisa."SIFOPERAT",polisa."LISTPOKR",polisa."OSNPOL",polisa."SIFOSIG",polisa."PTTMOSIG",polisa."KLOPAS",polisa."KLOPP",polisa."KLZM",polisa."NACOS",polisa."TRAJOS",polisa."DATDOS",polisa."BROJ_PASOSA",polisa."ZEMLJA_PASOSA",polisa."TAR",polisa."GRA_KAT",polisa."SIF_DEL",polisa."STAT_BR",polisa."NAZIVOSIG",polisa."IZNPOREZ0",polisa."KORISNIKSMRT",polisa."STROGA",polisa."PASOS",polisa."DATROD",polisa."BIRO_DATUM",polisa."DATUM_PLACANJA",polisa."MBR",polisa."DEL_KASKO_RBR",polisa."LOM_STAKLA_RBR",polisa."KOMADA",polisa."BROJTEL",polisa."BROJ_ZK",polisa."DATPOC_VREME",polisa."DATIST_VREME",polisa."E_MAIL",polisa."TELEFON_MOBILNI",polisa."MESTOUG_GRAN",polisa."ZA_STORNIRANJE",polisa."NAZIV_FORME",polisa."BRPOL_OSTALI",polisa."OSIG_OSTALI",polisa."AZORS_SLANJE_ID",polisa."BM_PRENOS_POLISA",polisa."BM_PRENOS_PROCENAT",polisa."BM_PRENOS_OSIG_KUCA",polisa."TEGLJAC",polisa."VREME_IZDAVANJA",polisa."DATUM_PRESTANKA_VAZENJA",polisa."LICNA_KARTA",polisa."IZNOS_POPUSTA",polisa."ZIRO_RACUN",polisa."NAZIV_BANKE",polisa."POL",polisa."BRACNI_STATUS",polisa."DATUM_VOZACKE"
from polisa , polao3
where POLISA.POL_BRPOL = POLAO3.AO3_BRPOL
and POLAO3.ZONR=3


/

