create FUNCTION PROVERI_DOZVOLA_KNJIZENJA ( p_datum date ) RETURN VARCHAR2 AS
  l_broj number;
BEGIN
  select count(*) 
    into l_broj
    from periodi_knjizenja
   where to_char ( p_datum, 'rrrrmmdd' ) between
            to_char ( periodi_knjizenja.datum_od, 'rrrrmmdd' ) and
            to_char ( periodi_knjizenja.datum_do, 'rrrrmmdd' ) and 
            nvl ( zakljucan, 8 ) = 0;
  if l_broj = 1 then
    RETURN 'TRUE';
  else
    RETURN 'FALSE';
  end if;  
END PROVERI_DOZVOLA_KNJIZENJA;

/

