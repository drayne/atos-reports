create PROCEDURE          "LOSESTETE"   IS
 cursor cur is select prijstet_id,
                      sta_rednibroj,
                      sta_datum,
                      status_stete
                 from statstet
             group by prijstet_id,
                      sta_rednibroj,
                      sta_datum,
                      status_stete;
 old_id statstet.prijstet_id%type := 0;
 old_rednibroj statstet.sta_rednibroj%type := 0;
 old_datum statstet.sta_datum%type := to_date ( '010170','ddmmrr' );
 old_status statstet.status_stete%type := 0;
 lose boolean := false;
 ispao boolean := false;
 datum_prijstet date;
BEGIN
  for cur_rec in cur loop
   if cur_rec.prijstet_id = old_id then
     if not ispao then
      if old_datum <= cur_rec.sta_datum then
        if old_rednibroj < cur_rec.sta_rednibroj then
        if old_status >= cur_rec.status_stete then
            lose := true;
       end if;
       else
          lose := true;
       end if;
        else
         lose := true;
       end if;
      end if;
    end if;
    if lose then
      ispao := true;
    insert into lose_stete ( prijstet_id, status_istorija, sta_rednibroj, sta_datum, broj_stete,
                             godina_stete, datumobracuna, status_stete )
                           ( select prijstet_id, statstet.status_stete, sta_rednibroj,
                                    sta_datum, prst_brstete, prst_godina, datumobracuna,
                                    prijstet.status_stete
                               from statstet, prijstet
                              where id = cur_rec.prijstet_id and
                                    id = statstet.prijstet_id );
    commit;
    else
     ispao := false;
    end if;
    lose := false;
   old_id := cur_rec.prijstet_id;
   old_rednibroj := cur_rec.sta_rednibroj;
   old_datum := cur_rec.sta_datum;
   old_status := cur_rec.status_stete;
  end loop;
  insert into lose_stete ( prijstet_id, status_istorija, sta_rednibroj, sta_datum, broj_stete,
                             godina_stete, datumobracuna, status_stete )
                       ( select statstet.prijstet_id, statstet.status_stete, sta_rednibroj,
                                sta_datum, prst_brstete, prst_godina, datumobracuna,
                                prijstet.status_stete
                           from statstet,
                                prijstet,
                                ( select prijstet_id
                                    from prijstet,statstet
                                     where id = prijstet_id and
                                           sta_rednibroj = ( select max(sta_rednibroj)
                                                               from statstet
                                                              where prijstet_id = id ) and
                                           to_char ( datumobracuna, 'rrrrmmdd' ) <> to_char ( sta_datum, 'rrrrmmdd' ) and
                                           not exists ( select *
                                                          from lose_stete
                                                         where lose_stete.prijstet_id = prijstet.id )) lose
                            where statstet.prijstet_id = lose.prijstet_id and
                                  statstet.prijstet_id = prijstet.id );

END;

/

