create trigger DOP_RIZ2ID_PREINS
  before insert
  on DOP_RIZ2
  for each row
  begin
 select dop_riz2seq.nextval into :new.id from dual;
end;



/

