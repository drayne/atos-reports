create PROCEDURE IZVRSI_DDL (p_command IN varchar)
 AS 
BEGIN
  execute immediate p_command;  
END IZVRSI_DDL;

/

