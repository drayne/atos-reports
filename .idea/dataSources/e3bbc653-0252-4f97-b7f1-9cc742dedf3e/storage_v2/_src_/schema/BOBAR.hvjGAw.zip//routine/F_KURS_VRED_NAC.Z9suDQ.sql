create function f_kurs_vred_nac(
  p_datum      in date,
  p_vrkursa    in kurs.vrsta%type,
  p_nac_valuta in kurs.valuta%type,
  p_valuta     in kurs.valuta%type
) return number as
  l_kurs number default 1.0;
  l_nac  valute.nac%type;
begin
  if p_valuta != p_nac_valuta then
    select kurs3/za
      into l_kurs
      from kurs
     where datum = (select max(datum)
                      from kurs
                     where trunc(datum) <= trunc(p_datum)
                       and vrsta  = p_vrkursa
                       and valuta = p_valuta)
       and vrsta  = p_vrkursa
       and valuta = p_valuta;
  end if;
  return l_kurs;
exception
  when others then return 1.0;
end;


/

