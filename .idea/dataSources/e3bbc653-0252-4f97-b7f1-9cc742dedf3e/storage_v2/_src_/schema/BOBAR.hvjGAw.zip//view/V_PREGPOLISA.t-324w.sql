create view V_PREGPOLISA as
  select
  pol.pol_brpol pol_brpol,
  pol.vsdok vsdok,
  pol.vros vros,
  pol.datdok datdok,
  dug.duguje - pot.potrazuje saldo,
  pol.nazivugov ime,
  pol.mbrzastup mbrzastup
from polisa pol,
(select   pol_brpol, sum(dev_duguje) duguje
 from     anlanl
 where    datdok < sysdate
 group by pol_brpol) dug,
(select   pol_brpol, sum(dev_potrazuje) potrazuje
 from     anlanl
 group by pol_brpol) pot
where pol.pol_brpol = dug.pol_brpol
  and pol.pol_brpol = pot.pol_brpol
  and dug.duguje - pot.potrazuje > 0


/

