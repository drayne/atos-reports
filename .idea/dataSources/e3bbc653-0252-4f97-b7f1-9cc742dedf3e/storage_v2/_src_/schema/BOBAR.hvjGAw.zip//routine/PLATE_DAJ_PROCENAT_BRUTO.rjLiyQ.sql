create FUNCTION PLATE_DAJ_PROCENAT_BRUTO (godina in number ,mjesec in number) RETURN number AS 
 gm varchar(6):=godina||mjesec;
begin
for redi in (select procenat from pl_procenat_bruto 
where datum_vazenja in (select max(datum_vazenja) from pl_procenat_bruto where to_char(datum_vazenja,'rrrrmm') <= gm)
) loop
 return redi.procenat;
end loop;
  return 0;
END PLATE_DAJ_PROCENAT_BRUTO;

/

