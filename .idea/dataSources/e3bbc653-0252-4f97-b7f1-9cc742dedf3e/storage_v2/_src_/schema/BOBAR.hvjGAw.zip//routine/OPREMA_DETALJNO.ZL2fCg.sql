create FUNCTION         "OPREMA_DETALJNO" (broj number) RETURN VARCHAR2 AS
  naziv varchar (2000):='';
BEGIN
  for red in (
  select 
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='monitor_proizvodjac' and s.id=o.monitor_proizvodjac) as monitor_proizvodjac,
o.monitor_model as monitor_model,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='monitor_tip' and s.id=o.monitor_tip) as monitor_tip,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='monitor_velicina' and s.id=o.monitor_velicina) as monitor_velicina,
o.monitor_napomena, 
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='stampac_proizvodjac' and s.id=o.stampac_proizvodjac) as stampac_proizvodjac,
o.stampac_model as stampac_model,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='stampac_tip' and s.id=o.stampac_tip) as stampac_tip,
o.stampac_napomena, 
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_procesor_proizvodjac' and s.id=o.racunar_procesor_proizvodjac) as racunar_procesor_proizvodjac,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_procesor_tip' and s.id=o.racunar_procesor_tip) as racunar_procesor_tip,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_procesor_brzina' and s.id=o.racunar_procesor_brzina) as racunar_procesor_brzina,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_hard_disk_proizvodjac' and s.id=o.racunar_hard_disk_proizvodjac) as racunar_hard_disk_proizvodjac,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_hard_disk_tip' and s.id=o.racunar_hard_disk_tip) as racunar_hard_disk_tip,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_hard_disk_velicina' and s.id=o.racunar_hard_disk_velicina) as racunar_hard_disk_velicina,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_hard_disk_brzina' and s.id=o.racunar_hard_disk_brzina) as racunar_hard_disk_brzina,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_memorija_proizvodjac' and s.id=o.racunar_memorija_proizvodjac) as racunar_memorija_proizvodjac,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_memorija_tip' and s.id=o.racunar_memorija_tip) as racunar_memorija_tip,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_memorija_velicina' and s.id=o.racunar_memorija_velicina) as racunar_memorija_velicina,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_opticki_proizvodjac' and s.id=o.racunar_opticki_proizvodjac) as racunar_opticki_proizvodjac,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_opticki_tip' and s.id=o.racunar_opticki_tip) as racunar_opticki_tip,
(select s.naziv from inv_vrsta_sifrarnika vs, inv_sifrarnik s 
where vs.id= s.id_vrsta and lower(vs.naziv)='racunar_opticki_brzina' and s.id=o.racunar_opticki_brzina) as racunar_opticki_brzina,
racunar_napomena
from inv_oprema o 
where o.id=broj
  ) loop
  return trim(nvl(red.monitor_proizvodjac,'')||' '||nvl(red.monitor_model,'')||' '||nvl(red.monitor_tip,'')||' '||nvl(red.monitor_velicina,'')||' '||nvl(red.monitor_napomena,'')||' '||
  nvl(red.stampac_proizvodjac,'')||' '||nvl(red.stampac_model,'')||' '||nvl(red.stampac_tip,'')||' '||nvl(red.stampac_napomena,'')||' '||
  nvl(red.racunar_procesor_proizvodjac,'')||' '||nvl(red.racunar_procesor_tip,'')||' '||nvl(red.racunar_procesor_brzina,'')||' '||
  nvl(red.racunar_hard_disk_proizvodjac,'')||' '||nvl(red.racunar_hard_disk_tip,'')||' '||nvl(red.racunar_hard_disk_velicina,'')||' '||nvl(red.racunar_hard_disk_brzina,'')||' '||
  nvl(red.racunar_memorija_proizvodjac,'')||' '||nvl(red.racunar_memorija_tip,'')||' '||nvl(red.racunar_memorija_velicina,'')||' '||
  nvl(red.racunar_opticki_proizvodjac,'')||' '||nvl(red.racunar_opticki_tip,'')||' '||nvl(red.racunar_opticki_brzina,''));
  end loop;
  return naziv;
END OPREMA_DETALJNO;

/

