create PROCEDURE       job_IMPORT_KNJIGA_ST_MATRICA AS 
  p_upisano number:=0;
  p_poruka  varchar2(200);
  ima       number:=0;
  datoteka  varchar2(200):='KNJIGA_STETNIKA_IMPORT_MATRICA_ZA_' ||to_number(to_char((add_months(sysdate,-1)),'mm'))||'_'||to_number(to_char((add_months(sysdate,-1)),'rrrr'));
begin
if to_number(to_char(sysdate,'dd'))>=5 then
  select count(*) into ima 
  from import_knjiga_matrica
  where nvl(importovan,0)>0 and lower(trim(naziv_fajla))=lower(trim(datoteka))||'.csv';
  if ima=0 then
    bobar.IMP_KNJIGA_STETNIKA (
    datoteka, 'C:\BOBAR\OSIGURANJE',';', p_upisano, p_poruka );
    insert into import_knjiga_matrica (naziv_fajla,importovan,poruka) values (datoteka||'.csv',nvl(p_upisano,0),p_poruka);
    commit;
    posalji_sms('066903255',datoteka||'.csv Upisano slogova: '||p_upisano||' Poruka: '||p_poruka);
  if nvl(p_upisano,0)>0 then
   for redd in (select * from TEP.sms_telefoni
  where lower(trim(vrsta))='knjiga_stetnika'
  and prikaz=1
  order by id asc) loop
  posalji_sms(redd.broj,'Obavještavamo Vas da možete preuzeti ukupnu knjigu štetnika za '|| to_number(to_char((add_months(sysdate,-1)),'mm')) ||'. mjesec. Bobar osiguranje.');
  end loop;
  end if;
   end if;
  end if; 
  exception
    when others then 
      posalji_sms('066903255','Greška prilikom importa '||datoteka||'.csv '||p_poruka);
END job_IMPORT_KNJIGA_ST_MATRICA;

/

