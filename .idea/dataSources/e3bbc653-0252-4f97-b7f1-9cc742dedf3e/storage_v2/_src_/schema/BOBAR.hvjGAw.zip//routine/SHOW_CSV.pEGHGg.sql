create function       SHOW_CSV( p_query     in varchar2,
                                      p_separator in varchar2 default ',',
                                      p_dir       in varchar2 ,
                                      p_filename  in varchar2 )
return number
AUTHID CURRENT_USER
is
    l_output        utl_file.file_type;
    l_log             utl_file.file_type;
    l_theCursor     integer default dbms_sql.open_cursor;
    l_columnValue   varchar2(4000);
    l_status        integer;
    l_colCnt        number default 0;
    l_separator     varchar2(10) default '';
    l_desc_tab  DBMS_SQL.desc_tab;
    l_col_cnt   INTEGER;
    l_cnt           number default 0;
begin

    execute immediate 'alter session set nls_date_format=''dd.mm.rrrr''';
    execute immediate 'alter session set nls_numeric_characters=''.,''';
       
    l_output := utl_file.fopen( p_dir, p_filename, 'w' );
    l_log := utl_file.fopen( p_dir, p_filename || '.log', 'w' );
        --utl_file.put_line( l_log, p_query );
        utl_file.put_line( l_log, 'Start...' );

    dbms_sql.parse(  l_theCursor,  p_query, dbms_sql.native );
    utl_file.put_line( l_log, '1' );

DBMS_SQL.describe_columns (l_theCursor, l_col_cnt, l_desc_tab);

  -- Output the column names.
  FOR i IN 1 .. l_col_cnt LOOP
    IF i > 1 THEN
      UTL_FILE.put(l_output, p_separator);
    END IF;
    UTL_FILE.put(l_output, l_desc_tab(i).col_name);
  END LOOP;
  UTL_FILE.new_line(l_output);        

    for i in 1 .. 255 loop
        begin
            dbms_sql.define_column( l_theCursor, i, l_columnValue, 4000 );
            l_colCnt := i;
        exception
            when others then
                if ( sqlcode = -1007 ) then exit;
                else
                    raise;
                end if;
        end;
    end loop;
    utl_file.put_line( l_log, '2' );

    dbms_sql.define_column( l_theCursor, 1, l_columnValue, 4000 );

    l_status := dbms_sql.execute(l_theCursor);
    utl_file.put_line( l_log, '3' );

    loop
        exit when ( dbms_sql.fetch_rows(l_theCursor) <= 0 );
        l_separator := '';
        for i in 1 .. l_colCnt loop
            dbms_sql.column_value( l_theCursor, i, l_columnValue );
            utl_file.put( l_output, l_separator || l_columnValue );
            l_separator := p_separator;
        end loop;
        utl_file.new_line( l_output );
        l_cnt := l_cnt+1;
    end loop;
    dbms_sql.close_cursor(l_theCursor);

    utl_file.put_line( l_log, 'Finish!' );

    utl_file.fclose( l_output );
    utl_file.fclose( l_log );
    return l_cnt;

   exception when others then
       utl_file.fclose( l_output );
       utl_file.put_line( l_log, sqlerrm || l_columnvalue );
       utl_file.fclose( l_log );
       return l_cnt;

end SHOW_CSV;

/

