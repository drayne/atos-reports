create FUNCTION yusciilat(p_yuscii varchar2) RETURN VARCHAR2 IS
yuscii varchar2(250) := 'ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^¦Ń abcdefghijklmnopqrstuvwxyz{~`}|_-"0123456789!#$%&*()+=<>,.';
la_s varchar2(250) :=   'ABCDEFGHIJKLMNOPQRSTUVWXYZŠĆČŽĐ abcdefghijklmnopqrstuvwxyzščžđ _-"0123456789!#$%&*()+=<>,.';
BEGIN 
 return translate(p_yuscii,  yuscii, la_s);  
END;

/

