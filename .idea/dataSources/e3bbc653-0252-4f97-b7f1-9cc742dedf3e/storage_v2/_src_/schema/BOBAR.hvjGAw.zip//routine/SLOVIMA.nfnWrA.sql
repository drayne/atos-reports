create FUNCTION         "SLOVIMA" (brojka in number) RETURN VARCHAR2 AS 
slova_stotine   varchar(2000):='';
slova_hiljade   varchar(2000):='';
slova_milioni   varchar(2000):='';
slova_milijarde varchar(2000):='';
stotina_opis    varchar(200):=null;
hiljada_opis    varchar(200):=null;
milion_opis     varchar(200):=null;
milijarda_opis  varchar(200):=null;
p_broj          varchar(2000):='';
p_decimale      varchar(200):='';
BEGIN
  if instr(trim(to_char(brojka)),',')>0 then
    p_broj:=substr(trim(to_char(brojka)),0,instr(trim(to_char(brojka)),',')-1);
    p_decimale:=(case when substr(trim(to_char(brojka)),0,instr(trim(to_char(brojka)),',')-1)>0 then ' i ' else '' end)||substr(trim(to_char(brojka)),instr(trim(to_char(brojka)),',')+1,2)||'/100';
    stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  else
    p_broj:=trim(to_char(brojka));
  end if;
  -- jedinice stotine
  case 
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-1,1)='1' then slova_stotine := 'jedna';stotina_opis:=nvl(stotina_opis,' konvertibilna marka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-1,1)='2' then slova_stotine := 'dvije';stotina_opis:=nvl(stotina_opis,' konvertibilne marke');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-1,1)='3' then slova_stotine := 'tri';stotina_opis:=nvl(stotina_opis,' konvertibilne marke');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-1,1)='4' then slova_stotine := 'četiri';stotina_opis:=nvl(stotina_opis,' konvertibilne marke');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-1,1)='5' then slova_stotine := 'pet';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-1,1)='6' then slova_stotine := 'šest';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-1,1)='7' then slova_stotine := 'sedam';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-1,1)='8' then slova_stotine := 'osam';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-1,1)='9' then slova_stotine := 'devet';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  else slova_stotine:='';
  end case;
  --desetice stotine
  case 
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,1)='1' then case
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,2)='10' then slova_stotine := 'deset';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,2)='11' then slova_stotine := 'jedanaest';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,2)='12' then slova_stotine := 'dvanaest';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,2)='13' then slova_stotine := 'trinaest';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,2)='14' then slova_stotine := 'četrnaest';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,2)='15' then slova_stotine := 'petnaest';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,2)='16' then slova_stotine := 'šestnaest';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,2)='17' then slova_stotine := 'sedamnaest';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,2)='18' then slova_stotine := 'osamnaest';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,2)='19' then slova_stotine := 'devetnaest';stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
                                                                                   else slova_stotine:='';
                                                                                   end case;
  
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,1)='2' then slova_stotine := 'dvadeset' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,1)='3' then slova_stotine := 'trideset' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,1)='4' then slova_stotine := 'četrdeset' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,1)='5' then slova_stotine := 'pedeset' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,1)='6' then slova_stotine := 'šezdeset' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,1)='7' then slova_stotine := 'sedamdeset' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,1)='8' then slova_stotine := 'osamdeset' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-2,1)='9' then slova_stotine := 'devedeset' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  else slova_stotine:='' || slova_stotine;
  end case;
  -- stotice stotine
  case 
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-3,1)='1' then slova_stotine := 'sto' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-3,1)='2' then slova_stotine := 'dvijestotine' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-3,1)='3' then slova_stotine := 'tristotine' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-3,1)='4' then slova_stotine := 'četiristotine' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-3,1)='5' then slova_stotine := 'petstotina' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-3,1)='6' then slova_stotine := 'šeststotina' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-3,1)='7' then slova_stotine := 'sedamstotina' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-3,1)='8' then slova_stotine := 'osamstotina' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-3,1)='9' then slova_stotine := 'devetstotina' || slova_stotine;stotina_opis:=nvl(stotina_opis,' konvertibilnih maraka');
  else slova_stotine:='' || slova_stotine;
  end case;
  -- jedinice hiljade
  case 
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-4,1)='1' then slova_hiljade := 'jedna'; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-4,1)='2' then slova_hiljade := 'dvije'; hiljada_opis:=nvl(hiljada_opis,'hiljade');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-4,1)='3' then slova_hiljade := 'tri' ; hiljada_opis:=nvl(hiljada_opis,'hiljade');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-4,1)='4' then slova_hiljade := 'četiri' ; hiljada_opis:=nvl(hiljada_opis,'hiljade');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-4,1)='5' then slova_hiljade := 'pet' ; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-4,1)='6' then slova_hiljade := 'šest' ; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-4,1)='7' then slova_hiljade := 'sedam' ; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-4,1)='8' then slova_hiljade := 'osam' ; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-4,1)='9' then slova_hiljade := 'devet' ; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  else slova_hiljade:='';
  end case;
  --desetice hiljade
  case 
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,1)='1' then case
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,2)='11' then slova_hiljade := 'jedanaest' ;hiljada_opis:=nvl(hiljada_opis,'hiljada');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,2)='12' then slova_hiljade := 'dvanaest' ;hiljada_opis:=nvl(hiljada_opis,'hiljada');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,2)='13' then slova_hiljade := 'trinaest' ;hiljada_opis:=nvl(hiljada_opis,'hiljada');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,2)='14' then slova_hiljade := 'četrnaest' ;hiljada_opis:=nvl(hiljada_opis,'hiljada');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,2)='15' then slova_hiljade := 'petnaest' ;hiljada_opis:=nvl(hiljada_opis,'hiljada');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,2)='16' then slova_hiljade := 'šestnaest' ;hiljada_opis:=nvl(hiljada_opis,'hiljada');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,2)='17' then slova_hiljade := 'sedamnaest' ;hiljada_opis:=nvl(hiljada_opis,'hiljada');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,2)='18' then slova_hiljade := 'osamnaest' ;hiljada_opis:=nvl(hiljada_opis,'hiljada');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,2)='19' then slova_hiljade := 'devetnaest' ;hiljada_opis:=nvl(hiljada_opis,'hiljada');
                                                                                   else slova_hiljade:='';
                                                                                   end case;
  
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,1)='2' then slova_hiljade := 'dvadeset' || slova_hiljade; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,1)='3' then slova_hiljade := 'trideset' || slova_hiljade; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,1)='4' then slova_hiljade := 'četrdeset' || slova_hiljade; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,1)='5' then slova_hiljade := 'pedeset' || slova_hiljade; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,1)='6' then slova_hiljade := 'šezdeset' || slova_hiljade; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,1)='7' then slova_hiljade := 'sedamdeset' || slova_hiljade; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,1)='8' then slova_hiljade := 'osamdeset' || slova_hiljade; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-5,1)='9' then slova_hiljade := 'devedeset' || slova_hiljade; hiljada_opis:=nvl(hiljada_opis,'hiljada');
  else slova_hiljade:='' || slova_hiljade;
  end case;
  -- stotice hiljade
  case 
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-6,1)='1' then slova_hiljade := 'sto' || slova_hiljade;hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-6,1)='2' then slova_hiljade := 'dvijestotine' || slova_hiljade;hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-6,1)='3' then slova_hiljade := 'tristotine' || slova_hiljade;hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-6,1)='4' then slova_hiljade := 'četiristotine' || slova_hiljade;hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-6,1)='5' then slova_hiljade := 'petstotina' || slova_hiljade;hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-6,1)='6' then slova_hiljade := 'šeststotina' || slova_hiljade;hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-6,1)='7' then slova_hiljade := 'sedamstotina' || slova_hiljade;hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-6,1)='8' then slova_hiljade := 'osamstotina' || slova_hiljade;hiljada_opis:=nvl(hiljada_opis,'hiljada');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-6,1)='9' then slova_hiljade := 'devetstotina' || slova_hiljade;hiljada_opis:=nvl(hiljada_opis,'hiljada');
  else slova_hiljade:='' || slova_hiljade;
  end case;

  -- jedinice milioni
  case 
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-7,1)='1' then slova_milioni := 'jedan'; milion_opis:=nvl(milion_opis,'milion');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-7,1)='2' then slova_milioni := 'dva'; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-7,1)='3' then slova_milioni := 'tri' ; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-7,1)='4' then slova_milioni := 'četiri' ; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-7,1)='5' then slova_milioni := 'pet' ; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-7,1)='6' then slova_milioni := 'šest' ; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-7,1)='7' then slova_milioni := 'sedam' ; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-7,1)='8' then slova_milioni := 'osam' ; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-7,1)='9' then slova_milioni := 'devet' ; milion_opis:=nvl(milion_opis,'miliona');
  else slova_milioni:='';
  end case;
  --desetice milioni
  case 
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,1)='1' then case
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,2)='11' then slova_milioni := 'jedanaest' ;milion_opis:=nvl(milion_opis,'miliona');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,2)='12' then slova_milioni := 'dvanaest' ;milion_opis:=nvl(milion_opis,'miliona');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,2)='13' then slova_milioni := 'trinaest' ;milion_opis:=nvl(milion_opis,'miliona');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,2)='14' then slova_milioni := 'četrnaest' ;milion_opis:=nvl(milion_opis,'miliona');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,2)='15' then slova_milioni := 'petnaest' ;milion_opis:=nvl(milion_opis,'miliona');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,2)='16' then slova_milioni := 'šestnaest' ;milion_opis:=nvl(milion_opis,'miliona');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,2)='17' then slova_milioni := 'sedamnaest' ;milion_opis:=nvl(milion_opis,'miliona');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,2)='18' then slova_milioni := 'osamnaest' ;milion_opis:=nvl(milion_opis,'miliona');
                                                                                   when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,2)='19' then slova_milioni := 'devetnaest' ;milion_opis:=nvl(milion_opis,'miliona');
                                                                                   else slova_milioni:='';
                                                                                   end case;
  
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,1)='2' then slova_milioni := 'dvadeset' || slova_milioni; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,1)='3' then slova_milioni := 'trideset' || slova_milioni; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,1)='4' then slova_milioni := 'četrdeset' || slova_milioni; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,1)='5' then slova_milioni := 'pedeset' || slova_milioni; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,1)='6' then slova_milioni := 'šezdeset' || slova_milioni; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,1)='7' then slova_milioni := 'sedamdeset' || slova_milioni; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,1)='8' then slova_milioni := 'osamdeset' || slova_milioni; milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-8,1)='9' then slova_milioni := 'devedeset' || slova_milioni; milion_opis:=nvl(milion_opis,'miliona');
  else slova_milioni:='' || slova_milioni;
  end case;
  -- stotice milioni
  case 
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-9,1)='1' then slova_milioni := 'sto' || slova_milioni;milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-9,1)='2' then slova_milioni := 'dvijestotine' || slova_milioni;milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-9,1)='3' then slova_milioni := 'tristotine' || slova_milioni;milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-9,1)='4' then slova_milioni := 'četiristotine' || slova_milioni;milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-9,1)='5' then slova_milioni := 'petstotina' || slova_milioni;milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-9,1)='6' then slova_milioni := 'šeststotina' || slova_milioni;milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-9,1)='7' then slova_milioni := 'sedamstotina' || slova_milioni;milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-9,1)='8' then slova_milioni := 'osamstotina' || slova_milioni;milion_opis:=nvl(milion_opis,'miliona');
  when substr(trim(to_char(p_broj)),instr(trim(to_char(p_broj)),',')-9,1)='9' then slova_milioni := 'devetstotina' || slova_milioni;milion_opis:=nvl(milion_opis,'miliona');
  else slova_milioni:='' || slova_milioni;
  end case;
  /*if slova_stotine is not null then
    slova_stotine:='i' || slova_stotine;
  end if;*/
  RETURN slova_milijarde||milijarda_opis||slova_milioni||milion_opis||slova_hiljade||hiljada_opis||slova_stotine||p_decimale||nvl(stotina_opis,' konvertibilnih maraka');
END SLOVIMA;

/

