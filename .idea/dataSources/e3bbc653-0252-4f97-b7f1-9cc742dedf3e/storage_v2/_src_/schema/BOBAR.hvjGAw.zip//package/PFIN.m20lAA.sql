create PACKAGE PFIN IS
-- PL/SQL Specification
type stavka_tp is record (
	    rj        anlanl.rj%type          := NULL,
	    konto     anlanl.konto%type       := NULL,
	    valuta    anlanl.valuta%type      := NULL,
	    datval    anlanl.datval%type      := NULL,
	    duguje    anlanl.duguje%type      := NULL,
	    potrazuje anlanl.potrazuje%type   := NULL
	);
END PFIN;


/

