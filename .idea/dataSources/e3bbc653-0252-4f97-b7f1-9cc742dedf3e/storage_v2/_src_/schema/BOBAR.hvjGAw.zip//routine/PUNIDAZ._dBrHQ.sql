create PROCEDURE punidaz IS
ropstina opstina%rowtype;

cursor c_opstina is select * 
                      from opstina
                      where ops_sifra < 500
	              order by ops_sifra;
BEGIN
  open c_opstina;
  loop
  	fetch c_opstina into ropstina;
  	exit when c_opstina%notfound;
  	
       insert into ziro_racuni values (
          ropstina.ops_sifra,
          001,
          '562-099-00004389-34',
          'AMS Republike Srpske',
          to_date('31122001','ddmmyyyy'),
          'branot',
          '-', 
          null,
          null
                                      );         
       insert into ziro_racuni values (
          ropstina.ops_sifra,
          002,
          '562-099-00000556-87',
          'Budžet Republike Srpske',
          to_date('31122001','ddmmyyyy'),
          'branot',
          '722423', 
          null,
          null
                                      );         
       insert into ziro_racuni values (
          ropstina.ops_sifra,
          003,
          '562-099-00000556-87',
          'Budžet Republike Srpske',
          to_date('31122001','ddmmyyyy'),
          'branot',
          '722442', 
          null,
          null
                                      );         
       insert into ziro_racuni values (
          ropstina.ops_sifra,
          004,
          '562-099-00000556-87',
          'Budžet Republike Srpske',
          to_date('31122001','ddmmyyyy'),
          'branot',
          '714911', 
          null,
          null
                                      );         
       insert into ziro_racuni values (
          ropstina.ops_sifra,
          005,
          '562-099-00000556-87',
          'Budžet Republike Srpske',
          to_date('31122001','ddmmyyyy'),
          'branot',
          '722111', 
          null,
          null
                                      );         
  end loop;
  close c_opstina;
END;



/

