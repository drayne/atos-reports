create PACKAGE BODY PK_OSNSRED IS

-- Datastructure Definitions
TYPE T_AMOR_SRED IS RECORD
 (VLASNIK TOSNSREDSTVO.VLASNIK%TYPE
 ,LOKACIJA TOSNSREDSTVO.LOKACIJA%TYPE
 ,INVENTARSKIBROJ TOSNSREDSTVO.INVENTARSKIBROJ%TYPE
 ,VRDOK TOSNSREDSTVO.VD%TYPE
 ,NABAVNAVREDNOST TOSNSREDSTVO.NABAVNAVREDNOST%TYPE
 ,ISPRAVKAVREDNOSTI TOSNSREDSTVO.ISPRAVKAVREDNOSTI%TYPE
 ,PROCNABVREDNOST TOSNSREDSTVO.PROCNABVREDNOST%TYPE
 ,REZIDUALNAVREDNOST TOSNSREDSTVO.REZIDUALNAVREDNOST%TYPE
 ,KORISNIVEK TOSNSREDSTVO.KORISNIVEK%TYPE
 ,POCETNAGODINAKORISNOGVEKA TOSNSREDSTVO.POCETNAGODINAKORISNOGVEKA%TYPE
 ,STOPA TOSNAMORGRUPA.STOPA%TYPE
 ,VARIJABILNASTOPA TOSNAMORGRUPA.VARIJABILNASTOPA%TYPE
 ,POC_MESEC NUMBER(4)
 ,KRAJ_MESEC NUMBER(4)
 ,EFEKTIVNI_MESECI NUMBER(4)
 ,GODINAAMORTIZACIJE NUMBER(4)
 ,MESECAMORTIZACIJE NUMBER(2)
 ,SIFOPERAT TOSNSREDSTVO.SIFOPERAT%TYPE
);

-- Sub-Program Unit Declarations
/* Obracun amortizacije primenom amort. stope (proporcionalna metoda). */
PROCEDURE P_AMOR_PRIMENOMSTOPE
 (P_NABAVNAVREDNOST IN NUMBER
 ,P_STOPA IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 );
/* Obracun amortizacije linearnom metodom (proporcionalna metoda). */
PROCEDURE P_AMOR_LINMETOD
 (P_PROCNABVREDNOST IN NUMBER
 ,P_REZIDUALNAVREDNOST IN NUMBER
 ,P_KORISNIVEK IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 );
/* Obracun amortizacije metodom sume degresije. */
PROCEDURE P_AMOR_SUMADEGRESIJE
 (P_PROCNABVREDNOST IN NUMBER
 ,P_REZIDUALNAVREDNOST IN NUMBER
 ,P_KORISNIVEK IN NUMBER
 ,P_GODINAAMORTIZACIJE IN NUMBER
 ,P_POCETNAGODINAKORISNOGVEKA IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 );
/* Obracun amortizacije metodom sume brojeva korisnog veka upotrebe. */
PROCEDURE P_AMOR_SUMABRKORVEKA
 (P_NABAVNAVREDNOST IN NUMBER
 ,P_REZIDUALNAVREDNOST IN NUMBER
 ,P_KORISNIVEK IN NUMBER
 ,P_GODINAAMORTIZACIJE IN NUMBER
 ,P_pocmesec IN NUMBER
 ,P_krajmesec IN NUMBER
 ,P_mesecaktiviranja IN NUMBER
 ,P_godinaaktiviranja IN NUMBER
 ,P_POCETNAGODINAKORISNOGVEKA IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 );
/* Obracun amortizacije metodom opadajuceg salda uz primenu fiksne stope. */
PROCEDURE P_AMOR_OPADSALDO
 (P_NABAVNAVREDNOST IN NUMBER
 ,P_ISPRAVKAVREDNOSTI IN NUMBER
 ,P_REZIDUALNAVREDNOST IN NUMBER
 ,P_KORISNIVEK IN NUMBER
 ,P_GODINAAMORTIZACIJE IN NUMBER
 ,P_POCETNAGODINA IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 );
/* Obracun amortizacije metodom smanjenja stope amortizacije. */
PROCEDURE P_AMOR_SMANJSTOPEAMO
 (P_NABAVNAVREDNOST IN NUMBER
 ,P_REZIDUALNAVREDNOST IN NUMBER
 ,P_VARIJABILNASTOPA IN NUMBER
 ,P_KORISNIVEK IN NUMBER
 ,P_GODINAAMORTIZACIJE IN NUMBER
 ,P_POCETNAGODINA IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 );
/* Obracun amortizacije funkcionalnom metodom. */
PROCEDURE P_AMOR_FUNKCMETOD
 (P_NABAVNAVREDNOST IN NUMBER
 ,P_REZIDUALNAVREDNOST IN NUMBER
 ,P_VLASNIK IN TOSNSREDSTVO.VLASNIK%TYPE
 ,P_LOKACIJA IN TOSNSREDSTVO.LOKACIJA%TYPE
 ,P_INVENTARSKIBROJ IN TOSNSREDSTVO.INVENTARSKIBROJ%TYPE
 ,P_GODINAAMORTIZACIJE IN NUMBER
 ,P_POCETNAGODINA IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 );

-- Sub-Program Units
PROCEDURE P_OBRACUN_AMORTIZACIJE
 (P_VLASNIK_OD IN number
 ,P_LOKACIJA_OD IN number
 ,P_VLASNIK_DO IN number
 ,P_LOKACIJA_DO IN number
 ,P_MESEC_OD IN number
 ,P_MESEC_DO IN number
 ,P_GODINA IN number
 ,P_METOD IN number
 ,P_STOPA IN number
 ,P_VARSTOPA IN number
 ,P_KORISNIK IN varchar2
 ,P_OBRADJENO OUT number
 )
 IS

-- Sub-Program Unit Declarations
/* Kursor za sredstva za koja se vrsi amortizacija. */
CURSOR C_AMOR_SRED
 (PP_VLASNIK_OD IN NUMBER
 ,PP_LOKACIJA_OD IN NUMBER
 ,PP_VLASNIK_DO IN NUMBER
 ,PP_LOKACIJA_DO IN NUMBER
 ,PP_MESEC_OD IN NUMBER
 ,PP_MESEC_DO IN NUMBER
 ,PP_GODINA IN NUMBER
 ,PP_METOD IN NUMBER
 ,PP_STOPA IN NUMBER
 ,PP_VARSTOPA IN NUMBER
 )
 IS
   select s.vlasnik,
          s.lokacija,
          s.inventarskibroj,
          o.vdobramor,
          s.amortizacionagrupa,
          s.mesecaktiviranja,
          s.godinaaktiviranja,
          s.mesecisknjizenja,
          s.godinaisknjizenja,
          s.nabavnavrednost,
          s.ispravkavrednosti,
          nvl(s.procnabvrednost, 0) procnabvrednost,
          nvl(s.rezidualnavrednost, 0) rezidualnavrednost,
          s.korisnivek,
          s.pocetnagodinakorisnogveka,
          decode(pp_metod, 0, a.metodamortizacije, pp_metod) metodamortizacije,
          decode(pp_metod, 0, a.stopa, pp_stopa) stopa,
          decode(pp_metod, 0, a.varijabilnastopa, pp_varstopa) varijabilnastopa
     from TOsnSredstvo s, TOsnAmorGrupa a, TOsnObrada o
    where power(10,13)*s.vlasnik+s.lokacija between power(10,13)*pp_vlasnik_od+pp_lokacija_od and power(10,13)*pp_vlasnik_do+pp_lokacija_do
      and 100*s.godinaaktiviranja+s.mesecaktiviranja <= 100*pp_godina+pp_mesec_do
      and (s.mesecisknjizenja is null or 100*s.godinaisknjizenja+s.mesecisknjizenja >= 100*pp_godina+pp_mesec_od)
      and s.amortizacionagrupa = a.amortizacionagrupa
      and s.vlasnik = o.vlasnik
      and s.lokacija = o.radnja;

-- Program Data
EFEKTIVNIMESECI NUMBER;
KRAJMESEC NUMBER;
IZNOSAMORTIZACIJE NUMBER;
POCMESEC NUMBER;
-- L_AMOR_SRED PK_OSNSRED.T_AMOR_SRED;

-- Sub-Program Units
-- PL/SQL Block
begin

   p_obradjeno := 0;

   delete TOsnObracunAmor;

   for r_sred in c_amor_sred(p_vlasnik_od, p_lokacija_od, p_vlasnik_do, p_lokacija_do, p_mesec_od, p_mesec_do, p_godina, p_metod, p_stopa, p_varstopa) loop

      /*
         Ako je sredstvo aktivirano posle pocetka perioda za koji se racuna amortizacija
         onda je pocetni mesec mesec aktiviranja + 1. U ostalim slucajevima za pocetni mesec
         se uzima pocetni mesec intervala.
      */
      if r_sred.godinaaktiviranja = p_godina and r_sred.mesecaktiviranja >= p_mesec_od then
         PocMesec := r_sred.mesecaktiviranja + 1;
      else
         PocMesec := p_mesec_od;
      end if;

      /*
         Ako je sredstvo isknjizeno za vreme perioda za koji se racuna amortizacija,
         onda je krajnji mesec mesec isknjizenja. U ostalim slucajevima za krajnji
         mesec se uzima krajnji mesec intervala.
      */
      if r_sred.godinaisknjizenja = p_godina and r_sred.mesecisknjizenja < p_mesec_do then
         KrajMesec := r_sred.mesecisknjizenja;
      else
         KrajMesec := p_mesec_do;
      end if;

      EfektivniMeseci := KrajMesec - PocMesec + 1;

      if EfektivniMeseci > 0 then

         /*
            Napuni strukturu
         l_amor_sred.vlasnik := r_sred.vlasnik;
         l_amor_sred.lokacija := r_sred.lokacija;
         l_amor_sred.inventarskibroj := r_sred.inventarskibroj;
         l_amor_sred.vrdok := r_sred.vdobramor;
         l_amor_sred.nabavnavrednost := r_sred.nabavnavrednost;
         l_amor_sred.ispravkavrednosti := r_sred.ispravkavrednosti;
         l_amor_sred.procnabvrednost := r_sred.procnabvrednost;
         l_amor_sred.rezidualnavrednost := r_sred.rezidualnavrednost;
         l_amor_sred.korisnivek := r_sred.korisnivek;
         l_amor_sred.pocetnagodinakorisnogveka := r_sred.pocetnagodinakorisnogveka;
         l_amor_sred.stopa := r_sred.stopa;
         l_amor_sred.varijabilnastopa := r_sred.varijabilnastopa;
         l_amor_sred.poc_mesec := PocMesec;
         l_amor_sred.kraj_mesec := KrajMesec;
         l_amor_sred.efektivni_meseci := EfektivniMeseci;
         l_amor_sred.godinaamortizacije := p_godina;
         l_amor_sred.mesecamortizacije := p_mesec_do;
         l_amor_sred.sifoperat := p_korisnik;
         */

         /*
            Pozovi odgovarajuci obracun amortizacije
         */

         if r_sred.metodamortizacije = 1 then
            p_amor_primenomstope(
               r_sred.nabavnavrednost,
               r_sred.stopa,
               EfektivniMeseci,
               IznosAmortizacije
            );
         elsif r_sred.metodamortizacije = 2 then
            p_amor_linmetod(
               r_sred.procnabvrednost,
               r_sred.rezidualnavrednost,
               r_sred.korisnivek,
               EfektivniMeseci,
               IznosAmortizacije
            );
         elsif r_sred.metodamortizacije = 3 then
            p_amor_sumadegresije(
               r_sred.procnabvrednost,
               r_sred.rezidualnavrednost,
               r_sred.korisnivek,
               p_godina,
               r_sred.pocetnagodinakorisnogveka,
               EfektivniMeseci,
               IznosAmortizacije
            );
         elsif r_sred.metodamortizacije = 4 then
            p_amor_sumabrkorveka(
               r_sred.nabavnavrednost,
               r_sred.rezidualnavrednost,
               r_sred.korisnivek,
               p_godina,
               PocMesec,
               KrajMesec,
               r_sred.mesecaktiviranja,
               r_sred.godinaaktiviranja,
               r_sred.pocetnagodinakorisnogveka,
               EfektivniMeseci,
               IznosAmortizacije
            );
         elsif r_sred.metodamortizacije = 5 then
            p_amor_opadsaldo(
               r_sred.nabavnavrednost,
               r_sred.ispravkavrednosti,
               r_sred.rezidualnavrednost,
               r_sred.korisnivek,
               p_godina,
               r_sred.pocetnagodinakorisnogveka,
               EfektivniMeseci,
               IznosAmortizacije
            );
         elsif r_sred.metodamortizacije = 6 then
            p_amor_smanjstopeamo(
               r_sred.nabavnavrednost,
               r_sred.rezidualnavrednost,
               r_sred.varijabilnastopa,
               r_sred.korisnivek,
               p_godina,
               r_sred.pocetnagodinakorisnogveka,
               EfektivniMeseci,
               IznosAmortizacije
            );
         elsif r_sred.metodamortizacije = 7 then
            p_amor_funkcmetod(
               r_sred.nabavnavrednost,
               r_sred.rezidualnavrednost,
               r_sred.vlasnik,
               r_sred.lokacija,
               r_sred.inventarskibroj,
               p_godina,
               r_sred.pocetnagodinakorisnogveka,
               EfektivniMeseci,
               IznosAmortizacije
            );
         end if;

         /*
            Ukupna ispravka vrednosti ne sme biti veca od nabavne vrednosti umanjene za rezidualnu vrednost.
         */
         if r_sred.nabavnavrednost - r_sred.rezidualnavrednost < r_sred.ispravkavrednosti + IznosAmortizacije then
            IznosAmortizacije := r_sred.nabavnavrednost - r_sred.rezidualnavrednost - r_sred.ispravkavrednosti;
         end if;

         insert into TOsnObracunAmor (
            ID                             ,
            TABLEMANAGER                   ,
            VLASNIK                        ,
            LOKACIJA                       ,
            INVENTARSKIBROJ                ,
            GODINAAMORTIZACIJE             ,
            MESECPROMENE                   ,
            VD                             ,
            BROJMESECI                     ,
            IZNOSAMORTIZACIJE              ,
            METODAMORTIZACIJE              ,
            STOPA                          ,
            VARIJABILNASTOPA               ,
            DATUMOBRADE                    ,
            SIFOPERAT
         )
         values (
            null,                     -- ID
            null,                     -- TABLEMANAGER
            r_sred.vlasnik,           -- VLASNIK
            r_sred.lokacija,          -- LOKACIJA
            r_sred.inventarskibroj,   -- INVENTARSKIBROJ
            p_godina,                 -- GODINAAMORTIZACIJE
            p_mesec_do,               -- MESECPROMENE
            r_sred.vdobramor,         -- VD
            EfektivniMeseci,          -- BROJMESECI
            IznosAmortizacije,        -- IZNOSAMORTIZACIJE
            r_sred.metodamortizacije, -- METODAMORTIZACIJE
            r_sred.stopa,             -- STOPA
            r_sred.varijabilnastopa,  -- VARIJABILNASTOPA
            sysdate,                  -- DATUMOBRADE
            p_korisnik                -- SIFOPERAT
         );

         p_obradjeno := p_obradjeno + 1;

      end if;

   end loop;

   commit;

end;

PROCEDURE P_OBRACUN_REVALORIZACIJE
 (P_VLASNIK_OD IN number
 ,P_LOKACIJA_OD IN number
 ,P_VLASNIK_DO IN number
 ,P_LOKACIJA_DO IN number
 ,P_MESEC_OD IN number
 ,P_MESEC_DO IN number
 ,P_GODINA IN number
 ,P_PO_MESECIMA IN boolean
 ,P_KORISNIK IN varchar2
 ,P_OBRADJENO OUT number
 )
 IS
-- PL/SQL Specification
cursor c_sred is
   select s.vlasnik,
          s.lokacija,
          s.inventarskibroj,
          o.vdobrreval,
          s.revalorizacionagrupa,
          s.mesecaktiviranja,
          s.godinaaktiviranja,
          s.mesecisknjizenja,
          s.godinaisknjizenja,
          s.nabavnavrednost,
          s.ispravkavrednosti
     from TOsnSredstvo s, TOsnObrada o
    where power(10,13)*s.vlasnik+s.lokacija between power(10,13)*p_vlasnik_od+p_lokacija_od and power(10,13)*p_vlasnik_do+p_lokacija_do
      and 100*s.godinaaktiviranja+s.mesecaktiviranja <= 100*p_godina+p_mesec_do
      and (s.mesecisknjizenja is null or 100*s.godinaisknjizenja+s.mesecisknjizenja >= 100*p_godina+p_mesec_od)
      and s.vlasnik = o.vlasnik
      and s.lokacija = o.radnja
    order by revalorizacionagrupa;

   EfektivniMeseci number;
   PocMesec        number; -- pocetak intervala za koji se racuna revalorizacija
   KrajMesec       number; -- kraj intervala za koji se racuna revalorizacija
   StopaRev        number;

   type t_stope is varray(13) of number;
   type t_grupa is record (
      revgrupa    varchar2(10),
      zbirnastopa number,
      messtope    t_stope := t_stope(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
   );

   r_grupa        t_grupa;

   IznosRevNabVred number;
   IznosRevIspVred number;

-- PL/SQL Block
begin

   p_obradjeno := 0;

   /*
      Preuzmi prvu revalorizacionu grupu.
   */
   select revalorizacionagrupa,
          zbirnastopa,
          odjanuara,
          odfebruara,
          odmarta,
          odaprila,
          odmaja,
          odjuna,
          odjula,
          odavgusta,
          odseptembra,
          odoktobra,
          odnovembra,
          oddecembra
     into r_grupa.revgrupa,
          r_grupa.zbirnastopa,
          r_grupa.messtope(1),
          r_grupa.messtope(2),
          r_grupa.messtope(3),
          r_grupa.messtope(4),
          r_grupa.messtope(5),
          r_grupa.messtope(6),
          r_grupa.messtope(7),
          r_grupa.messtope(8),
          r_grupa.messtope(9),
          r_grupa.messtope(10),
          r_grupa.messtope(11),
          r_grupa.messtope(12)
     from TOsnRgOd
    where rownum = 1;

   delete TosnObracunReval;

   for r_sred in c_sred loop

      /*
         Ako je sredstvo aktivirano posle pocetka perioda za koji se racuna revalorizacija,
         onda je pocetni mesec mesec aktiviranja. U ostalim slucajevima za pocetni mesec
         se uzima pocetni mesec intervala.
      */
      if r_sred.godinaaktiviranja = p_godina and r_sred.mesecaktiviranja > p_mesec_od then
         PocMesec := r_sred.mesecaktiviranja;
      else
         PocMesec := p_mesec_od;
      end if;

      /*
         Ako je sredstvo isknjizeno za vreme perioda za koji se racuna revalorizacija,
         onda je krajnji mesec mesec isknjizenja. U ostalim slucajevima za krajnji
         mesec se uzima krajnji mesec intervala.
      */
      if r_sred.godinaisknjizenja = p_godina and r_sred.mesecisknjizenja < p_mesec_do then
         KrajMesec := r_sred.mesecisknjizenja;
      else
         KrajMesec := p_mesec_do;
      end if;

      EfektivniMeseci := KrajMesec - PocMesec + 1;

      if EfektivniMeseci > 0 then

         /*
            Provera da li r_grupa sadrzi odgovarajucu revalorizacionu grupu.
         */
         if r_grupa.revgrupa != r_sred.revalorizacionagrupa then
            select revalorizacionagrupa,
                   zbirnastopa,
                   odjanuara,
                   odfebruara,
                   odmarta,
                   odaprila,
                   odmaja,
                   odjuna,
                   odjula,
                   odavgusta,
                   odseptembra,
                   odoktobra,
                   odnovembra,
                   oddecembra
              into r_grupa.revgrupa,
                   r_grupa.zbirnastopa,
                   r_grupa.messtope(1),
                   r_grupa.messtope(2),
                   r_grupa.messtope(3),
                   r_grupa.messtope(4),
                   r_grupa.messtope(5),
                   r_grupa.messtope(6),
                   r_grupa.messtope(7),
                   r_grupa.messtope(8),
                   r_grupa.messtope(9),
                   r_grupa.messtope(10),
                   r_grupa.messtope(11),
                   r_grupa.messtope(12)
              from TOsnRgOd
             where revalorizacionagrupa = r_sred.revalorizacionagrupa;
         end if;

         /*
            Odredjivanje stope revalorizacije
         */
         if (not p_po_mesecima) and (PocMesec = 1) and (KrajMesec = 12) then
            /* uzima se zbirna stopa */
            StopaRev := r_grupa.zbirnastopa;
         else
            StopaRev := r_grupa.messtope(PocMesec) - r_grupa.messtope(KrajMesec+1); -- r_grupa.messtope(13) je uvek 0
         end if;

         IznosRevNabVred := r_sred.nabavnavrednost * StopaRev / 100.00;
         IznosRevIspVred := r_sred.ispravkavrednosti * StopaRev / 100.00;

         insert into TOsnObracunReval values (
            null,                     -- ID
            null,                     -- TABLEMANAGER
            r_sred.vlasnik,           -- VLASNIK
            r_sred.lokacija,          -- LOKACIJA
            r_sred.inventarskibroj,   -- INVENTARSKIBROJ
            p_godina,                 -- GODINAOBRADE
            p_mesec_do,               -- MESECPROMENE
            r_sred.vdobrreval,        -- VD
            EfektivniMeseci,          -- BROJMESECI
            IznosRevNabVred,          -- IZNOSREVNABAVNEVRED
            IznosRevIspVred,          -- IZNOSREVISPRAVKEVRED
            r_sred.nabavnavrednost,   -- NABAVNAVREDNOST
            r_sred.ispravkavrednosti, -- ISPRAVKAVREDNOSTI
            StopaRev,                 -- STOPA
            sysdate,                  -- DATUMOBRADE
            p_korisnik                -- SIFOPERAT
         );
         p_obradjeno := p_obradjeno + 1;
      end if;

   end loop;

   commit;

end;

PROCEDURE P_PRENOS_OBR_AMOR
 (P_OPERATER IN varchar2
 ,P_OBRADJENO OUT number
 )
 IS
-- PL/SQL Specification
cursor c_amor is
   select vlasnik,
          lokacija,
          inventarskibroj,
          godinaamortizacije,
          mesecpromene,
          vd,
          iznosamortizacije,
          metodamortizacije,
          stopa,
          varijabilnastopa
     from TosnObracunAmor;

-- PL/SQL Block
begin

   p_obradjeno := 0;

   for r_amor in c_amor loop

      begin

         update TosnSredstvo
            set ispravkavrednosti = ispravkavrednosti + r_amor.iznosamortizacije
          where vlasnik           = r_amor.vlasnik
            and lokacija          = r_amor.lokacija
            and inventarskibroj   = r_amor.inventarskibroj;

         insert into TOsnKartica (
            ID                     ,
            TABLEMANAGER           ,
            VLASNIK                ,
            LOKACIJA               ,
            INVENTARSKIBROJ        ,
            VD                     ,
            GODINAPROMENE          ,
            MESECPROMENE           ,
            NABAVNAVREDNOST        ,
            ISPRAVKAVREDNOSTI      ,
            METODAMORTIZACIJE      ,
            STOPA                  ,
            VARIJABILNASTOPA       ,
            DATUMOBRADE            ,
            SIFOPERAT
         )
         values (
            null,                      -- ID
            null,                      -- TABLEMANAGER
            r_amor.vlasnik,            -- VLASNIK
            r_amor.lokacija,           -- LOKACIJA
            r_amor.inventarskibroj,    -- INVENTARSKIBROJ
            r_amor.vd,                 -- VD
            r_amor.godinaamortizacije, -- GODINAPROMENE
            r_amor.mesecpromene,       -- MESECPROMENE
            0,                         -- NABAVNAVREDNOST
            r_amor.iznosamortizacije,  -- ISPRAVKAVREDNOSTI
            r_amor.metodamortizacije,  -- METODAMORTIZACIJE
            r_amor.stopa,              -- STOPA
            r_amor.varijabilnastopa,   -- VARIJABILNASTOPA
            sysdate,                   -- DATUMOBRADE
            p_operater                 -- SIFOPERAT
         );

         p_obradjeno := p_obradjeno + 1;

      exception
         when others then null;
      end;

   end loop;

   commit;

end;

PROCEDURE P_PRENOS_OBR_REVAL
 (P_OPERATER IN varchar2
 ,P_OBRADJENO OUT number
 )
 IS
-- PL/SQL Specification
cursor c_reval is
   select vlasnik,
          lokacija,
          inventarskibroj,
          godinaobrade,
          mesecpromene,
          vd,
          iznosrevnabavnevred,
          iznosrevispravkevred
     from TOsnObracunReval;

-- PL/SQL Block
begin

   p_obradjeno := 0;

   for r_reval in c_reval loop

      begin

         update TOsnSredstvo
            set nabavnavrednost   = nabavnavrednost   + r_reval.iznosrevnabavnevred,
                ispravkavrednosti = ispravkavrednosti + r_reval.iznosrevispravkevred
          where vlasnik           = r_reval.vlasnik
            and lokacija          = r_reval.lokacija
            and inventarskibroj   = r_reval.inventarskibroj;

         insert into TOsnKartica (
            ID                     ,
            TABLEMANAGER           ,
            VLASNIK                ,
            LOKACIJA               ,
            INVENTARSKIBROJ        ,
            VD                     ,
            GODINAPROMENE          ,
            MESECPROMENE           ,
            NABAVNAVREDNOST        ,
            ISPRAVKAVREDNOSTI      ,
            DATUMOBRADE            ,
            SIFOPERAT
         )
         values (
            null,                         -- ID
            null,                         -- TABLEMANAGER
            r_reval.vlasnik,              -- VLASNIK
            r_reval.lokacija,             -- LOKACIJA
            r_reval.inventarskibroj,      -- INVENTARSKIBROJ
            r_reval.vd,                   -- VD
            r_reval.godinaobrade,         -- GODINAPROMENE
            r_reval.mesecpromene,         -- MESECPROMENE
            r_reval.iznosrevnabavnevred,  -- NABAVNAVREDNOST
            r_reval.iznosrevispravkevred, -- ISPRAVKAVREDNOSTI
            sysdate,                      -- DATUMOBRADE
            p_operater                    -- SIFOPERAT
         );

         p_obradjeno := p_obradjeno + 1;

      exception
         when others then null;
      end;

   end loop;

   commit;

end;

PROCEDURE P_PONISTI_OBRADU
 (P_VLASNIK IN NUMBER
 ,P_LOKACIJA IN NUMBER
 ,P_VD IN NUMBER
 ,P_GODINA IN NUMBER
 ,P_MESEC IN NUMBER
 ,P_OBRADJENO OUT NUMBER
 )
 IS
-- PL/SQL Specification
cursor c_kart is
  select vlasnik, lokacija, inventarskibroj, nabavnavrednost, ispravkavrednosti
    from tosnkartica
   where vlasnik = p_vlasnik
     and lokacija = p_lokacija
     and vd = p_vd
     and godinapromene = p_godina
     and mesecpromene = p_mesec;

-- PL/SQL Block
BEGIN
p_obradjeno := 0;

for r_kart in c_kart loop

   update tosnsredstvo
      set nabavnavrednost = nabavnavrednost - r_kart.nabavnavrednost,
          ispravkavrednosti = ispravkavrednosti - r_kart.ispravkavrednosti
    where vlasnik = r_kart.vlasnik
      and lokacija = r_kart.lokacija
      and inventarskibroj = r_kart.inventarskibroj;

   p_obradjeno := p_obradjeno + 1;

end loop;

delete tosnkartica
 where vlasnik = p_vlasnik
   and lokacija = p_lokacija
   and vd = p_vd
   and godinapromene = p_godina
   and mesecpromene = p_mesec;

commit;
END;

PROCEDURE P_STORNIRAJ_OBRADU
 (P_VLASNIK IN NUMBER
 ,P_LOKACIJA IN NUMBER
 ,P_VD IN NUMBER
 ,P_GODINA IN NUMBER
 ,P_MESEC IN NUMBER
 ,P_OPERATER IN VARCHAR2
 ,P_OBRADJENO OUT NUMBER
 )
 IS
-- PL/SQL Specification
cursor c_kart is
  select k.inventarskibroj, k.nabavnavrednost, k.ispravkavrednosti,
         decode(k.vd,
                o.vdobramor, o.vdstornoamor,
                o.vdobrreval, o.vdstornoreval) vdstorno
    from tosnkartica k, tosnobrada o
   where k.vlasnik = p_vlasnik
     and k.lokacija = p_lokacija
     and k.vd = p_vd
     and k.godinapromene = p_godina
     and k.mesecpromene = p_mesec
     and k.vlasnik = o.vlasnik
     and k.lokacija = o.radnja;

-- PL/SQL Block
BEGIN
p_obradjeno := 0;

for r_kart in c_kart loop

   update tosnsredstvo
      set nabavnavrednost = nabavnavrednost - r_kart.nabavnavrednost,
          ispravkavrednosti = ispravkavrednosti - r_kart.ispravkavrednosti
    where vlasnik = p_vlasnik
      and lokacija = p_lokacija
      and inventarskibroj = r_kart.inventarskibroj;

   insert into TOsnKartica (
      ID                ,
      TABLEMANAGER      ,
      VLASNIK           ,
      LOKACIJA          ,
      INVENTARSKIBROJ   ,
      VD                ,
      GODINAPROMENE     ,
      MESECPROMENE      ,
      NABAVNAVREDNOST   ,
      ISPRAVKAVREDNOSTI ,
      DATUMOBRADE       ,
      SIFOPERAT
   )
   values (
      null,                      -- ID
      null,                      -- TABLEMANAGER
      p_vlasnik,                 -- VLASNIK
      p_lokacija,                -- LOKACIJA
      r_kart.inventarskibroj,    -- INVENTARSKIBROJ
      r_kart.vdstorno,           -- VD
      p_godina,                  -- GODINAPROMENE
      p_mesec,                   -- MESECPROMENE
      -r_kart.nabavnavrednost,   -- NABAVNAVREDNOST
      -r_kart.ispravkavrednosti, -- ISPRAVKAVREDNOSTI
      sysdate,                   -- DATUMOBRADE
      p_operater                 -- SIFOPERAT
   );

   p_obradjeno := p_obradjeno + 1;

end loop;

commit;
END;

/* 1. Obracun amortizacije primenom amort. stope. */
PROCEDURE P_AMOR_PRIMENOMSTOPE
 (P_NABAVNAVREDNOST IN NUMBER
 ,P_STOPA IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 )
 IS
BEGIN
p_IznosAmortizacije := p_NabavnaVrednost *
                       (p_Stopa / 100) *
                       (p_EfektivniMeseci / 12);
END;

/* 2. Obracun amortizacije linearnom metodom (proporcionalna metoda). */
PROCEDURE P_AMOR_LINMETOD
 (P_PROCNABVREDNOST IN NUMBER
 ,P_REZIDUALNAVREDNOST IN NUMBER
 ,P_KORISNIVEK IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 )
 IS
BEGIN
p_IznosAmortizacije := ((p_ProcNabVrednost - p_RezidualnaVrednost) / p_KorisniVek) *
                       (p_EfektivniMeseci / 12);
END;

/* 3. Obracun amortizacije metodom sume degresije. */
PROCEDURE P_AMOR_SUMADEGRESIJE
 (P_PROCNABVREDNOST IN NUMBER
 ,P_REZIDUALNAVREDNOST IN NUMBER
 ,P_KORISNIVEK IN NUMBER
 ,P_GODINAAMORTIZACIJE IN NUMBER
 ,P_POCETNAGODINAKORISNOGVEKA IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 )
 IS

-- Program Data
FAKTOR NUMBER;
BROJGODINA NUMBER;

-- PL/SQL Block
BEGIN
Faktor := p_KorisniVek * (p_KorisniVek + 1) / 2;
BrojGodina := p_GodinaAmortizacije - p_PocetnaGodinaKorisnogVeka;

p_IznosAmortizacije := (p_ProcNabVrednost - p_RezidualnaVrednost) *
                     (p_KorisniVek - BrojGodina) / Faktor *
                     (p_EfektivniMeseci / 12);
END;

/* 4. Obracun amortizacije metodom sume brojeva korisnog veka upotrebe. */
PROCEDURE P_AMOR_SUMABRKORVEKA
 (P_NABAVNAVREDNOST IN NUMBER
 ,P_REZIDUALNAVREDNOST IN NUMBER
 ,P_KORISNIVEK IN NUMBER
 ,P_GODINAAMORTIZACIJE IN NUMBER
 ,P_POCMESEC IN NUMBER
 ,P_KRAJMESEC IN NUMBER
 ,P_MESECAKTIVIRANJA IN NUMBER
 ,P_GODINAAKTIVIRANJA IN NUMBER
 ,P_POCETNAGODINAKORISNOGVEKA IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 )
 IS

-- Program Data
Faktor NUMBER;
Godina NUMBER;
OsnovZaAmortizaciju NUMBER;
BrojMeseciPreAktiviranja NUMBER;
BrojMeseciPosleAktiviranja NUMBER;
Iznos1 NUMBER;
Iznos2 NUMBER;
MesecAktiviranja NUMBER;

-- PL/SQL Block
BEGIN
/*
   Ako je sredstvo aktivirano pre Pocetne godine korisnog veka,
   za mesec aktiviranja se uzima januar u pocetnoj godini korisnog
   veka.
*/
if P_GODINAAKTIVIRANJA < P_POCETNAGODINAKORISNOGVEKA then
   MesecAktiviranja := 1;
else
   MesecAktiviranja := P_MESECAKTIVIRANJA;
end if;

/*
   Period za koji se obracunava amortizacija se deli na dva dela:
   1. pre meseca aktiviranja (uknjizenja)
   2. mesec aktiviranja i kasnije

   Za prvi deo se uzima faktor iz prethodne godina, a za drugi iz
   tekuce godine.
*/
Faktor := p_KorisniVek * (p_KorisniVek + 1) / 2;
Godina := p_GodinaAmortizacije - p_PocetnaGodinaKorisnogVeka;
OsnovZaAmortizaciju := p_NabavnaVrednost - p_RezidualnaVrednost;

if p_KrajMesec < MesecAktiviranja then
   /* Ceo interval je pre meseca aktiviranja */
   BrojMeseciPreAktiviranja := p_KrajMesec - p_PocMesec + 1;
   BrojMeseciPosleAktiviranja := 0;
elsif p_PocMesec >= MesecAktiviranja then
   /* Ceo interval je posle meseca aktiviranja */
   BrojMeseciPreAktiviranja := 0;
   BrojMeseciPosleAktiviranja := p_KrajMesec - p_PocMesec + 1;
else
   BrojMeseciPreAktiviranja := MesecAktiviranja - p_PocMesec;
   BrojMeseciPosleAktiviranja := p_KrajMesec - MesecAktiviranja + 1;
end if;

/* deo amortizacije pre meseca aktiviranja */
if Godina > 0 and Godina <= p_KorisniVek then
   Iznos1 := OsnovZaAmortizaciju * (p_KorisniVek-Godina+1)/Faktor * BrojMeseciPreAktiviranja/12;
else
   Iznos1 := 0;
end if;

/* deo amortizacije posle meseca aktiviranja */
if Godina >= 0 and Godina < p_KorisniVek then
   Iznos2 := OsnovZaAmortizaciju * (p_KorisniVek-Godina)/Faktor * BrojMeseciPosleAktiviranja/12;
else
   Iznos2 := 0;
end if;
p_IznosAmortizacije := Iznos1 + Iznos2;

END;

/* 5. Obracun amortizacije metodom opadajuceg salda uz primenu fiksne stope. */
PROCEDURE P_AMOR_OPADSALDO
 (P_NABAVNAVREDNOST IN NUMBER
 ,P_ISPRAVKAVREDNOSTI IN NUMBER
 ,P_REZIDUALNAVREDNOST IN NUMBER
 ,P_KORISNIVEK IN NUMBER
 ,P_GODINAAMORTIZACIJE IN NUMBER
 ,P_POCETNAGODINA IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 )
 IS

-- Program Data
DVOSTRUKASTOPA NUMBER;
OSNOVZAAMORTIZACIJU NUMBER;
BROJGODINA NUMBER;

-- PL/SQL Block
BEGIN
DvostrukaStopa := 2 / p_KorisniVek;
BrojGodina := p_GodinaAmortizacije - p_PocetnaGodina;

if BrojGodina = 0 then
   OsnovZaAmortizaciju := p_NabavnaVrednost - p_RezidualnaVrednost;
else
   OsnovZaAmortizaciju := p_NabavnaVrednost - p_IspravkaVrednosti;
end if;


p_IznosAmortizacije := OsnovZaAmortizaciju *
                       DvostrukaStopa *
                       (p_EfektivniMeseci / 12);
END;

/* 6. Obracun amortizacije metodom smanjenja stope amortizacije. */
PROCEDURE P_AMOR_SMANJSTOPEAMO
 (P_NABAVNAVREDNOST IN NUMBER
 ,P_REZIDUALNAVREDNOST IN NUMBER
 ,P_VARIJABILNASTOPA IN NUMBER
 ,P_KORISNIVEK IN NUMBER
 ,P_GODINAAMORTIZACIJE IN NUMBER
 ,P_POCETNAGODINA IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 )
 IS

-- Program Data
OSNOVZAAMORTIZACIJU NUMBER;
FIKSNASTOPA NUMBER;
BROJGODINA NUMBER;

-- PL/SQL Block
BEGIN
FiksnaStopa := (1 - (p_KorisniVek*(p_KorisniVek+1)*(p_VarijabilnaStopa/100)/2)) / p_KorisniVek;
BrojGodina := p_GodinaAmortizacije - p_PocetnaGodina;

OsnovZaAmortizaciju := p_NabavnaVrednost - p_RezidualnaVrednost;

p_IznosAmortizacije := OsnovZaAmortizaciju *
                       (FiksnaStopa + (p_KorisniVek-BrojGodina) * (p_VarijabilnaStopa/100)) *
                       (p_EfektivniMeseci / 12);
END;

/* 7. Obracun amortizacije funkcionalnom metodom. */
PROCEDURE P_AMOR_FUNKCMETOD
 (P_NABAVNAVREDNOST IN NUMBER
 ,P_REZIDUALNAVREDNOST IN NUMBER
 ,P_VLASNIK IN TOSNSREDSTVO.VLASNIK%TYPE
 ,P_LOKACIJA IN TOSNSREDSTVO.LOKACIJA%TYPE
 ,P_INVENTARSKIBROJ IN TOSNSREDSTVO.INVENTARSKIBROJ%TYPE
 ,P_GODINAAMORTIZACIJE IN NUMBER
 ,P_POCETNAGODINA IN NUMBER
 ,P_EFEKTIVNIMESECI IN NUMBER
 ,P_IZNOSAMORTIZACIJE OUT NUMBER
 )
 IS

-- Program Data
UCINAKZAGODINU NUMBER;
SUMAUCINAKA NUMBER;
BROJGODINA NUMBER;

-- PL/SQL Block
BEGIN
BrojGodina := p_GodinaAmortizacije - p_PocetnaGodina + 1;

select nvl(sum(ucinak), 0)
  into SumaUcinaka
  from TOsnOstvareniUcinak
 where sred_vlasnik = p_Vlasnik
   and sred_lokacija = p_Lokacija
   and sred_inventarskibroj = p_InventarskiBroj;

begin
   select ucinak
     into UcinakZaGodinu
     from TOsnOstvareniUcinak
    where sred_vlasnik = p_Vlasnik
      and sred_lokacija = p_Lokacija
      and sred_inventarskibroj = p_InventarskiBroj
      and godina = BrojGodina;
exception
   when others then
      UcinakZaGodinu := 0;
end;

p_IznosAmortizacije := (p_NabavnaVrednost - p_RezidualnaVrednost) *
                       (UcinakZaGodinu / SumaUcinaka) *
                       (p_EfektivniMeseci / 12);
END;

-- PL/SQL Block
END PK_OSNSRED;
/

