create function premija (p_vsdok number,p_pol_brpol number) return varchar2 as 
rez number:=0;
begin
  select sum(dev_duguje) into rez
  from anlanl 
  where pol_brpol=to_char(p_pol_brpol) and reznum_1=p_vsdok and konto in (20100,22230) and anl_vsdok in (314,319);
  return rez;
END PREMIJA;

/

