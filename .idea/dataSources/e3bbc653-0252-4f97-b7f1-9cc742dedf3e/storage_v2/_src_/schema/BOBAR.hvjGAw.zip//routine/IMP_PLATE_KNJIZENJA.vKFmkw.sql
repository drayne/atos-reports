create PROCEDURE       "IMP_PLATE_KNJIZENJA"
(
p_ime_fajla varchar2,
p_put_do_fajla varchar2,
p_delimiter varchar2 default ';',
p_upisano out number,
p_poruka out varchar2,
p_datnal date, --sa forme
p_datdok date, --sa forme
p_datval date, --sa forme
p_brdok varchar2, --sa forme
p_operater varchar2
)
AS
ulaz utl_file.FILE_TYPE;
izlaz utl_file.FILE_TYPE;
EOF boolean;
br_upisanih number;
br_procitanih number;
komad varchar(1024);
--l_komad varchar2(1024);
--l_knjiga knjiga_stetnika_svi%rowtype;
l_anlanl anlanl%rowtype;
l_nalog nalog%rowtype;
l_brnal number;

BEGIN
  EOF := FALSE;
  dbms_output.enable(100000);
  begin
    izlaz := utl_file.fopen ( p_put_do_fajla, p_ime_fajla || '.log', 'w' );
    ulaz  := utl_file.fopen ( p_put_do_fajla, p_ime_fajla || '.csv', 'r' );
    utl_file.put_line ( izlaz, 'Otvaram.' );
  exception when utl_file.invalid_path then
    p_poruka := 'FOPEN:invalid_path';
    utl_file.put_line ( izlaz, 'FOPEN:invalid_path' );
    return;
  when utl_file.invalid_mode then
    p_poruka := 'FOPEN:invalid_mode';
    utl_file.put_line ( izlaz, 'FOPEN:invalid_mode' );
    return;
  when utl_file.invalid_operation then
    p_poruka := 'FOPEN:invalid_operation';
    utl_file.put_line ( izlaz, 'FOPEN:invalid_operation' );
    return;
  when others then
    p_poruka := 'Greška: ' || sqlerrm;
    return;
  end;

  if ( utl_file.is_open ( ulaz ) ) then
    utl_file.put_line ( izlaz, 'Čitam...' );
    br_upisanih := 0;
    br_procitanih := 0;
    
    select nvl ( max ( nal_nalog ), to_char ( p_datnal, 'rr' ) * 10000 ) + 1
    into l_brnal
    from nalog
    where nal_vlasnik = 1 --:global.firma
    and  nal_radnja = 2 --:global.finpreduzece
    and nal_vsdok = 311 --:global.vsdok;
    and to_char ( datnal, 'rrrr' ) = to_char ( p_datnal, 'rrrr' );
    
      l_anlanl.ANL_STAVKA := 1;
    
      l_nalog.NAL_NALOG := l_brnal;
      l_nalog.DATNAL := p_datnal;

      insert into NALOG
      ( NAL_VLASNIK, NAL_RADNJA, NAL_VSDOK, NAL_NALOG, DATNAL, ZAKLJUCEN, TOTAL_DUGUJE, TOTAL_POTRAZUJE, SALDO_DUGUJE, SALDO_POTRAZUJE, DATUMOBRADE, SIFOPERAT)
      values
      --(1, 2, 311, l_nalog.NAL_NALOG, l_nalog.DATNAL, 1, 0, 0, 0, 0, to_date(sysdate, 'dd.mm.rrrr'), 'admin');
      (1, 2, 311, l_nalog.NAL_NALOG, l_nalog.DATNAL, 1, 0, 0, 0, 0, to_date(sysdate, 'dd.mm.rrrr'), p_operater);
    
    loop
      begin
           utl_file.get_line ( ulaz, komad );
        br_procitanih := br_procitanih + 1;
        
        if instr ( komad, p_delimiter, 1, 3 ) = 0 then
          utl_file.put_line ( izlaz, 'Ne postoji dovoljan broj kolona:' || komad);
        else
          
            l_anlanl.ANL_NALOG := l_brnal;
            l_anlanl.DATDOK := p_datdok;
            l_anlanl.DUGUJE := ltrim ( rtrim ( substr ( komad, 1, instr ( komad, p_delimiter, 1, 1 ) - 1 ) ) );
            l_anlanl.POTRAZUJE := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 1 ) + 1, instr ( komad, p_delimiter, 1, 2 ) - instr ( komad, p_delimiter, 1, 1 ) - 1 ) ) );
            l_anlanl.RJ := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 2 ) + 1, instr ( komad, p_delimiter, 1, 3 ) - instr ( komad, p_delimiter, 1, 2 ) - 1 ) ) );
            l_anlanl.DATVAL := p_datval;
            l_anlanl.DATNAL := p_datnal;
            l_anlanl.BRDOK := p_brdok;
            l_anlanl.KONTO := ltrim ( rtrim ( substr ( komad, instr ( komad, p_delimiter, 1, 3 ) + 1 ) ) );
                
            insert into ANLANL
            (ANL_VLASNIK, ANL_RADNJA, ANL_VSDOK, ANL_NALOG, ANL_STAVKA, DATDOK, DUGUJE, POTRAZUJE, DEV_DUGUJE, DEV_POTRAZUJE, KOMITENT, JMBG, RJ, DATVAL, KOL, DATNAL, BRDOK, VALUTA, KONTO, DATUMOBRADE, SIFOPERAT)
            values
            --(1, 2, 311, l_anlanl.ANL_NALOG, l_anlanl.ANL_STAVKA, l_anlanl.DATDOK, l_anlanl.DUGUJE, l_anlanl.POTRAZUJE, l_anlanl.DUGUJE, l_anlanl.POTRAZUJE, 1, 0, l_anlanl.RJ,  l_anlanl.DATVAL, 0, l_anlanl.DATNAL, l_anlanl.BRDOK, 977, l_anlanl.KONTO, to_date(sysdate, 'dd.mm.rrrr'), 'admin');
            (1, 2, 311, l_anlanl.ANL_NALOG, l_anlanl.ANL_STAVKA, l_anlanl.DATDOK, l_anlanl.DUGUJE, l_anlanl.POTRAZUJE, l_anlanl.DUGUJE, l_anlanl.POTRAZUJE, 1, 0, l_anlanl.RJ,  l_anlanl.DATVAL, 0, l_anlanl.DATNAL, l_anlanl.BRDOK, 977, l_anlanl.KONTO, to_date(sysdate, 'dd.mm.rrrr'), p_operater);
                
             l_anlanl.ANL_STAVKA :=  l_anlanl.ANL_STAVKA + 1;

          
          if sql%found then
            br_upisanih := br_upisanih + 1;
          end if;
--          utl_file.put_line ( izlaz, l_knjiga.broj_stete || '*****' || instr ( komad, p_delimiter, 1, 1 ));
        end if;
      exception    
        when no_data_found then EOF := TRUE;
        when others then utl_file.put_line ( izlaz, 'Greška: ' || sqlerrm || '--' || komad );
      end;
      exit when EOF;
    end loop;
  end if;
  commit;
  
 update NALOG
 set TOTAL_DUGUJE = (select sum(A.DUGUJE)
                     from ANLANL a
                     where A.ANL_VLASNIK = 1
                     and A.ANL_RADNJA = 2 
                     and ANL_VSDOK = 311
                     and a.ANL_NALOG = l_brnal)
 where NAL_VLASNIK = 1
 and NAL_RADNJA = 2
 and NAL_VSDOK = 311
 and NAL_NALOG = l_brnal;
 
 update NALOG
 set TOTAL_POTRAZUJE = (select sum(A.POTRAZUJE)
                        from ANLANL a
                        where A.ANL_VLASNIK = 1
                        and A.ANL_RADNJA = 2 
                        and ANL_VSDOK = 311
                        and a.ANL_NALOG = l_brnal)
 where NAL_VLASNIK = 1
 and NAL_RADNJA = 2
 and NAL_VSDOK = 311
 and NAL_NALOG = l_brnal;
 
    update NALOG
    set ZAKLJUCEN = (select case when N.TOTAL_DUGUJE = N.TOTAL_POTRAZUJE then 1 else 0 end
                                from NALOG n
                                where nal_vlasnik = 1
                                and  nal_radnja = 2
                                and nal_vsdok = 311
                                and nal_nalog = l_brnal)
    where nal_vlasnik = 1
    and  nal_radnja = 2
    and nal_vsdok = 311
    and nal_nalog = l_brnal;
  
   commit;
 
  p_upisano := br_upisanih;
  utl_file.put_line ( izlaz, 'Zatvaram.' );
  utl_file.put_line ( izlaz, 'Ukupno pročitano: ' || br_procitanih );
  utl_file.put_line ( izlaz, 'Ukupno upisano: ' || br_upisanih );
  utl_file.fclose ( ulaz );
  utl_file.fclose ( izlaz );
exception when others then
  rollback;
  p_poruka := 'Greška: ' || sqlerrm;
  utl_file.put_line ( izlaz, 'Zatvaram.' || 'Greška: ' || sqlerrm );
  utl_file.fclose ( ulaz );
  utl_file.fclose ( izlaz );
END IMP_PLATE_KNJIZENJA;

/

