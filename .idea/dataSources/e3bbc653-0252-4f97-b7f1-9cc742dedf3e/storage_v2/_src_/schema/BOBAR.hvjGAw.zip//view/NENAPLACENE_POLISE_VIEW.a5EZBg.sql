create view NENAPLACENE_POLISE_VIEW as
  select  baza.KOMITENT, baza.KONTO, baza.POL_BRPOL,
  case when sysdate - max(A.DATVAL) is null then -1 else sysdate - max(A.DATVAL) end kasnjenje, max(A.DATVAL) datprip, baza.duguje iznos, baza.saldo iznos_preostali
    from
    (
    select A.KONTO, A.KOMITENT, A.POL_BRPOL, sum(A.DEV_DUGUJE) duguje, sum(A.DEV_POTRAZUJE) potrazuje,
    sum(A.DEV_DUGUJE) - sum(A.DEV_POTRAZUJE) saldo 
    from anlanl a, komitent k
    where A.KOMITENT = K.KOM_SIFRA
    and K.POVEZANO_LICE = 1
    and A.KOMITENT in
    (select K.KOM_SIFRA
    from komitent k
    where K.POVEZANO_LICE = 1)
    and A.DATDOK between to_date('01.01.'||to_char(sysdate,'rrrr'),'dd.mm.rrrr') and sysdate
    and A.KONTO in (select kon_sifra from konto where kon_sifra between '15100' and '23860' and status = 1)
    group by A.KONTO, A.KOMITENT, A.POL_BRPOL,
    A.POL_BRPOL
    having sum(A.DEV_DUGUJE) - sum(A.DEV_POTRAZUJE) > 0
    ) baza, anlanl a
    where baza.pol_brpol = A.POL_BRPOL(+)
    and baza.konto = A.KONTO(+)
    and baza.komitent = A.KOMITENT(+)
    group by baza.KONTO, baza.KOMITENT, baza.POL_BRPOL, baza.duguje, baza.SALDO

/

