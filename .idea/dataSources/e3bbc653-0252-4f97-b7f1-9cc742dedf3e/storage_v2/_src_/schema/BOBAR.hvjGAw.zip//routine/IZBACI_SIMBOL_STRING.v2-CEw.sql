create FUNCTION IZBACI_SIMBOL_STRING (p_str in varchar) RETURN VARCHAR2 AS 
BEGIN
  return replace(REPLACE(p_str,'-',NULL),',',null);
END IZBACI_SIMBOL_STRING;

/

