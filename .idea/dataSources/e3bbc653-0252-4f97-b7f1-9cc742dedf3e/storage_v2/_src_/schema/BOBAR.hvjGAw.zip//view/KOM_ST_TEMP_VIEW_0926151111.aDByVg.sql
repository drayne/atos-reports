create view KOM_ST_TEMP_VIEW_0926151111 as
  select komitent, anl_nalog, anl_vsdok, datnal, datdok, datval, brdok, pol_brpol, opis, zatvoren, dev_duguje duguje, dev_potrazuje potrazuje from anlanl where komitent between 131178 and 131178 and anl_vlasnik between 1 and 1 and anl_radnja between 2 and 2 and anl_vsdok not in (300) and trunc(datnal) between to_date('01.01.17') and to_date('30.09.17') and konto between '20100' and '20971'

/

