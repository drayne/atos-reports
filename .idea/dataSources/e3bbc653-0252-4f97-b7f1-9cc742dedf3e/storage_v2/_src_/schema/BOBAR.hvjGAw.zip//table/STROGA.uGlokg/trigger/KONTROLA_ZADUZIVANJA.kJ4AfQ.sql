create trigger KONTROLA_ZADUZIVANJA
  before insert or update
  on STROGA
  for each row
  declare 
nesto         number:=0;
privilegija   number:=0;
datum         date;
datum_storno  date;
zastupnik     number:=0;
begin

  -- datum storniranja mora biti u istoj godini u kojoj je i zadnja promjena dokumenta
  if /*INSERTING and*/ :new.svsprom in (22,24) then
    select nvl(max (str_datumpromene),sysdate) into datum_storno
    from stroga 
    where str_vsdok=:new.str_vsdok and str_brojdok=:new.str_brojdok;
    if to_char(datum,'rrrr')<>to_char(:new.str_datumpromene,'rrrr') then
      RAISE_APPLICATION_ERROR(-20000, 'Godina storniranja mora biti u '||to_char(datum,'rrrr'));
    end if;
  end if;
  
  -- promjene koje nastaju u strogoj moraju biti datumski hronološki redane
  if INSERTING and :new.svsprom <> 1 then
    select nvl(max (str_datumpromene),sysdate) into datum
    from stroga 
    where str_vsdok=:new.str_vsdok and str_brojdok=:new.str_brojdok;
    if to_char(datum,'rrrrmmdd')>to_char(:new.str_datumpromene,'rrrrmmdd') then
      RAISE_APPLICATION_ERROR(-20000, 'Prethodna promjena za dokument '||:new.str_vsdok||'/'||:new.str_brojdok
      ||' je sa vecim datumom nego ovaj '||to_char(:new.str_datumpromene,'dd.mm.rrrr'));
    end if;
  end if;
  
  -- promjene koje nastaju u strogoj moraju biti hronološki redane po zastupnicima
  if INSERTING and :new.svsprom <> 1 then
    select mbrzastupprima into zastupnik from stroga s
    where s.id=(select max(ss.id) from stroga ss where s.str_vsdok=ss.str_vsdok and s.str_brojdok=ss.str_brojdok)
    and str_vsdok=:new.str_vsdok and str_brojdok=:new.str_brojdok;
    if zastupnik<>:new.mbrzastupprima and :new.svsprom in (21,22,23,24) then
      RAISE_APPLICATION_ERROR(-20000, 'Prethodna promjena za dokument '||:new.str_vsdok||'/'||:new.str_brojdok
      ||' je na drugom zastupniku!');
    end if;
  end if;
  
  -- provjera da li zastupnik koji daje aktivan
  for red in (select * from zastup where zas_sifra in (:new.mbrzastupdaje)) loop
   if red.aktivan=0 then
    RAISE_APPLICATION_ERROR(-20000, 'Zastupnik '|| :new.mbrzastupdaje||'-'||red.naziv||' koji daje je neaktivan!'); 
   end if;   
  end loop;
  -- provjera da li je zastupnik koji prima aktivan
  for red in (select * from zastup where zas_sifra in (:new.mbrzastupprima)) loop
   if red.aktivan=0 then
    RAISE_APPLICATION_ERROR(-20000, 'Zastupnik '|| :new.mbrzastupprima||'-'||red.naziv||' koji prima je neaktivan!'); 
   end if;   
  end loop;
  
  -- provjera da li je šifra privilegije = 1, ako jeste to znači da ne može snimati promjene  
  select count(zastupnik) into privilegija from operater o where trim(o.korisnik)=trim(:new.sifoperat)
  and nvl(o.zastupnik,0)=1;
  if privilegija = 1 then
    raise_application_error(-20000, 'Za operatera '||:new.sifoperat||' nije dozvoljeno razduzivanje zastupnika!');
  else
    -- ako nije onda tražimo privilegiju sa kojom je operater vezan
    privilegija:=0;  
    -- provjera da li operater može da razduži zastupnika ili pravi bilo kakve promjene u strogoj
    select count(zastupnik) into privilegija from operater o where trim(o.korisnik)=trim(:new.sifoperat)
    and nvl(o.zastupnik,0)>1;
    if :new.svsprom in (1,11,21,22,23,24) and privilegija>0 then  
      select count(*) into nesto from operater o, zastup_grupe zg
      where o.zastupnik=zg.grp_zastup 
      and trim(o.korisnik)=trim(:new.sifoperat) 
      and decode(nvl(zg.ko,0),99999,nvl(:new.mbrzastupdaje,0),nvl(zg.ko,0))=nvl(:new.mbrzastupdaje,0) 
      and decode(nvl(zg.koga,0),99999,nvl(:new.mbrzastupprima,0),nvl(zg.koga,0))=nvl(:new.mbrzastupprima,0)
      and to_char(:new.svsprom) = zg.sta;
      if nesto=0 then
        raise_application_error(-20000, 'Za operatera '||:new.sifoperat||' nije dozvoljeno zaduzivanje '||:new.mbrzastupdaje||' >>>>> '||:new.mbrzastupprima
        || ' po vrsti promjene '||:new.svsprom); 
      end if;
    end if;  
  end if;
end;


/

