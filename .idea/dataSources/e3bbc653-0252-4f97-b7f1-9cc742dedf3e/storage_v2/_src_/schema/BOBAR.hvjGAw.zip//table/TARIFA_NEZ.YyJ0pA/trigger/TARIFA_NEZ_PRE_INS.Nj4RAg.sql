create trigger TARIFA_NEZ_PRE_INS
  before insert
  on TARIFA_NEZ
  for each row
  begin
 select tarifa_nez_seq.nextval into :new.id from dual;
end;


/

