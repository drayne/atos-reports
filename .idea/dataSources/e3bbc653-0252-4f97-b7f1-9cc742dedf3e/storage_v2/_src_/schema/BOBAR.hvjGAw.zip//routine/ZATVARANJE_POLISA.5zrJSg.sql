create FUNCTION          "ZATVARANJE_POLISA"  (
    p_datum_od date, p_datum_do date, p_konta varchar2, p_komitenti varchar2 ) return number
as
  l_konto number;
  l_komitent number;
  l_rasporedi number;
  l_iznos number;
  preostao_iznos number := 0;
  cursor iznosi is select komitent, konto, sum ( dev_potrazuje ) potrazuje, sum ( dev_duguje ) duguje
                    from /*( select distinct osigdug
                             from ( select osigdug from semakont
                                    union
                                    select osigdug from semakont_im ) ) semkont,*/
                         anlanl
                   where anlanl.konto in ( select *
							 			              			  		  from THE ( select cast ( str2tbl ( p_konta )
							 			              										 										 as moja_konta )
							 			              						 											from dual ) ) and
--                   			 semkont.osigdug = anlanl.konto and
												 anlanl.komitent in ( select *
							 			              			  		  from THE ( select cast ( str2tbl ( p_komitenti )
							 			              										 										 as moja_konta )
							 			              						 											from dual ) ) and
                         anlanl.datdok between p_datum_od and p_datum_do and
--                         anlanl.anl_vsdok <> 301 and
--                         nvl ( dev_potrazuje, 0 ) <> 0 and
                         anlanl.anl_radnja = 2 and
                         nvl ( dev_duguje, 0 ) <= 0
                group by komitent, konto
                order by komitent, konto;

  cursor iznosi_konto is select komitent, konto, sum ( dev_potrazuje ) potrazuje, sum ( dev_duguje ) duguje
                    from /*( select distinct osigdug
                             from ( select osigdug from semakont
                                    union
                                    select osigdug from semakont_im ) ) semkont,*/
                         anlanl
                   where anlanl.konto in ( select *
							 			              			  		  from THE ( select cast ( str2tbl ( p_konta )
							 			              										 										 as moja_konta )
							 			              						 											from dual ) ) and
--                   			 semkont.osigdug = anlanl.konto and
                         anlanl.datdok between p_datum_od and p_datum_do and
--                         anlanl.anl_vsdok <> 301 and
--                         nvl ( dev_potrazuje, 0 ) <> 0 and
                         anlanl.anl_radnja = 2 and
                         nvl ( dev_duguje, 0 ) <= 0
                group by komitent, konto
                order by komitent, konto;

  cursor iznosi_komitent is select komitent, konto, sum ( dev_potrazuje ) potrazuje, sum ( dev_duguje ) duguje
                    from ( select distinct osigdug
                             from ( select osigdug from semakont
                                    union
                                    select osigdug from semakont_im ) ) semkont,
                         anlanl
                   where semkont.osigdug = anlanl.konto and
												 anlanl.komitent in ( select *
							 			              			  		  from THE ( select cast ( str2tbl ( p_komitenti )
							 			              										 										 as moja_konta )
							 			              						 											from dual ) ) and
                         anlanl.datdok between p_datum_od and p_datum_do and
--                         anlanl.anl_vsdok <> 301 and
--                         nvl ( dev_potrazuje, 0 ) <> 0 and
                         anlanl.anl_radnja = 2 and
                         nvl ( dev_duguje, 0 ) <= 0
                group by komitent, konto
                order by komitent, konto;

  cursor iznosi_sva is select komitent, konto, sum ( dev_potrazuje ) potrazuje, sum ( dev_duguje ) duguje
                    from ( select distinct osigdug
                             from ( select osigdug from semakont
                                    union
                                    select osigdug from semakont_im ) ) semkont,
                         anlanl
                   where semkont.osigdug = anlanl.konto and
                         anlanl.datdok between p_datum_od and p_datum_do and
--                         anlanl.anl_vsdok <> 301 and
--                         nvl ( dev_potrazuje, 0 ) <> 0 and
                         anlanl.anl_radnja = 2 and
                         nvl ( dev_duguje, 0 ) <= 0
                group by komitent, konto
                order by komitent, konto;

  cursor zatvaranje is select rowid, konto, komitent, dev_duguje
                         from anlanl
                        where anlanl.datdok between p_datum_od and p_datum_do and
--                              anlanl.anl_vsdok <> 301 and
                              anlanl.anl_radnja = 2 and
                              nvl ( dev_duguje, 0 ) <> 0 and
                              konto = l_konto and
                              komitent = l_komitent
                     order by komitent, konto, datdok for update;
begin

	if p_konta = 'sva' and p_komitenti = 'svi' then
	 for cur_rec1 in iznosi_sva loop
	   l_konto := cur_rec1.konto;
	   l_komitent := cur_rec1.komitent;
	   l_iznos := cur_rec1.potrazuje - cur_rec1.duguje;
	   for cur_rec2 in zatvaranje loop
	    if cur_rec2.dev_duguje <= l_iznos then
	      l_rasporedi := cur_rec2.dev_duguje;
	    elsif cur_rec2.dev_duguje > l_iznos and l_iznos > 0 then
	      l_rasporedi := l_iznos;
	    else
	      l_rasporedi := null;
	    end if;
	    update anlanl set zatvoren_iznos = l_rasporedi where rowid = cur_rec2.rowid;
	    l_iznos := l_iznos - nvl ( l_rasporedi, 0 );
	   end loop;
	 end loop;
	elsif p_konta = 'sva' and p_komitenti <> 'svi' then
	 for cur_rec1 in iznosi_komitent loop
	   l_konto := cur_rec1.konto;
	   l_komitent := cur_rec1.komitent;
	   l_iznos := cur_rec1.potrazuje - cur_rec1.duguje;
	   for cur_rec2 in zatvaranje loop
	    if cur_rec2.dev_duguje <= l_iznos then
	      l_rasporedi := cur_rec2.dev_duguje;
	    elsif cur_rec2.dev_duguje > l_iznos and l_iznos > 0 then
	      l_rasporedi := l_iznos;
	    else
	      l_rasporedi := null;
	    end if;
	    update anlanl set zatvoren_iznos = l_rasporedi where rowid = cur_rec2.rowid;
	    l_iznos := l_iznos - nvl ( l_rasporedi, 0 );
	   end loop;
	 end loop;
	elsif p_konta <> 'sva' and p_komitenti = 'svi' then
	 for cur_rec1 in iznosi_konto loop
	   l_konto := cur_rec1.konto;
	   l_komitent := cur_rec1.komitent;
	   l_iznos := cur_rec1.potrazuje - cur_rec1.duguje;
	   for cur_rec2 in zatvaranje loop
	    if cur_rec2.dev_duguje <= l_iznos then
	      l_rasporedi := cur_rec2.dev_duguje;
	    elsif cur_rec2.dev_duguje > l_iznos and l_iznos > 0 then
	      l_rasporedi := l_iznos;
	    else
	      l_rasporedi := null;
	    end if;
	    update anlanl set zatvoren_iznos = l_rasporedi where rowid = cur_rec2.rowid;
	    l_iznos := l_iznos - nvl ( l_rasporedi, 0 );
	   end loop;
	 end loop;
	else
	 for cur_rec1 in iznosi loop
	   l_konto := cur_rec1.konto;
	   l_komitent := cur_rec1.komitent;
	   l_iznos := cur_rec1.potrazuje - cur_rec1.duguje;
	   for cur_rec2 in zatvaranje loop
	    if cur_rec2.dev_duguje <= l_iznos then
	      l_rasporedi := cur_rec2.dev_duguje;
	    elsif cur_rec2.dev_duguje > l_iznos and l_iznos > 0 then
	      l_rasporedi := l_iznos;
	    else
	      l_rasporedi := null;
	    end if;
	    update anlanl set zatvoren_iznos = l_rasporedi where rowid = cur_rec2.rowid;
	    l_iznos := l_iznos - nvl ( l_rasporedi, 0 );
	   end loop;
	 end loop;
	end if;
 commit;
 return 1;
exception when others then
  return 0;
end;

/

