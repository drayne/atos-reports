create PROCEDURE job_PUNI_KNJIGA_STETNIKA_SVI AS
broj number:=0;
BEGIN
  select count(*) into broj from  prijstet p , knjigastao 
  where p.id= knjigastao.prijstet_id and p.vros=800
  and p.datumprijave >= '01-oct-03' 
  and (LTRIM(RTRIM(knjigastao.MBROSI)) IS NOT NULL) and (P.BRPOLISE <> '9999999999')
  and not EXISTS (select * from knjiga_stetnika_svi where id= p.id );
  
  insert into knjiga_stetnika_svi (ID,BROJ_STETE,DATUM_PRIJAVE,DATUM_NASTANKA,OSIGURANIK,JMBG,TIP_VOZILA,REGISTARSKA_OZNAKA,BROJ_POLISE,IZNOS_STETE
  ,DATUM_LIKVIDACIJE,VOZAC, osig_kuca)
  select p.id, p.prst_brstete||'/'||p.prst_godina as brojstete, to_char(p.datumprijave,'dd.mm.rrrr') as datumprijave,
  to_char(p.datumnastanka,'dd.mm.rrrr') as datumnastanka,
  knjigastao.nazivosi osiguranik, knjigastao.mbrosi jmbg,
  --DECODE (LENGTH(KNJIGASTAO.TARGRUPA),1,'0' || KNJIGASTAO.TARGRUPA, KNJIGASTAO.TARGRUPA) || DECODE (LENGTH(KNJIGASTAO.TARPODGRUPA),1,'0' || KNJIGASTAO.TARPODGRUPA,KNJIGASTAO.TARPODGRUPA) tipvozila,
  knjigastao.markaosi||', '||knjigastao.tiposi as tipvozila,
  knjigastao.regbrosi as regoznaka, p.brpolise as brojpolise, to_char(p.iznos_prijavljen,'99G999G999D99') as iznosstete,
  to_char(p.datumobracuna,'dd.mm.rrrr') as datumlikvidacije, knjigastao.nazivvozosi as vozac,'Bobar' as osig_kuca
  from prijstet p , knjigastao 
  where p.id= knjigastao.prijstet_id and p.vros=800
  and p.datumprijave >= '01-oct-03' 
  and (LTRIM(RTRIM(knjigastao.MBROSI)) IS NOT NULL) and (P.BRPOLISE <> '9999999999')
  and not EXISTS (select * from knjiga_stetnika_svi where id= p.id );
  
  for red in (  select k.rowid,k.broj_stete,k.iznos_stete,to_char(p.iznos_prijavljen,'999G999G999D99') iznos
                from knjiga_stetnika_svi k, prijstet p
                where k.id=p.id and trim(k.iznos_stete)<>trim(to_char(p.iznos_prijavljen,'999G999G999D99')) 
              ) loop
  update knjiga_stetnika_svi set iznos_stete=trim(red.iznos) where rowid=red.rowid;
end loop;

  commit;
  --posalji_sms('065638700','Ukupno importovano slogova knjige štetnika je '||broj);
END job_PUNI_KNJIGA_STETNIKA_SVI;

/

