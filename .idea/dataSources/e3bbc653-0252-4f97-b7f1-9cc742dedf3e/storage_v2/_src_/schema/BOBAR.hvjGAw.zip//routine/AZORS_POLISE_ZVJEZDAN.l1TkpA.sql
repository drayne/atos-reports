create function azors_polise_zvjezdan ( p_datum_od date, p_datum_do date, p_fajl varchar2, p_broj_redova out number ) return VARCHAR2 is 
  result XMLTYPE; 
  v_clob clob; 
  izlaz utl_file.FILE_TYPE;
  logfl utl_file.FILE_TYPE;
  l_broj number;
  l_kod_osig varchar2(128) := 'RD-7';
  l_rbr number;
  l_UniqueID varchar2(128);
begin 

  execute immediate 'alter session set nls_numeric_characters=''.,''';
 
  select nvl ( max ( rbr ), 0 ) + 1 into l_rbr    
    from azors_slanje    
   where to_char ( datum, 'rrrr' ) = to_char ( sysdate, 'rrrr' ) and    
         vrsta = 'POLISA';    
  l_UniqueID := 'P-' || l_kod_osig || '-' || to_char ( sysdate, 'rrrr' ) || '-' || lpad ( l_rbr, 5, '0' );    

  insert into azors_slanje ( broj_polise, vsdok, datum, rbr, vrsta, unique_id, datum_od, datum_do )
            ( select to_number ( polisa.pol_brpol ), polisa.vsdok, sysdate, l_rbr, 'POLISA', l_UniqueID, p_datum_od, p_datum_do     
               from polisa, orgjed, tarifa, polao3, zastup, mesto m_izdavanja, mesto m_ugov, polao2, popdop popust, popdop doplatak, opstina, bonus_malus, tep.ddor ddor
              where polisa.vsdok in ( 1, 4 ) and
                    polisa.datdok >= to_date ( '01.01.2010', 'dd.mm.rrrr' ) and
                    polisa.azors_slanje_id is null and
                    ( ( polisa.datdok between p_datum_od and p_datum_do and    
                        not exists ( select * 
                                       from rate
                                      where polisa.pol_brpol = rate.rat_brpol and
                                            polisa.vsdok = rate.vsdok and
                                            statusrate = 0 ) )  ) and
                    polisa.oj = orgjed.oj_sifra and
                    polisa.brosk is not null and
                    polisa.tar = tarifa.tar_tar and
                    polisa.vros = tarifa.tar_vros and
                    polisa.pol_brpol = polao3.ao3_brpol and
                    polisa.vsdok = polao3.vsdok and
                    polisa.mbrzastup = zastup.zas_sifra and
                    polisa.pttm = m_izdavanja.mes_sifra and
                    m_izdavanja.opst = opstina.ops_sifra and
                    polisa.pttmug = m_ugov.mes_sifra(+) and
                    polisa.pol_brpol = polao2.ao2_brpol and
                    polisa.vsdok = polao2.vsdok and
                    polao3.sif_popusta = popust.pd_sifra(+) and
                    polao3.sif_doplatka = doplatak.pd_sifra(+) and
                    popust.pd_vros(+) = 800 and
                    doplatak.pd_vros(+) = 800 and
                    polao3.bonusmalus = bonus_malus.sifra(+) and
                    polisa.osig_ostali = ddor.sifra(+));

  select count(*) into p_broj_redova
    from azors_slanje
   where unique_id = l_UniqueID;

  begin
    izlaz := utl_file.fopen ( 'PISI', l_UniqueID || '.xml', 'w' );
    logfl:= utl_file.fopen ( 'PISI', l_UniqueID || '.log', 'w' );
    utl_file.put_line ( logfl, 'Otvoren...' );
  exception 
    when utl_file.invalid_path then
      utl_file.put_line ( logfl, 'FOPEN:invalid_path' );
    when utl_file.invalid_mode then
      utl_file.put_line ( logfl, 'FOPEN:invalid_mode' );
    when utl_file.invalid_operation then
      utl_file.put_line ( logfl, 'FOPEN:invalid_operation' );
  end;

  utl_file.put_line ( logfl, p_broj_redova );

  if ( utl_file.is_open ( izlaz ) ) then
    for cur_rec in ( 
      select xmlElement
       (
         "InsuranceBatch",
         xmlAttributes( 'http://www.w3.org/2001/XMLSchema-instance' as "xmlns:xsi", 'http://www.w3.org/2001/XMLSchema' as "xmlns:xsd", 'http://www.azors.org/xmlschemas/data/InsuranceBatch' as "xmlns" ),
          xmlElement
           (
             "Header",
             xmlElement
             (
               "Info",
               xmlForest
               (
                  l_kod_osig as "Provider", 
                  to_char ( sysdate, 'rrrr-mm-dd' ) || 'T' || to_char ( systimestamp, 'hh24:mi:ss.ff7TZH:TZM' ) as "Timestamp", 
                  l_UniqueID as "BatchUniqueId",
                  p_broj_redova as "NumberOfRecords"
               )
             ),
          xmlelement ( "RequestReportDelivery", 
                xmlelement ( "SendTo" , 'office@bobar.com' )
                )),
          xmlElement
           (
             "Body",
             xmlagg ( xmlElement
             (
               "MotorVehicleInsurance",
               xmlAttributes ( 'http://www.azors.org/xmlschemas/data/Insurance' AS "xmlns" ),
               xmlelement ( "InsuranceCompanyCode",
                            xmlattributes ( 'http://www.azors.org/xmlschemas/data/Common' AS "xmlns" ),
                            l_kod_osig || '-0001' ),
               xmlelement ( "SourceRecordIdentifier", pol_brpol || '-' || vsdok ),
               xmlelement ( "SourcePolicyIdentifier", pol_brpol || '-' || vsdok ),
               xmlelement ( "InsuranceTypeCode", xmlattributes ( 'http://www.azors.org/xmlschemas/data/Common' AS "xmlns" ),
                            substr ( nbs, 1, 2 ) ),
               xmlelement ( "InsuranceSubTypeCode", xmlattributes ( 'http://www.azors.org/xmlschemas/data/Common' AS "xmlns" ),
                            substr ( nbs, 3 ) ),
               xmlelement ( "PremiumGroupCode", xmlattributes ( 'http://www.azors.org/xmlschemas/data/Common' AS "xmlns" ),
                            lpad ( to_char ( targrupa ), 2, '0' ) ),
               xmlelement ( "PremiumSubGroupCode", xmlattributes ( 'http://www.azors.org/xmlschemas/data/Common' AS "xmlns" ),
                            decode ( vsdok, 4, '01', lpad ( to_char ( decode ( targrupa, 2, decode ( tarpodgrupa, 10, 9, tarpodgrupa ), tarpodgrupa )), 2, '0' ) ) ),
               xmlelement ( "BasicPremiumSum", ltrim ( to_char ( osnpremao, '9999990.00' ) ) ),
               xmlelement ( "InsurancePolicyNumber", xmlattributes ( 'http://www.azors.org/xmlschemas/data/Common' AS "xmlns" ),
                            pol_brpol ),
               decode ( broj_zk, null, null, xmlelement ( "GreenCardNumber", broj_zk ) ),
               xmlelement ( "AgentCode", nvl ( agencija_reg_broj, 'RZ-1-000' ) ),
               decode ( nvl ( zampol, '0' ), '0', decode ( brpol_ostali, null, null, xmlelement ( "PreviousInsuranceCompanyCode", ddor_azors ) ), xmlelement ( "PreviousInsuranceCompanyCode", l_kod_osig ) ),
               decode ( nvl ( zampol, '0' ), '0', decode ( brpol_ostali, null, null, xmlelement ( "PreviousInsurancePolicyNumber", brpol_ostali ) ), xmlelement ( "PreviousInsurancePolicyNumber", zampol ) ),
               xmlelement ( "InsuranceContractDate", to_char ( datdok, 'rrrr-mm-dd' ) || 'T00:00:00.0000000' || to_char ( systimestamp, 'TZH:TZM' ) ),
               xmlelement ( "InsuranceContractPlace", opstina_azors ),
               xmlelement ( "InsuranceStartDate", to_char ( datpoc, 'rrrr-mm-dd' ) || 'T23:59:00.0000000' || to_char ( systimestamp, 'TZH:TZM' ) ),
               xmlelement ( "InsuranceExpiryDate", to_char ( datist, 'rrrr-mm-dd' ) || 'T23:59:00.0000000' || to_char ( systimestamp, 'TZH:TZM' ) ),
               xmlelement ( "InsurancePremiumClass", lpad ( nvl ( premijski_razred, '6' ), 2, '0' ) ),
               xmlelement ( "InsurancePremiumRate", decode ( bonus_malus, 'B', 100 - procenat_bm, 'M', 100 + procenat_bm, 100 ) ),
               xmlelement ( "InsurancePremiumSum", ltrim ( to_char ( uk_prem_ano + nvl ( izn_doplatka, 0 ) + nvl ( izn_popusta, 0 ) + stdok_premija, '9999990.00' ) ) ),
               xmlelement ( "InsurancePremiumCurrency", 'BAM' ),
               xmlelement ( "DiscountAndAdditions", popust_azors || decode ( popust_azors, null, decode ( doplatak_azors, null, null, '.' ), '.' ) || doplatak_azors ),
               xmlelement ( "AssetInsuranceSum", '350000.00' ),
               xmlelement ( "AssetInsuranceCurrency", 'BAM' ),
               xmlelement ( "InjuryInsuranceSum", '1000000.00' ),
               xmlelement ( "InjuryInsuranceCurrency", 'BAM' ),
               xmlelement ( "InsuranceStatusCode", decode ( datum_prestanka_vazenja, null, 'A', 'S' ) ),
               xmlelement ( "InsuranceStatusDate", decode ( datum_prestanka_vazenja, null, to_char ( datpoc, 'rrrr-mm-dd' ), to_char ( datum_prestanka_vazenja, 'rrrr-mm-dd' ) ) ),
               xmlelement ( "DataImportDate", to_char ( sysdate, 'rrrr-mm-dd' ) ),
               decode ( bm_prenos_polisa, null, null, xmlelement ( "BonusMalusPolicyNumber", bm_prenos_polisa ) ),
               decode ( bm_prenos_polisa, null, null, xmlelement ( "BonusMalusTransferred", 'Y' ) ),
               xmlelement ( "Insured", 
                 xmlelement ( "Customer", xmlattributes ( 'http://www.azors.org/xmlschemas/data/Common' AS "xmlns" ),
                    xmlelement ( "Name", convert ( nazivugov, 'UTF8' ) ),
                    xmlelement ( "TypeOfEntity", decode ( sektor, 1, 'P', 2, 'F', 'F' ) ),
                    xmlelement ( "IdentificationNumber", lpad ( nvl ( jmbg, '1' ), 13, '0' ) ),
                    xmlelement ( "Address", 
                      xmlelement ( "Street", convert ( adresa, 'UTF8' ) ),
                      xmlelement ( "City", convert ( mesto_ugov, 'UTF8' ) ),
                      xmlelement ( "PostCode", pttmug )))),
               xmlelement ( "InsuredVehicle", 
                 xmlelement ( "VehicleRegistrationNumber", xmlattributes ( 'http://www.azors.org/xmlschemas/data/Common' AS "xmlns" ), convert ( regbroj, 'UTF8' ) ),
                 xmlelement ( "VehicleTypeCode", lpad ( to_char ( targrupa ), 2, '0' ) ),
                 xmlelement ( "VehicleIdentificationNumber", xmlattributes ( 'http://www.azors.org/xmlschemas/data/Common' AS "xmlns" ), convert  ( nvl ( brojsasije, '1' ), 'UTF8' ) ),
                 decode ( godproizv, null, null, xmlelement ( "ProductionYear", godproizv ) ),
                 xmlelement ( "MaxPower", nvl ( snagakw, 0 ) ),
                 xmlelement ( "MaxLoad", nvl ( ltrim ( to_char ( nosivostkg, '999G990D00' ) ), 0 ) ),
                 xmlelement ( "SeatingCapacity", nvl ( brojmesta, 0 ) ),
                 xmlelement ( "EngineCapacity", nvl ( zapreminaccm, 0 ) ),
                 decode ( brojmotora, null, null, xmlelement ( "EngineNumber", convert ( brojmotora, 'UTF8' ))))
             ))
           )).extract('/*') as result 
      from ( select polisa.pol_brpol, 
                    polisa.vsdok, 
                    polisa.nazivugov,
                    polisa.sektor,
                    polisa.mbr,
                    polisa.jmbg,
                    polisa.adresa,
                    polisa.pttmug,
                    polisa.broj_zk,     
                    polisa.zampol,
                    polisa.brpol_ostali,
                    polisa.datdok,
                    polisa.datpoc,
                    polisa.datist,
                    polao2.godproizv,
                    polao2.regbroj,
                    polao2.brojsasije,
                    polao2.snagakw,
                    polao2.nosivostkg,
                    polao2.brojmesta,
                    polao2.zapreminaccm,
                    polao2.brojmotora,
                    polao3.targrupa, 
                    polao3.tarpodgrupa, 
                    polao3.uk_prem_ano,
                    polao3.izn_doplatka,
                    polao3.izn_popusta,
                    polao3.osnpremao,
                    bonus_malus.premijski_razred,
                    bonus_malus.bonus_malus,
                    bonus_malus.procenat procenat_bm,
                    popust.sifra_azors popust_azors,
                    doplatak.sifra_azors doplatak_azors,
                    tarifa.nbs, 
                    zastup.agencija_reg_broj,
                    ddor.sifra_azors ddor_azors,
                    opstina.sifra_azors opstina_azors,
                    m_ugov.mesto mesto_ugov,
                    null stdok_brojdok,
                    ( select nvl ( sum ( iznospremije ), 0 )
                        from kpsnalog
                       where kpsnalog.kpsnal_brojdok = polisa.pol_brpol and
                             kpsnalog.kpsnal_vsdok = polisa.vsdok and
                             kpsnalog.vros1 = 800 ) stdok_premija,    
                    polisa.datum_prestanka_vazenja,
                    polisa.bm_prenos_polisa
               from polisa, 
                    orgjed, 
                    tarifa, 
                    polao3, 
                    zastup, 
                    mesto m_izdavanja, 
                    mesto m_ugov, 
                    polao2, 
                    popdop popust, 
                    popdop doplatak, 
                    opstina, 
                    bonus_malus, 
                    tep.ddor
              where polisa.vsdok in ( 1, 4 ) and
                    polisa.datdok >= to_date ( '01.01.2010', 'dd.mm.rrrr' ) and
                    polisa.azors_slanje_id is null and
                    polisa.brosk is not null and
                    ( ( polisa.datdok between p_datum_od and p_datum_do and    
                        not exists ( select * 
                                       from rate
                                      where polisa.pol_brpol = rate.rat_brpol and
                                            polisa.vsdok = rate.vsdok and
                                            statusrate = 0 ) ) or 
                        exists ( select * 
                                   from kpsnalog
                                  where polisa.pol_brpol = kpsnalog.kpsnal_brojdok and
                                        polisa.vsdok = kpsnalog.kpsnal_vsdok and
                                        kpsnalog.vros1 = 800 and
                                        kpsnalog.kps = 1 and
                                        kpsnalog.azors_slanje_id is null and
                                        kpsnalog.datdok >= to_date ( '01.01.2010', 'dd.mm.rrrr' ) and
                                        kpsnalog.datdok between p_datum_od and p_datum_do ) ) and
                    polisa.oj = orgjed.oj_sifra and
                    polisa.tar = tarifa.tar_tar and
                    polisa.vros = tarifa.tar_vros and
                    polisa.pol_brpol = polao3.ao3_brpol and
                    polisa.vsdok = polao3.vsdok and
                    polisa.mbrzastup = zastup.zas_sifra and
                    polisa.pttm = m_izdavanja.mes_sifra and
                    m_izdavanja.opst = opstina.ops_sifra and
                    polisa.pttmug = m_ugov.mes_sifra(+) and
                    polisa.pol_brpol = polao2.ao2_brpol and
                    polisa.vsdok = polao2.vsdok and
                    polao3.sif_popusta = popust.pd_sifra(+) and
                    polao3.sif_doplatka = doplatak.pd_sifra(+) and
                    popust.pd_vros(+) = 800 and
                    doplatak.pd_vros(+) = 800 and
                    polao3.bonusmalus = bonus_malus.sifra(+) and
                    polisa.osig_ostali = ddor.sifra(+) 
  ) ) loop

      l_broj := trunc ( dbms_lob.getlength(cur_rec.result.getclobval()) / 32000 );
      utl_file.put_line ( izlaz, '<?xml version="1.0" encoding="utf-8"?>' );

        for i in 1..l_broj loop
          utl_file.put ( izlaz, substr ( xmltype.getClobval(cur_rec.result), 32000 * ( i - 1 ) + 1, 32000) );
          utl_file.fflush ( izlaz );
        end loop;  
        if l_broj > 0 then
          utl_file.put ( izlaz, substr ( xmltype.getClobval(cur_rec.result), 32000 * ( l_broj ) + 1 ) );
          utl_file.fflush ( izlaz );
        else
          utl_file.put ( izlaz, substr ( xmltype.getClobval(cur_rec.result), 1) );
        end if;  

    end loop;

    if p_broj_redova > 0 then
      update polisa set azors_slanje_id = l_UniqueID     
       where (pol_brpol,vsdok) in ( select to_char ( broj_polise ), vsdok 
                          from azors_slanje
                         where azors_slanje.unique_id = l_UniqueID );    
  
      update kpsnalog set azors_slanje_id = l_UniqueID 
       where kpsnalog.datdok between p_datum_od and p_datum_do and
             kpsnalog.kpsnal_vsdok in ( 1, 4 ) and
             kpsnalog.vros1 = 800 and
             azors_slanje_id is null and
             kpsnalog.kps = 1 and
             exists ( select * from azors_slanje  
                       where azors_slanje.broj_polise = kpsnalog.kpsnal_brojdok and
                             azors_slanje.vsdok = kpsnalog.kpsnal_vsdok and
                             azors_slanje.unique_id = l_UniqueID );
  
      update zelkarton set azors_slanje_id = l_UniqueID     
       where sifra in ( select broj_polise 
                          from azors_slanje
                         where azors_slanje.unique_id = l_UniqueID and
                               vsdok = 2 );    
    end if;
  end if;
  utl_file.put_line ( logfl, 'Uspešno završeno.');
  utl_file.fclose_all;
  return l_UniqueID;
exception when others then
  utl_file.put_line ( logfl, 'Greška: ' || sqlerrm );
  utl_file.fclose_all;
  rollback;
  return 'FALSE';
end azors_polise_zvjezdan;

/

