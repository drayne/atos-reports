create FUNCTION prva_prijava_stete (p_id number,p_zapisnik varchar2) RETURN date AS 
r_return date;
BEGIN
if trim(nvl(p_zapisnik,'')) <> '' then

  select min(p.datumprijave) into r_return 
  from knjigastao kao , prijstet p 
  where (p.id=kao.prijstet_id) and  kao.prijstet_id<=p_id and trim(kao.zapisnikmupa) 
  in (select trim(kao1.zapisnikmupa) from knjigastao kao1 where kao1.prijstet_id=p_id and kao1.zapisnikmupa is not null);
else
  select p.datumprijave into r_return 
  from prijstet p 
  where  p.id=p_id;
end if;
return r_return;
END prva_prijava_stete;

/

