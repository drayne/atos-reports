create PACKAGE BODY IZVESTAJI_QUERY  IS
  function spisak_dok_po_zastupniku (
                p_datumpromene_od date,
                p_datumpromene_do date,
                p_brojdok_od varchar2,
                p_brojdok_do varchar2,
                p_zastupnik number,
                p_vsdok number,
                p_status number )
    return spisak_dok_po_zastupniku_rf_c is
   query_temp spisak_dok_po_zastupniku_rf_c;
  begin
   open query_temp for
      SELECT stroga.str_brojdok,
             stroga.str_vsdok,
              vrstadok.naziv nazivdok,
              zastup.zas_sifra,
              zastup.naziv zastupnik,
              strgprom.svsp_sifra,
              strgprom.naziv status,
              stroga.str_datumpromene
 FROM VRSTADOK, ZASTUP, stroga, strgprom, ( select str_vsdok, str_brojdok
                                              from stroga
                                             where trunc ( str_datumpromene ) between p_datumpromene_od and p_datumpromene_do and
                                                   stroga.str_brojdok between p_brojdok_od and p_brojdok_do and
                                                   stroga.mbrzastupprima like nvl ( to_char ( p_zastupnik ), '%' ) and
                                                   stroga.str_vsdok like nvl ( to_char ( p_vsdok ), '%' ) and
                                                   stroga.svsprom like nvl ( to_char ( p_status ), '%' )
                                          group by str_vsdok, str_brojdok ) stroga_cur
WHERE stroga_cur.str_vsdok = stroga.str_vsdok and
      stroga_cur.str_brojdok = stroga.str_brojdok and
      stroga.svsprom = strgprom.svsp_sifra and
      stroga.str_vsdok = vrstadok.vsd_sifra and
      stroga.mbrzastupprima = zastup.zas_sifra
order by vrstadok.vsd_sifra;
   return query_temp;
  end;
END;
/

