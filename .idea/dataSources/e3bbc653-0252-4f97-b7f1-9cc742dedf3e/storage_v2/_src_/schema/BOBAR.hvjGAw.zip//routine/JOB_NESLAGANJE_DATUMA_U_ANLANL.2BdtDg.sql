create PROCEDURE JOB_NESLAGANJE_DATUMA_U_ANLANL AS 
broj number:=0;
BEGIN
    select count(*) into broj
    from anlanl 
    where datumobrade=trunc(sysdate)
    and to_char(datdok,'rrrr')<>to_char(datnal,'rrrr');
    if to_char(sysdate,'HH24MM') between '0800' and '1600' and trim(to_char(sysdate,'DAY')) not in ('SOBOTA','NEDELJA')then 
      if broj <> 0 then
        bobar.posalji_sms('066903255','Postoje neslaganja datuma u anlanl.Ukupno :'||to_char(broj));
        bobar.posalji_sms('065850120','Postoje neslaganja datuma u anlanl.Ukupno :'||to_char(broj));
      end if;
    end if;
END JOB_NESLAGANJE_DATUMA_U_ANLANL;

/

