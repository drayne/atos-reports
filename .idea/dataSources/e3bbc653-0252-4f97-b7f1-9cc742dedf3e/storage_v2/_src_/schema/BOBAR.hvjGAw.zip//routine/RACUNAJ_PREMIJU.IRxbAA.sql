create FUNCTION RACUNAJ_PREMIJU (p_pol_brpol in number,p_vros in number,p_datdok in date) RETURN number AS 
rez_saldo number:=0;
BEGIN
  select nvl(sum(a.dev_potrazuje-a.dev_duguje),0) into rez_saldo
  from anlanl a
  where a.anl_vsdok in (314,316,319) and a.konto in (
  select porez3 konto from semakont where vros=p_vros and datvazenja in (select max(datvazenja)from semakont where vros=p_vros)
  union all
  select porez4 konto from semakont where vros=p_vros and datvazenja in (select max(datvazenja)from semakont where vros=p_vros)
  union all
  select porez5 konto from semakont where vros=p_vros and datvazenja in (select max(datvazenja)from semakont where vros=p_vros)
  union all
  select konto_popust_tp konto from semakont where vros=p_vros and datvazenja in (select max(datvazenja)from semakont where vros=p_vros)
  union all
  select konto_popust_prev konto from semakont where vros=p_vros and datvazenja in (select max(datvazenja)from semakont where vros=p_vros)
  union all
  select konto_popust_rd konto from semakont where vros=p_vros and datvazenja in (select max(datvazenja)from semakont where vros=p_vros)
  
  
  union all
  select porez3 konto from semakont_im where vros=p_vros and datvazenja in (select max(datvazenja)from semakont_im where vros=p_vros)
  union all
  select porez4 konto from semakont_im where vros=p_vros and datvazenja in (select max(datvazenja)from semakont_im where vros=p_vros)
  union all
  select porez5 konto from semakont_im where vros=p_vros and datvazenja in (select max(datvazenja)from semakont_im where vros=p_vros)
  )
  and a.datdok<=p_datdok and pol_brpol=to_char(p_pol_brpol);
  return rez_saldo;
END RACUNAJ_PREMIJU;

/

