create FUNCTION yu852lat(yu852 varchar2) RETURN VARCHAR2 IS
yu_852 varchar2(250) := 'ABCDEFGHIJKLMNOPQRSTUVWXYZćŹ¬¦Ń abcdefghijklmnopqrstuvwxyz{~`}|_-"0123456789!#$%&*()+=<>,.';
la_s varchar2(250) :=   'ABCDEFGHIJKLMNOPQRSTUVWXYZŠĆČŽĐ abcdefghijklmnopqrstuvwxyzščžđ _-"0123456789!#$%&*()+=<>,.';
BEGIN 
 return translate(yu852,  yu_852, la_s);  
END;


/

