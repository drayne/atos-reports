create PROCEDURE       DAJ_RASPPREM (p_vros in number,
                        p_tarifa in number,
                        p_datum in date,
                        p_RASPREM in out RASPREM%ROWTYPE,
                        p_rezultat in out number ) IS

w_tarifa number;
w_procenat number;
w_datum date;
W_RASPREM RASPREM%ROWTYPE;
w_vros number;
kraj boolean;
nadjen boolean;

cursor	w_cur_tar is
        select
                     *
        from
                     rasprem
        where
                     rsp_vros = p_vros
                 and rsp_tar = w_tarifa
        order by
                     rasprem.rsp_datprimene desc;

BEGIN
        p_rezultat := 1;
	w_tarifa := p_tarifa;

        open w_cur_tar;
        fetch w_cur_tar into W_RASPREM;

        nadjen := false;
        kraj := w_cur_tar%notfound;

    while not kraj loop
       if w_rasprem.rsp_datprimene <= p_datum then
       	  P_RASPREM := W_RASPREM;
          nadjen 		 := true;
          kraj	 		 := true;
       else
          fetch w_cur_tar into W_RASPREM;
          kraj  := w_cur_tar%notfound;
       end if;
    end loop;

    close w_cur_tar;

    if nadjen then
       p_rezultat := 0;
    else
       w_tarifa := 0;
       p_rezultat := 1;

    	 open  w_cur_tar;
    	 fetch w_cur_tar into W_RASPREM;

         nadjen := false;
    	 kraj  := w_cur_tar%notfound;

       while not kraj loop
          if w_rasprem.rsp_datprimene <= p_datum then
             P_RASPREM := W_RASPREM;
             nadjen := true;
             kraj := true;
          else
            fetch w_cur_tar into W_RASPREM;
            kraj  := w_cur_tar%notfound;
       	 end if;
      end loop;

    	 close w_cur_tar;

    	 if nadjen then
       		p_rezultat := 0;
    	 end if;
   end if;

END;

/

