create package pk_zatvaranje as

  /*
    Zatvaranje stavki za zadati raspon komitenta ili zastupnika, zadati period i konto.
    parametri:
    p_vlasnik   - vlasnik
    p_radnja    - radnja
    p_kom_zast  - K = trazi po komitentima; Z = trazi po zastupnicima
    p_sifra_od  - interval komitenata/zastupnika
    p_sifra_do  - interval komitenata/zastupnika
    p_datum_od  - pocetni datum za datdok
    p_datum_do  - krajnji datum za datdok
    p_konto     - navode se konta (pod navodnicima) za koja se radi zatvaranje, npr '4211', '4212', '4213'
    p_vsdok_dug - vrste dokumenata za dugovnu stranu, npr 301, 302, 303
    p_vsdok_pot - vrste dokumenata za potraznu stranu, npr 301, 302, 303
    p_ponisti   - da li da se prvo poniste sva prethodna zatvaranja
  p_nivo_dokumenta('D','N') - da li se radi zatvaranje na nivou dokumenta ili nivou komitenta(zastupnika)

    Funkcija vraca poruku o tome da li je obrada uspesno zavrsena.
  */
  function f_zatvaranje(p_vlasnik in anlanl.anl_vlasnik%type,
                        p_radnja  in anlanl.anl_radnja%type,
                        p_kom_zast in varchar2,
                        p_sifra_od in number,
                        p_sifra_do in number,
                        p_datum_od in date,
                        p_datum_do in date,
                        p_konto in varchar2,
                        p_vsdok_dug in varchar2,
                        p_vsdok_pot in varchar2,
                        p_ponisti in varchar2,
                        p_nivo_dokumenta varchar2,
                        p_korisnik varchar2 ) return varchar2;

end pk_zatvaranje;

/

