create trigger UVECAJ_ID
  before insert
  on ZASTUP_GRUPE
  for each row
  declare
broj number:=0;
BEGIN
  	select nvl(max(id),0)+1 into :new.id 
		from zastup_grupe;
END;


/

