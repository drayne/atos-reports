create view KOMITENTI_POTRAZIVANJE as
  select anlanl.komitent, POLISA.DATPOC, polisa.datist, anlanl.pol_brpol, naziv_konta(anlanl.konto,anlanl.anl_radnja) naziv_potrazivanja, anlanl.konto, sum(dev_duguje-dev_potrazuje) iznos
from anlanl
join polisa on anlanl.pol_brpol = polisa.pol_brpol
where
anl_vlasnik=1 and anl_radnja=2
and konto is not null and komitent is not null  
and polisa.datpoc between (sysdate-800) and (sysdate-365)
and polisa.datist < sysdate
and anlanl.datdok between (sysdate-835) and (sysdate)
and anlanl.konto in (20110, 20120, 20130, 20140, 20170, 20190)
having sum(anlanl.dev_duguje - anlanl.dev_potrazuje)>0
group by anlanl.pol_brpol, anlanl.komitent, anlanl.konto, naziv_konta(anlanl.konto,anlanl.anl_radnja), polisa.datpoc, polisa.datist

/

