create trigger SNIMANJE_POLAO2
  before insert or update
  on POLAO2
  for each row
  begin
  if :new.vsdok=1 and :new.regbroj is null then
    posalji_sms('065638700','Operater '||:new.sifoperat||' je unijeo polisu '||:new.ao2_brpol||' bez registarkog broja!');
  end if;  
  -- Zbog AZORS-a
  update polisa set azors_slanje_id=null where pol_brpol=:new.ao2_brpol and vsdok = :new.vsdok;
end;


/

