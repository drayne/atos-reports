create PROCEDURE DAJ_PROSKALA (
                        p_datum    in     date,
                        p_tarifa   in     number,
                        p_brojdana in     number,
                        p_vros     in     number,
                        p_PROCENAT in out number,
                        p_rezultat in out number
                                             ) IS
w_PROCENAT NUMBER(17,2);

BEGIN
   p_rezultat := 99;
   p_procenat := 0;

   if p_datum is null then
      p_rezultat := 51;
/*
                                    prazan datum važenja cenovnika za probne tablice
*/
      p_procenat := 0;
   ELSE
      if P_brojdana = 0 then
         p_rezultat := 71;
         p_pROCENAT := 0;
/*
                                    broj dana ne može biti nula
*/
      ELSE
        
         if P_brojdana > 240 then
            p_rezultat := 0;
            P_procenat := 100;
         else
            SELECT       PROSKALA.PROCENAT
            INTO         W_PROCENAT
            FROM         PROSKALA
            where
                         PROSKALA.tarIFA = p_tarIFA
                     AND PROSKALA.VROS = P_VROS
                     AND P_BROJDANA BETWEEN PROSKALA.DANA_OD AND PROSKALA.DANA_DO
                     AND PROSKALA.datum  = (
                            select            
                                        max(PROSKALA.datum)
                            from                       
                                        PROSKALA
                            where             
                                        PROSKALA.tarIFA = p_tarIFA
                                    AND PROSKALA.VROS = P_VROS
                                    AND P_BROJDANA BETWEEN PROSKALA.DANA_OD AND PROSKALA.DANA_DO
                                    AND to_char(PROSKALA.datum,'yyyymmdd') <=
                                               to_char(p_datum,'yyyymmdd')
                                           );
            if nvl(w_procenat, 0) = 0 then
               p_rezultat := 61;
               p_PROCENAT := 0;
/*
                                      nije prona?en PROCENAT za proSKALA OBRA?UN
*/
            else
               p_PROCENAT := W_PROCENAT;
               P_REZULTAT := 0;
            end if;
         end if;
      end if;
   end if;
END;

/

