create PROCEDURE update_sta_datum_od_null IS

  cursor c_st is
       select * from statstet where prijstet_id in (select prijstet_id
                                                      from statstet
                                                     where sta_datum_od is null)
     order by prijstet_id,sta_rednibroj;

  red_st statstet%rowtype;
  old_id number := 0;

BEGIN
  for red_st in c_st loop
     if red_st.prijstet_id = old_id then
       UPDATE statstet set sta_datum_od = (select sta_datum
                                             from statstet
                                            where prijstet_id = red_st.prijstet_id and
                                                  sta_rednibroj = 1),
                                                  datumobrade = sysdate,
                                                  sta_rednibroj = 2
      where prijstet_id = red_st.prijstet_id and
            sta_rednibroj = red_st.sta_rednibroj;
    else

   UPDATE statstet set sta_datum_od = (select datumprijave from prijstet
      where id = red_st.prijstet_id), sta_rednibroj = 1, datumobrade = sysdate
      where prijstet_id = red_st.prijstet_id and
            sta_rednibroj = red_st.sta_rednibroj;
    end if;
     old_id := red_st.prijstet_id;
  END LOOP;
commit;
END;

/

