create FUNCTION MOBILNI (mtel in varchar2) RETURN VARCHAR2 AS
rezultat VARCHAR2(200):='FALSE';
mtel_pomocna VARCHAR2(200):='';
mtel_pomocna1 VARCHAR2(200):='';
BEGIN
if mtel is null or trim (mtel)='' then
  return rezultat;
end if;
mtel_pomocna1:=replace(trim(mtel),'+387',0);

for i in 1 .. length(trim(mtel_pomocna1)) loop
  if substr(trim(mtel_pomocna1),i,1) in ('0','1','2','3','4','5','6','7','8','9') then
    mtel_pomocna:=mtel_pomocna||substr(trim(mtel_pomocna1),i,1);
  end if;  
end loop;
if substr(mtel_pomocna, 0, 3) not in (061,063,065,066) then
  rezultat:='FALSE';
else
  if length(mtel_pomocna)=9 then
    rezultat:= mtel_pomocna;
  end if;
end if;
  RETURN rezultat;
END MOBILNI;

/

