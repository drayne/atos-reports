create function broj_zk (p_pol_brpol number) return varchar2 as 
broj number:=0;
begin
  select max(z.sifra) into broj from zelkarton z where polisa_broj=to_char(p_pol_brpol);
  return broj;
END BROJ_ZK;

/

