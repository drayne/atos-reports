create trigger UP_PRIJSTET_ISTORIJA
  after update of ID, PRST_VRSTA, PRST_GODINA, PRST_BRSTETE, OJ, MBRRADNIKA, DATUMPRIJAVE, STATUS_STETE, BRPOLISE, NAZIVPODNOSIOCA, BRLKPODNOSIOCA, DATUMNASTANKA, MESTONEZGODE, IZNOS_PRIJAVLJEN, IZNOS_REZERVISAN, DATUMOBRADE, SIFOPERAT, VROS, TARIFA
  on PRIJSTET
  for each row
  declare
  redni_broj number;
  regosi varchar2(2000);
  nazosi varchar2(2000);
  pttosi number;
  mesosi varchar2(2000);
  adrosi varchar2(2000);
  mosi varchar2(2000);
  sektosi varchar2(2000);
  nazvozosi varchar2(2000);
  pttvozosi number;
  mesvozosi varchar2(2000);
  adrvozosi varchar2(2000);
  marka varchar2(2000);
  tip varchar2(2000);
  pocosi date;
  istosi date;
  regostec varchar2(2000);
  nazostec varchar2(2000);
  pttostec number;
  mesostec varchar2(2000);
  adrostec varchar2(2000);
  mostec varchar2(2000);
  sektostec varchar2(2000);
  nazvozostec varchar2(2000);
  pttvozostec number;
  mesvozostec varchar2(2000);
  adrvozostec varchar2(2000);
  markaost varchar2(2000);
  tipost varchar2(2000);
  opis varchar2(2000);
  brmrtvih number;
  brpovredjenih number;
  zapisnik varchar2(2000);
  drzost varchar2(2000);
  vozdoz varchar2(2000);
  kateg varchar2(2000);
  mup varchar2(2000);
  proizvod date;
  sas varchar2(2000);
  mot varchar2(2000);
  post number;
  targr number;
  tarpod number;
  mat varchar2(2000);
  obj number;
begin
if :old.vros = 800 then
  select nvl ( max ( ist_rednibroj ), 0 ) + 1
      into redni_broj
      from istorija
     where prijstet_id = :old.id;

  select regbrosi, nazivosi, pttmosi, mestoosi, adresaosi, mbrosi,
         sektorosi, nazivvozosi, pttmvozosi, mestovozosi, adresavozosi,
         markaosi, tiposi, datpocosi, datistosi, regbrostec, nazivostec,
         pttmostec, mestoostec, adresaostec, mbrostec, sektorostec,
         nazivvozostec, pttmvozostec, mestovozostec, adresavozostec,
         markaostec, tipostec, mesto_opis, brojmrtvih, brojpovredjenih,
         zapisnikmupa,  drzavaost, vozdozvola, kategorija, izdaomup, godproizvod,
         sasija, motor, postupak, targrupa, tarpodgrupa, matst, objekat
    into regosi, nazosi, pttosi, mesosi, adrosi, mosi,
         sektosi, nazvozosi, pttvozosi, mesvozosi, adrvozosi,
         marka, tip, pocosi, istosi, regostec, nazostec,
         pttostec, mesostec, adrostec, mostec, sektostec,
         nazvozostec, pttvozostec, mesvozostec, adrvozostec,
         markaost, tipost, opis, brmrtvih, brpovredjenih,
         zapisnik,  drzost, vozdoz, kateg, mup, proizvod, sas, mot,
         post, targr, tarpod, mat, obj
    from knjigastao
   where prijstet_id = :old.id;

  insert into istorija
    ( prijstet_id, ist_vrsta, ist_brstete, ist_godina, ist_datum,
      ist_rednibroj, oj, mbrradnika, datumprijave, status_stete,
      brpolise, nazivpodnosioca, brlkpodnosioca,
      datumnastanka, mestonezgode, iznos_prijavljen, iznos_rezervisan,
      datumobrade, sifoperat, vros, tarifa, datummodif, modifikovao, regbrosi, nazivosi,
      pttmosi, mestoosi, adresaosi, mbrosi, sektorosi, nazivvozosi,
      pttmvozosi, mestovozosi, adresavozosi, markaosi, tiposi, datpocosi,
      datistosi, regbrostec, nazivostec, pttmostec, mestoostec, adresaostec,
      mbrostec, sektorostec, nazivvozostec, pttmvozostec,
      mestovozostec, adresavozostec, markaostec, tipostec, mesto_opis,
      brojmrtvih, brojpovredjenih, zapisnikmupa,  drzavaost, vozdozvola, kategorija, izdaomup, godproizvod,
         sasija, motor, postupak, targrupa, tarpodgrupa, matst, objekat
 )
  values
    ( :old.id, :old.prst_vrsta, :old.prst_brstete, :old.prst_godina, sysdate,
      redni_broj, :old.oj, :old.mbrradnika, :old.datumprijave, :old.status_stete,
      :old.brpolise, :old.nazivpodnosioca, :old.brlkpodnosioca,
      :old.datumnastanka, :old.mestonezgode, :old.iznos_prijavljen, :old.iznos_rezervisan,
      :old.datumobrade, :old.sifoperat, :old.vros, :old.tarifa, :new.datumobrade, :new.sifoperat,
      regosi, nazosi, pttosi, mesosi, adrosi, mosi, sektosi, nazvozosi,
      pttvozosi, mesvozosi, adrvozosi, marka, tip, pocosi,
      istosi, regostec, nazostec, pttostec, mesostec, adrostec,
      mostec, sektostec, nazvozostec, pttvozostec,
      mesvozostec, adrvozostec, markaost, tipost, opis,
      brmrtvih, brpovredjenih, zapisnik,  drzost, vozdoz, kateg, mup, proizvod, sas, mot,
         post, targr, tarpod, mat, obj
 );

/*
else

  select nazivosi, pttmosi, mestoosi, adresaosi, mbrosi,
         sektorosi, datpocosi, datistosi, mesto_opis, brojmrtvih, brojpovredjenih,
         zapisnikmupa
    into nazosi, pttosi, mesosi, adrosi, mosi,
         sektosi, pocosi, istosi, opis, brmrtvih, brpovredjenih,
         zapisnik
    from knjigastim
   where prijstet_id = :old.id;

  insert into istorija (
      prijstet_id, ist_vrsta, ist_brstete, ist_godina, ist_datum,
      ist_rednibroj, oj, mbrradnika, datumprijave, status_stete,
      brpolise, nazivpodnosioca, brlkpodnosioca,
      datumnastanka, mestonezgode, iznos_prijavljen, iznos_rezervisan,
      datumobrade, sifoperat, vros, tarifa, datummodif, modifikovao,
      nazivosi, pttmosi, mestoosi, adresaosi, mbrosi,
      sektorosi, datpocosi, datistosi, mesto_opis, brojmrtvih, brojpovredjenih,
      zapisnikmupa )
  values
    ( :old.id, :old.prst_vrsta, :old.prst_brstete, :old.prst_godina, sysdate,
      redni_broj, :old.oj, :old.mbrradnika, :old.datumprijave, :old.status_stete,
      :old.brpolise, :old.nazivpodnosioca, :old.brlkpodnosioca,
      :old.datumnastanka, :old.mestonezgode, :old.iznos_prijavljen, :old.iznos_rezervisan,
      :old.datumobrade, :old.sifoperat, :old.vros, :old.tarifa, :new.datumobrade, :new.sifoperat,
      nazosi, pttosi, mesosi, adrosi, mosi, sektosi, pocosi, istosi, opis,
      brmrtvih, brpovredjenih, zapisnik );
*/
end if;
end;


/

