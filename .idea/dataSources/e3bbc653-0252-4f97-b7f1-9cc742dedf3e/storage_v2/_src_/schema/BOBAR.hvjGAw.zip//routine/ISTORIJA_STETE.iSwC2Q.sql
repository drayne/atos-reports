create FUNCTION ISTORIJA_STETE (pid number,status_od number, status_do number) RETURN date AS 
BEGIN
  for red in (  select datum_statusa from (select prijstet_id id,status_stete,sta_datum_od datum_statusa from statstet where prijstet_id=pid 
  union all
  select id,status_stete,datum_statusa from prijstet where id=pid)
  where status_stete between status_od and status_do
  ) loop 
   -- return to_char(red.datum_statusa,'dd.mm.rrrr');
  return red.datum_statusa;
  end loop;
  return null;
END ISTORIJA_STETE;

/

