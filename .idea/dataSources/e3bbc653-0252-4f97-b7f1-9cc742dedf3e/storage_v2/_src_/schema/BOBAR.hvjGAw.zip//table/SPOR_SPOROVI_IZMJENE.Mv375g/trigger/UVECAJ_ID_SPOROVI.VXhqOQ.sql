create trigger UVECAJ_ID_SPOROVI
  before insert
  on SPOR_SPOROVI_IZMJENE
  for each row
  BEGIN
  SELECT NVL(MAX(ID),0)+1 INTO :NEW.ID
  FROM SPOR_SPOROVI_IZMJENE;
END;


/

