create PROCEDURE JOB_PROMJENA_DATIST_POLISA AS 
begin
   update bobar.polisa set datist=datum_prestanka_vazenja,datum_prestanka_vazenja=datist 
   where datist<>datum_prestanka_vazenja and datum_prestanka_vazenja is not null
   and datum_prestanka_vazenja>= datpoc and datum_prestanka_vazenja<datist;
END JOB_PROMJENA_DATIST_POLISA;

/

