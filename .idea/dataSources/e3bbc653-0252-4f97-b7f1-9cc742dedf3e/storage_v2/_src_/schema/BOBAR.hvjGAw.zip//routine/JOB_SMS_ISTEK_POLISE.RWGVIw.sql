create PROCEDURE job_SMS_istek_polise AS
	datum date;	
	broj_dana number:=-1;
	sms_template_text varchar(2000):='';
begin
	select nvl(to_number(vrijednost),-1) into broj_dana from bobar.parametri
	where lower(trim(naziv))='sms_istek_dana';
	--select trim(nvl(template,'')) into sms_template_text from tep.sms_template	where id=2 and aktivan=1;
	if broj_dana>=0 /*and length(sms_template_text)>0*/ then
		datum:=sysdate+broj_dana;
		/*for red in (select polisa.pol_brpol pol_brpol,polisa.datist datist, trim(polisa.nazivugov) nazivugov, trim(polisa.adresa) adresa, trim(mesto.mesto) mjesto, 
		trim(mobilni(polisa.telefon_mobilni)) as mobilni 
		from bobar.polisa, bobar.mesto 
		where polisa.pttmug= mesto.mes_sifra and bobar.mobilni(polisa.telefon_mobilni)<>'FALSE'
    and to_char(polisa.datist,'rrrrmmdd')=to_char(sysdate+broj_dana,'rrrrmmdd') 
    and not exists(select * from tep.sms_slanje where trim(napomena)=trim(polisa.pol_brpol))
    order by polisa.pol_brpol asc) loop
			insert into tep.sms_slanje (RECEIVER,MSG,VRSTA,DATUM_SLANJA,operater,napomena) 
			values (red.mobilni,
			replace(replace(replace(replace(replace(replace(sms_template_text,'#pol_brpol',red.pol_brpol),'#datist',to_char(red.datist,'dd.mm.rrrr'))
			,'#nazivugov',red.nazivugov),'#adresa',red.adresa),'#mjesto',red.mjesto),'#mobilni',red.mobilni),
			2,
			sysdate,
			'Oracle Scheduled Jobs',trim(red.pol_brpol));
			commit;
		end loop;*/
    -- AUTOODGOVORNOST
    insert into tep.sms_slanje (receiver,msg,vrsta,operater,napomena)
    (select p.telefon_mobilni,'Postovani, u svrhu dobre poslovne saradnje obavjestavamo Vas da registracija za Vase vozilo '||
    decode (p2.regbroj,'NEMA','marke '||p2.marka,'reg. oznake '||p2.regbroj)||' istice '||to_char(p.datist,'dd.mm.rrrr')
    ||', te Vas pozivamo da obnovite osiguranje od autoodgovornosti."Mislite na vrijeme"!.Atos osiguranje.' 
    ,2,'Istek polise',p.vsdok||'/'||p.pol_brpol from polisa p, polao2 p2
    where p.pol_brpol=p2.ao2_brpol and p.vsdok=p2.vsdok
    and p.vsdok=1 and to_char(p.datist,'dd.mm.rrrr')=to_char(datum,'dd.mm.rrrr')
    and p.telefon_mobilni is not null and p.datist>=sysdate
    and not exists (select * from tep.sms_slanje where trim(status)='transmitted' and trim(napomena)=p.vsdok||'/'||p.pol_brpol));
    -- KASKO
    insert into tep.sms_slanje (receiver,msg,vrsta,operater,napomena)
    (select k.mobil,'Postovani, u svrhu dobre poslovne saradnje obavjestavamo Vas da kasko polisa za Vase vozilo istice '
    ||to_char(p.datist,'dd.mm.rrrr')
    ||', te Vas pozivamo da obnovite osiguranje."Mislite na vrijeme"!.Atos osiguranje.' 
    ,2,'Istek polise',p.vsdok||'/'||p.pol_brpol from polisa p, polao2 p2, komitent k
    where p.pol_brpol=p2.ao2_brpol and p.vsdok=p2.vsdok and p.jmbg=k.kom_sifra
    and p.vsdok=5 and to_char(p.datist,'dd.mm.rrrr')=to_char(datum,'dd.mm.rrrr')
    and k.mobil is not null and p.datist>=sysdate
    and not exists (select * from tep.sms_slanje where trim(status)='transmitted' and trim(napomena)=p.vsdok||'/'||p.pol_brpol));
	end if;
  commit;
  exception
  when others then
  null;
end job_SMS_istek_polise;

/

