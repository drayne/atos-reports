create trigger TAR1ID_PREINS
  before insert
  on TARIFA1
  for each row
  BEGIN
SELECT TAR1SEQ.NEXTVAL INTO :NEW.ID
FROM DUAL;
END;



/

