create PACKAGE BODY       UPITI as
  function query_spisak_nerealizovanih ( p_datum_ulaz_od date, p_datum_ulaz_do date, p_datum_zaduzen_od date, p_datum_zaduzen_do date, 
                     p_datum_razduzenja date, p_zastupnik_od number, p_zastupnik_do number,
             p_vsdok_od number, p_vsdok_do number, p_filijala number )
    return spisak_nerealizovanih_ref_cur is
   query_temp spisak_nerealizovanih_ref_cur;
  begin
   open query_temp for 
   SELECT ALL STROGA.STR_VSDOK,
STROGA.STR_BROJDOK,
STROGA.STR_DATUMPROMENE,
nvl(STROGA.MBRZASTUPDAJE,''),
STROGA.MBRZASTUPPRIMA,
ZASTUP.NAZIV,
STROGA.SVSPROM,
decode ( stroga.svsprom, 1, 'ULAZ OD ŠTAMPARA', 11, 'PRIMIO OD', null ) naziv_promene,
STROGA.BROJREVERSA,
STROGA.OPISREVERSA,
vrstadok.naziv nazivdok, filijala.fil_sifra, filijala.naziv filijala
FROM ( SELECT * FROM STROGA 
        WHERE to_char(STROGA.STR_DATUMPROMENE,'yyyymmdd') between TO_CHAR( P_DATUM_ULAZ_OD,'yyyymmdd') AND 
              TO_CHAR( P_DATUM_ULAZ_DO,'yyyymmdd') AND
              stroga.str_vsdok BETWEEN P_VSDOK_OD AND P_VSDOK_DO AND
              svsprom = 1) ULAZ, ZASTUP,vrstadok, orgjed, filijala, stroga
WHERE
stroga.str_vsdok = ulaz.str_vsdok and 
stroga.str_brojdok = ulaz.str_brojdok and 
STROGA.MBRZASTUPPRIMA = ZASTUP.ZAS_SIFRA AND
STROGA.MBRZASTUPPRIMA BETWEEN  P_ZASTUPNIK_OD AND P_ZASTUPNIK_DO
 AND to_char(STROGA.STR_DATUMPROMENE,'yyyymmdd') between TO_CHAR( P_DATUM_ZADUZEN_OD,'yyyymmdd') 
       AND TO_CHAR( P_DATUM_ZADUZEN_DO,'yyyymmdd') AND
ulaz.str_vsdok = vrstadok.vsd_sifra
--AND STROGA.STR_VSDOK BETWEEN P_VSDOK_OD AND P_VSDOK_DO
and zastup.oj = orgjed.oj_sifra and orgjed.filijala like nvl(to_char(p_filijala), '%')
and filijala.fil_sifra = orgjed.filijala

and (stroga.svsprom = 11 or STROGA.SVSPROM=1)  
--and stroga.svsprom = 11  -- vb 9.10.17 umjesto ovoga gornji red  - interna revizija - jelena stanar
and not exists ( select * from stroga s
where s.str_vsdok = stroga.str_vsdok and
to_char(S.STR_DATUMPROMENE,'yyyymmdd') <= TO_CHAR( P_DATUM_RAZDUZENJA,'yyyymmdd') and
s.mbrzastupprima = stroga.mbrzastupprima and
s.id > stroga.id and
s.str_brojdok = stroga.str_brojdok and
s.svsprom in (3, 21,22,23,24))
ORDER BY str_vsdok, STR_BROJDOK;

   return query_temp;
   end;
/**************************************************************************************/
  function query_spisak_zaduzenih ( p_datumpromene_od date, p_datumpromene_do date, p_zastupnik_od number, p_zastupnik_do number,
             p_vsdok_od number, p_vsdok_do number, p_filijala number )
    return spisak_zaduzenih_ref_cur is
   query_temp spisak_zaduzenih_ref_cur;
  begin
   open query_temp for SELECT ALL STROGA.STR_VSDOK,
STROGA.STR_BROJDOK,
STROGA.STR_DATUMPROMENE,
STROGA.MBRZASTUPDAJE,
STROGA.MBRZASTUPPRIMA,
ZASTUP.NAZIV,
STROGA.SVSPROM,
decode ( stroga.svsprom, 1, 'ULAZ OD ŠTAMPARA', 11, 'PRIMIO OD', null ) naziv_promene,
STROGA.BROJREVERSA,
STROGA.OPISREVERSA,
vrstadok.naziv nazivdok, filijala.fil_sifra, filijala.naziv filijala
FROM STROGA, ZASTUP,vrstadok, orgjed, filijala, 
  (SELECT MAX (STROGA.ID ) ID FROM STROGA, ZASTUP,vrstadok, orgjed, filijala
WHERE
STROGA.MBRZASTUPPRIMA = ZASTUP.ZAS_SIFRA AND
STROGA.MBRZASTUPPRIMA BETWEEN  P_ZASTUPNIK_OD AND P_ZASTUPNIK_DO
 AND trunc ( STROGA.STR_DATUMPROMENE )
      between P_DATUMPROMENE_OD and P_DATUMPROMENE_DO
and stroga.str_vsdok = vrstadok.vsd_sifra
AND STR_VSDOK BETWEEN P_VSDOK_OD AND P_VSDOK_DO
and zastup.oj = orgjed.oj_sifra and orgjed.filijala like nvl(to_char(p_filijala), '%')
and filijala.fil_sifra = orgjed.filijala
and svsprom in ( 1, 11) 
GROUP BY MBRZASTUPPRIMA, STR_VSDOK, STR_BROJDOK) A
WHERE STROGA.ID = A.ID AND STROGA.MBRZASTUPPRIMA = ZASTUP.ZAS_SIFRA 
and stroga.str_vsdok = vrstadok.vsd_sifra
and zastup.oj = orgjed.oj_sifra
and filijala.fil_sifra = orgjed.filijala
ORDER BY str_vsdok, STR_BROJDOK;

   return query_temp;
   end;
/**************************************************************************************/
  function query_spisak_razduzenih ( p_datumpromene_od date, p_datumpromene_do date, p_zastupnik_od number, p_zastupnik_do number,
             p_vsdok_od number, p_vsdok_do number, p_filijala number )
    return spisak_razduzenih_ref_cur is
   query_temp spisak_razduzenih_ref_cur;
  begin
   open query_temp for SELECT ALL STROGA.STR_VSDOK,
STROGA.STR_BROJDOK,
STROGA.STR_DATUMPROMENE,
STROGA.MBRZASTUPDAJE,
STROGA.MBRZASTUPPRIMA,
ZASTUP.NAZIV,
STROGA.SVSPROM,
decode ( stroga.svsprom, 1, 'ULAZ OD ŠTAMPARA', 11, 'PRIMIO OD', null ) naziv_promene,
STROGA.BROJREVERSA,
STROGA.OPISREVERSA,
vrstadok.naziv nazivdok, filijala.fil_sifra, filijala.naziv filijala
FROM STROGA, ZASTUP,vrstadok, orgjed, filijala
WHERE
STROGA.MBRZASTUPPRIMA = ZASTUP.ZAS_SIFRA AND
STROGA.MBRZASTUPPRIMA BETWEEN  P_ZASTUPNIK_OD AND P_ZASTUPNIK_DO
 AND trunc ( STROGA.STR_DATUMPROMENE )
    between P_DATUMPROMENE_OD AND P_DATUMPROMENE_DO
and stroga.str_vsdok = vrstadok.vsd_sifra
AND STR_VSDOK BETWEEN P_VSDOK_OD AND P_VSDOK_DO
and zastup.oj = orgjed.oj_sifra and orgjed.filijala like nvl(to_char(p_filijala), '%')
and filijala.fil_sifra = orgjed.filijala
and svsprom in ( 3, 21, 23, 22, 24 )
ORDER BY str_vsdok, STR_BROJDOK;

   return query_temp;
   end;
/*******************************************************************************************************/
function query_spisak_polisa
                 ( p_from varchar2, p_where varchar2 ) return spisak_polisa_ref_cur is
  query_temp spisak_polisa_ref_cur;
  l_query varchar2(50) := 'ddd';
begin
	null;
  return query_temp;
end;

/********************************************************************************************************/
function ukupna_premija_period_vros(datum_od POLISA.DATDOK%type, datum_do POLISA.DATDOK%type, p_vros POLISA.VROS%type default null) return POLISA.PREMIJA%type is
p_premija number;
begin
    if(p_vros is null)
    then
        select sum(premija)
        into p_premija
        from polisa p
        where P.DATDOK between datum_od and datum_do;
    else
        select sum(premija)
        into p_premija
        from polisa p
        where P.DATDOK between datum_od and datum_do
        and P.VROS = p_vros;
     end if;
    
    
    return p_premija;
end;

  /************************************************************************
   anl_za_konto_dug
   Created: 21.06.2016 8:32:01 AM by Administrator
   Purpose:
  ************************************************************************/
  FUNCTION anl_za_konto_dug(DATUM_OD IN ANLANL.DATDOK%TYPE, DATUM_DO IN ANLANL.DATDOK%TYPE, KONTO IN ANLANL.KONTO%TYPE, POLISA IN ANLANL.POL_BRPOL%type, vsdok ANLANL.ANL_VSDOK%type) RETURN ANLANL.DEV_DUGUJE%type IS
    r_dugovna number;
  BEGIN
    select sum(a.dev_duguje)
    into r_dugovna
    from anlanl a
    where A.DATDOK between datum_od and datum_do
    and polisa = A.POL_BRPOL
    and konto = A.KONTO
    and vsdok=a.anl_vsdok;
    RETURN r_dugovna;
  END anl_za_konto_dug;

  /************************************************************************
   anl_za_konto_pot
   Created: 21.06.2016 8:33:08 AM by Administrator
   Purpose:
  ***********************************************************************
  CTRL SHIFT C na spec  funkcije
  */
  FUNCTION anl_za_konto_pot(DATUM_OD IN ANLANL.DATDOK%TYPE, DATUM_DO IN ANLANL.DATDOK%TYPE, KONTO IN ANLANL.KONTO%TYPE, POLISA IN ANLANL.POL_BRPOL%type, vsdok ANLANL.ANL_VSDOK%type) RETURN ANLANL.DEV_POTRAZUJE%type IS
    r_potrazna number;
  BEGIN
    select sum(a.dev_duguje)
    into r_potrazna
    from anlanl a
    where A.DATDOK between datum_od and datum_do
    and polisa = A.POL_BRPOL
    and konto = A.KONTO
    and vsdok=a.anl_vsdok;    
    RETURN r_potrazna;
  END anl_za_konto_pot;
 
--
function vrati_opstinu(ptt MESTO.MES_SIFRA%type) return OPSTINA.NAZIV%type is
r_naziv_opstine varchar2(50);
    BEGIN 
        select o.naziv
        into r_naziv_opstine
        from opstina o, mesto m
        where O.OPS_SIFRA= M.OPST
        and M.MES_SIFRA = ptt;
        return r_naziv_opstine;
      END;   
end;
/

