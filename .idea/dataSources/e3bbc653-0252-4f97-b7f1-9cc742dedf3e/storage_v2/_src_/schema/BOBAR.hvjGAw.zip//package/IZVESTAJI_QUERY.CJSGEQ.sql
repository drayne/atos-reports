create PACKAGE IZVESTAJI_QUERY  as
  type spisak_dok_po_zastupniku_rec is record (
   brdok varchar2(11),
   vsdok number(5),
   nazivdok varchar2(100),
   zas_sifra number(13),
   zastupnik varchar2(50),
   sifra_statusa number,
   status varchar2(50),
   datum_statusa date );
  type spisak_dok_po_zastupniku_rf_c is ref cursor return spisak_dok_po_zastupniku_rec;
  function spisak_dok_po_zastupniku (
              p_datumpromene_od date,
              p_datumpromene_do date,
              p_brojdok_od varchar2,
              p_brojdok_do varchar2,
              p_zastupnik number,
              p_vsdok number,
              p_status number ) return spisak_dok_po_zastupniku_rf_c;
end;


/

