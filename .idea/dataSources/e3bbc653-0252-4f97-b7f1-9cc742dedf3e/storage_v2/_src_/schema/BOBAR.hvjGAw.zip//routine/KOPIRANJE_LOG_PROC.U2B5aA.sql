create PROCEDURE         "KOPIRANJE_LOG_PROC" (poperater varchar,pip varchar,phost varchar,psa varchar,pna varchar) AS 
BEGIN
  insert into kopiranje_log (operater,ip,host,sa,na)
						values 
						(poperater,pip,phost,psa,pna);
            commit;
END KOPIRANJE_LOG_PROC;

/

