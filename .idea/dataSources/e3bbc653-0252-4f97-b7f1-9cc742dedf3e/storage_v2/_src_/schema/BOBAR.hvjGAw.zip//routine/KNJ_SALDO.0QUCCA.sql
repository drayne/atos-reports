create FUNCTION KNJ_SALDO (brpol in number) RETURN number AS 

saldo number(13,2):=0;
BEGIN
  for red in (
  select nvl(sum(dev_duguje),0) as saldo from anlanl where pol_brpol=to_char(brpol)
  and anl_vsdok in (316,304,319)
  and konto in 
  (
  select distinct(osigdug) konto from (
  select distinct(osigdug) osigdug from semakont_im
  union all
  select distinct(osigdug) osigdug from semakont
  union all
  select distinct(prihodpot) osigdug from semakont_im
  union all
  select distinct(prihodpot) osigdug from semakont
  ) where osigdug is not null
  )
) loop
  saldo:=red.saldo;
  end loop;
return saldo;
END KNJ_SALDO;

/

