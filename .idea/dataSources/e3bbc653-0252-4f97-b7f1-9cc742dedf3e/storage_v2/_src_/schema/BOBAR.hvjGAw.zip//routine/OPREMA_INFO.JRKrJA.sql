create FUNCTION         "OPREMA_INFO" (broj number) RETURN VARCHAR2 AS
naziv varchar (2000):='';
BEGIN
  for red in (select s.naziv||'- '|| 'Šifra: '||o.id||' Inv. br.: '||o.inventarski_broj as naziv 
              from inv_oprema o, inv_vrsta_sifrarnika vs, inv_sifrarnik s
              where lower(vs.naziv)='vrsta_opreme' and vs.id= s.id_vrsta and s.id=o.vrsta and o.id=broj) loop
      naziv:=red.naziv;
  end loop;
  return naziv;
END OPREMA_INFO;

/

