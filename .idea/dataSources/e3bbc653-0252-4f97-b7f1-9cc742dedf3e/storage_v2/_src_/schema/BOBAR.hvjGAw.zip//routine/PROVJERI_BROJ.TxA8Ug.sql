create FUNCTION PROVJERI_BROJ ( p_value varchar2 ) return varchar2 is
    x number;
  begin
  
  if p_value is null then
    return 'FALSE';
  end if;
  
    x := to_number ( p_value );
    return 'TRUE';
  exception when others then
    return 'FALSE';
end PROVJERI_BROJ;

/

