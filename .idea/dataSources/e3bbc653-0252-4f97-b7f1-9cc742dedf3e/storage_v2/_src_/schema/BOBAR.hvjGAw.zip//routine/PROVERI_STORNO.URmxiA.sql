create FUNCTION PROVERI_STORNO ( p_broj_dok number, p_vsdok number ) RETURN varchar2 AS
  l_postoji number;
BEGIN
  select count(*)
    into l_postoji
    from stroga str
   where str_vsdok = p_vsdok and 
         str_brojdok = p_broj_dok and 
         exists ( select * from stroga where str_vsdok = p_vsdok and str_brojdok = p_broj_dok and svsprom in ( 22, 24 ));
  if l_postoji > 0 then
    RETURN 'TRUE';
  else
    RETURN 'FALSE';
  end if;
END PROVERI_STORNO;

/

