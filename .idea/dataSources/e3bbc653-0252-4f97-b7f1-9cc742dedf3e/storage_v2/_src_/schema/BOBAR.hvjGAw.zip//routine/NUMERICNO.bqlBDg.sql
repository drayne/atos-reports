create FUNCTION NUMERICNO
(p_num in varchar2)
return number is
x number;
begin
x :=to_number(p_num);
return 1;
exception when others then
return 0;
end;


/

