create FUNCTION zameni_konto ( p_stmt varchar2 ) RETURN number IS
broj_redova number;
BEGIN
 execute immediate p_stmt;
 broj_redova := sql%rowcount;
  if broj_redova >= 1 then
     commit;
  return 1;
  else
     return 0;
  end if;

 exception
when others then
return 2;
END;


/

