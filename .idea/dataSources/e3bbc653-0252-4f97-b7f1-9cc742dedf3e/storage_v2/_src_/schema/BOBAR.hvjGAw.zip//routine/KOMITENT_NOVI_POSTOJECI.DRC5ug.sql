create FUNCTION       "KOMITENT_NOVI_POSTOJECI" (p_jmbg in number default 0, p_nazivugov in varchar2, p_pttmug in number, p_adresa in varchar2, p_oj in number) RETURN number 
as r_sifra_komitenta number;

BEGIN

  select K.KOM_SIFRA
  into r_sifra_komitenta 
  from komitent k
  where k.matbr = p_jmbg; 
  return r_sifra_komitenta;
  
exception
        when NO_DATA_FOUND    then 
            select komitent_seq.nextval into r_sifra_komitenta from dual;
            --insert into komitent (kom_sifra, naziv, pttm, adresa, sifoperat, matbr, org) values(r_sifra_komitenta, p_nazivugov, p_pttmug, p_adresa, 'vedran' , p_jmbg, p_oj);
            BOBAR.DODAJ_KOMITENTA(p_jmbg, p_nazivugov,  r_sifra_komitenta, p_pttmug, p_adresa, p_oj); 
            return r_sifra_komitenta;     
  
END;

/

