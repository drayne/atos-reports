create view KOM_ST_TEMP_VIEW_1228142158 as
  select komitent, anl_nalog, anl_vsdok, datnal, datdok, datval, brdok, pol_brpol, opis, zatvoren, dev_duguje duguje, dev_potrazuje potrazuje from anlanl where komitent between 827 and 827 and anl_vlasnik between 1 and 1 and anl_radnja between 2 and 2 and trunc(datnal) between to_date('01.01.11') and to_date('31.12.11') and konto between '20100' and '20191'

/

