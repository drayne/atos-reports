create view KOM_TEMP_VIEW_0314121135 as
  select k.kom_sifra, k.naziv, m.mes_sifra||' '|| m.mesto as mesto, k.adresa, k.delat delatnost, to_char(m.mes_sifra)||' '||m.mesto as adresa1, 0 donos_dug, 0 donos_pot from komitent k, mesto m, vrstasvoj v where k.kom_sifra between 2 and 999999999 and k.pttm = m.mes_sifra and k.vrstasvojine = v.vrs_sifra(+) and v.sektor_sif = 2 and k.kom_sifra in ( select komitent from anlanl where komitent between 2 and 999999999 and anl_vlasnik between 1 and 1 and anl_radnja between 2 and 2 and trunc(datnal) between to_date('01.01.11') and to_date('31.12.11') and konto between '20100' and '20191')

/

