create package body pk_zatvaranje as

  function f_zatvaranje(p_vlasnik in anlanl.anl_vlasnik%type,
                        p_radnja  in anlanl.anl_radnja%type,
                        p_kom_zast in varchar2,
                        p_sifra_od in number,
                        p_sifra_do in number,
                        p_datum_od in date,
                        p_datum_do in date,
                        p_konto in varchar2,
                        p_vsdok_dug in varchar2,
                        p_vsdok_pot in varchar2,
                        p_ponisti in varchar2,
                        p_nivo_dokumenta varchar2,
                        p_korisnik varchar2 ) return varchar2 is

    l_del_sql varchar2(2000);
    type cur_type is ref cursor;
    c_dug cur_type;
    c_pot cur_type;
    type rec_dug_type is record(r rowid,
                                dug number,
                                zatv number,
                                ozna_zatvor number,
                                kom_zast number(13),
                                dok_pol varchar2(20),
                                id number,
                                anl_nalog number,
                                anl_vsdok number,
                                anl_stavka number,
                                konto number,
                                reznum_1 number,
                                rj number,
                                jmbg number );
    r_dug rec_dug_type;
    type rec_pot_type is record(r rowid,
                                pot number,
                                zatv number,
                                ozna_zatvor number,
                                id number,
                                anl_nalog number,
                                anl_vsdok number,
                                anl_stavka number,
                                konto number);
    r_pot rec_pot_type;
    l_dug_sql varchar2(2000);
    l_pot_sql varchar2(2000);
    l_kom_zast_sql varchar2(2000);
    l_kom_zast varchar2(20);
    l_dok_pol varchar2(20);

    l_cnt_dug number := 0;
    l_cnt_pot number := 0;

  begin

    if p_kom_zast = 'K' then
      l_kom_zast := 'komitent';
--      l_dok_pol := 'brdok';
      l_dok_pol := 'pol_brpol';
      l_kom_zast_sql := 'komitent between ' || p_sifra_od || ' and ' || p_sifra_do;
    else
      l_kom_zast := 'jmbg';
      l_dok_pol := 'pol_brpol';
      l_kom_zast_sql := 'jmbg between ' || p_sifra_od || ' and ' || p_sifra_do;
    end if;

    if p_ponisti = 'D' then
      l_del_sql :=              'update anlanl ';
      l_del_sql := l_del_sql || '   set zatvoren = null, ';
      l_del_sql := l_del_sql || '       ozna_zatvor = null ';
      l_del_sql := l_del_sql || ' where anl_vlasnik = ' || p_vlasnik;
      l_del_sql := l_del_sql || '   and anl_radnja  = ' || p_radnja;
      l_del_sql := l_del_sql || '   and anl_vsdok in (' || p_vsdok_dug || ', ' || p_vsdok_pot || ')';
      l_del_sql := l_del_sql || '   and ' || l_kom_zast_sql;
      l_del_sql := l_del_sql || '   and datdok between ''' || p_datum_od || ''' and ''' || p_datum_do || '''';
      if p_konto is not null then
        l_del_sql := l_del_sql || '   and konto in (' || p_konto || ')';
      end if;
      execute immediate l_del_sql;
    end if;
/*
    dbms_output.put_line('select rowid, dev_duguje, nvl(zatvoren, 0), ozna_zatvor, ' || l_kom_zast || ', ' || l_dok_pol);
    dbms_output.put_line('  from anlanl ');
    dbms_output.put_line(' where anl_vlasnik = ' || p_vlasnik);
    dbms_output.put_line('   and anl_radnja  = ' || p_radnja);
    dbms_output.put_line('   and anl_vsdok in (' || p_vsdok_dug || ')');
    dbms_output.put_line('   and ' || l_kom_zast_sql);
    dbms_output.put_line('   and datdok between ''' || p_datum_od || ''' and ''' || p_datum_do || '''');
    dbms_output.put_line('   and konto in (' || p_konto || ')');
    dbms_output.put_line('   and (ozna_zatvor is null or ozna_zatvor = 2)');
    dbms_output.put_line('   and (zatvoren is null or zatvoren < dev_duguje)');
    dbms_output.put_line('   and dev_duguje > 0');
    dbms_output.put_line(' order by datdok');
*/
    l_dug_sql :=              'select rowid, dev_duguje, nvl(zatvoren, 0), ozna_zatvor, komitent, pol_brpol' ||
                              ', id, anl_nalog, anl_vsdok, anl_stavka, konto, reznum_1, rj, jmbg ';
    l_dug_sql := l_dug_sql || '  from anlanl ';
    l_dug_sql := l_dug_sql || ' where anl_vlasnik = ' || p_vlasnik;
    l_dug_sql := l_dug_sql || '   and anl_radnja  = ' || p_radnja;
    l_dug_sql := l_dug_sql || '   and anl_vsdok in (' || p_vsdok_dug || ')';
    l_dug_sql := l_dug_sql || '   and ' || l_kom_zast_sql;
    l_dug_sql := l_dug_sql || '   and to_char ( datdok, ''rrrrmmdd'' ) between ''' || to_char ( p_datum_od, 'rrrrmmdd' ) || ''' and ''' || to_char ( p_datum_do, 'rrrrmmdd' ) || '''';
    if p_konto is not null then
      l_dug_sql := l_dug_sql || '   and konto in (' || p_konto || ')';
    end if;
    if nvl ( p_nivo_dokumenta, 'N' ) = 'D' then
      l_dug_sql := l_dug_sql || '   and pol_brpol is not null ';
    end if;
    l_dug_sql := l_dug_sql || '   and (ozna_zatvor is null or ozna_zatvor = 2)';
    l_dug_sql := l_dug_sql || '   and (zatvoren is null or zatvoren < nvl ( dev_duguje, 0 ))';
    l_dug_sql := l_dug_sql || '   and nvl ( dev_duguje, 0 ) > 0';
    l_dug_sql := l_dug_sql || '   and reznum_1 is not null';
    l_dug_sql := l_dug_sql || ' order by datdok';
    open c_dug for l_dug_sql;
    loop
      fetch c_dug into r_dug;
      exit when c_dug%notfound;
--      dbms_output.put_line('r_dug.dug = ' || r_dug.dug || ', r_dug.zatv = ' || r_dug.zatv);
      l_pot_sql :=              'select rowid, dev_potrazuje, nvl(zatvoren, 0), ozna_zatvor' ||
                                ', id, anl_nalog, anl_vsdok, anl_stavka, konto';
      l_pot_sql := l_pot_sql || '  from anlanl ';
      l_pot_sql := l_pot_sql || ' where anl_vlasnik = ' || p_vlasnik;
      l_pot_sql := l_pot_sql || '   and anl_radnja  = ' || p_radnja;
      l_pot_sql := l_pot_sql || '   and anl_vsdok in (' || p_vsdok_pot || ')';
      l_pot_sql := l_pot_sql || '   and komitent = ' || r_dug.kom_zast;
--- Ako se zatvaranje vrši na nivou dokumenta
			if nvl ( p_nivo_dokumenta, 'N' ) = 'D' then
	      l_pot_sql := l_pot_sql || '   and pol_brpol = ' || r_dug.dok_pol;
			end if;
---------------------------------------------
      l_pot_sql := l_pot_sql || '   and to_char ( datdok, ''rrrrmmdd'' ) between ''' || to_char ( p_datum_od, 'rrrrmmdd' ) || ''' and ''' || to_char ( p_datum_do, 'rrrrmmdd' ) || '''';
--      if p_konto is not null then
--        l_pot_sql := l_pot_sql || '   and konto in (' || p_konto || ')';
--      end if;
      l_pot_sql := l_pot_sql || '   and konto = :1';-- || r_dug.konto;

      l_pot_sql := l_pot_sql || '   and (ozna_zatvor is null or ozna_zatvor = 2)';
      l_pot_sql := l_pot_sql || '   and (zatvoren is null or zatvoren < nvl ( dev_potrazuje, 0 ))';
      l_pot_sql := l_pot_sql || '   and nvl ( dev_potrazuje, 0 ) > 0';
      l_pot_sql := l_pot_sql || '   and reznum_1 = :2';-- || r_dug.reznum_1;
      l_pot_sql := l_pot_sql || ' order by datdok';

      if nvl ( p_nivo_dokumenta, 'N' ) = 'D' then
			--- Ako se zatvaranje vrši na nivou dokumenta
	      open c_pot for l_pot_sql using r_dug.konto, r_dug.reznum_1;
  		else
	      open c_pot for l_pot_sql;
  		end if;

      loop
        fetch c_pot into r_pot;
        exit when c_pot%notfound;
--        dbms_output.put_line('r_pot.pot = ' || r_pot.pot || ', r_pot.zatv = ' || r_pot.zatv);
        if nvl ( r_dug.dug, 0 ) - nvl ( r_dug.zatv, 0 ) > nvl ( r_pot.pot, 0 ) - nvl (r_pot.zatv, 0 ) then
          /* zatvaranje potrazne stavke */
          r_dug.zatv := nvl ( r_dug.zatv, 0 ) + nvl ( r_pot.pot, 0  ) - nvl ( r_pot.zatv, 0 );
          update anlanl
             set zatvoren = r_dug.zatv,
                 ozna_zatvor = 2 -- delimicno zatvoren
           where rowid = r_dug.r;
          update anlanl
             set zatvoren = dev_potrazuje,
                 ozna_zatvor = 1 -- skroz zatvoren
           where rowid = r_pot.r;
          l_cnt_pot := l_cnt_pot + 1;
          insert into anlanl_zatvaranje  ( id, 
                                           anl_vlasnik, 
                                           anl_radnja, 
                                           anl_vsdok, 
                                           anl_nalog, 
                                           anl_stavka,
                                           z_id, 
                                           z_anl_vlasnik,
                                           z_anl_radnja,
                                           z_anl_vsdok, 
                                           z_anl_nalog, 
                                           z_anl_stavka, 
                                           iznos, 
                                           datum_kreiranja, 
                                           kreirao )
                                  values ( r_pot.id,
                                           p_vlasnik,
                                           p_radnja,
                                           r_pot.anl_vsdok,
                                           r_pot.anl_nalog,
                                           r_pot.anl_stavka,
                                           r_dug.id,
                                           p_vlasnik,
                                           p_radnja,
                                           r_dug.anl_vsdok,
                                           r_dug.anl_nalog,
                                           r_dug.anl_stavka,
                                           nvl ( r_pot.pot, 0 ) - nvl ( r_pot.zatv, 0 ),
                                           sysdate,
                                           p_korisnik );
        elsif nvl ( r_dug.dug, 0 ) - nvl ( r_dug.zatv, 0 ) < nvl ( r_pot.pot, 0 ) - nvl ( r_pot.zatv, 0 ) then
          /* zatvaranje dugovne stavke */
          r_pot.zatv := nvl ( r_pot.zatv, 0 ) + nvl ( r_dug.dug, 0 ) - nvl ( r_dug.zatv, 0 );
          update anlanl
             set zatvoren = dev_duguje,
                 ozna_zatvor = 1 -- skroz zatvoren
           where rowid = r_dug.r;
          update anlanl
             set zatvoren = r_pot.zatv,
                 ozna_zatvor = 2 -- delimicno zatvoren
           where rowid = r_pot.r;
          l_cnt_dug := l_cnt_dug + 1;
          insert into anlanl_zatvaranje  ( id, 
                                           anl_vlasnik, 
                                           anl_radnja, 
                                           anl_vsdok, 
                                           anl_nalog, 
                                           anl_stavka,
                                           z_id, 
                                           z_anl_vlasnik,
                                           z_anl_radnja,
                                           z_anl_vsdok, 
                                           z_anl_nalog, 
                                           z_anl_stavka, 
                                           iznos, 
                                           datum_kreiranja, 
                                           kreirao )
                                  values ( r_pot.id,
                                           p_vlasnik,
                                           p_radnja,
                                           r_pot.anl_vsdok,
                                           r_pot.anl_nalog,
                                           r_pot.anl_stavka,
                                           r_dug.id,
                                           p_vlasnik,
                                           p_radnja,
                                           r_dug.anl_vsdok,
                                           r_dug.anl_nalog,
                                           r_dug.anl_stavka,
                                           nvl ( r_dug.dug, 0 ) - nvl ( r_dug.zatv, 0 ),
                                           sysdate,
                                           p_korisnik );
          exit;
        else
          /* zatvaranje i dugovne i potrazne stavke */
          update anlanl
             set zatvoren = dev_duguje,
                 ozna_zatvor = 1 -- skroz zatvoren
           where rowid = r_dug.r;
          update anlanl
             set zatvoren = dev_potrazuje,
                 ozna_zatvor = 1 -- skroz zatvoren
           where rowid = r_pot.r;
          l_cnt_pot := l_cnt_pot + 1;
          l_cnt_dug := l_cnt_dug + 1;
          insert into anlanl_zatvaranje  ( id, 
                                           anl_vlasnik, 
                                           anl_radnja, 
                                           anl_vsdok, 
                                           anl_nalog, 
                                           anl_stavka,
                                           z_id, 
                                           z_anl_vlasnik,
                                           z_anl_radnja,
                                           z_anl_vsdok, 
                                           z_anl_nalog, 
                                           z_anl_stavka, 
                                           iznos, 
                                           datum_kreiranja, 
                                           kreirao )
                                  values ( r_pot.id,
                                           p_vlasnik,
                                           p_radnja,
                                           r_pot.anl_vsdok,
                                           r_pot.anl_nalog,
                                           r_pot.anl_stavka,
                                           r_dug.id,
                                           p_vlasnik,
                                           p_radnja,
                                           r_dug.anl_vsdok,
                                           r_dug.anl_nalog,
                                           r_dug.anl_stavka,
                                           nvl ( r_pot.pot, 0 ) - nvl ( r_pot.zatv, 0 ),
                                           sysdate,
                                           p_korisnik );
          exit;
        end if;
      end loop;
      close c_pot;
    end loop;
    close c_dug;
    commit;
    return 'Zatvoreno je ' || l_cnt_dug || ' dugovnih i ' || l_cnt_pot || ' potražnih stavki';
  exception
    when others then
      rollback;
      return 'Došlo je do greške prilikom obrade: ' || sqlerrm || chr (10) || 'Proverite da li ste dobro zadali parametre.';
  end f_zatvaranje;

end pk_zatvaranje;
/

