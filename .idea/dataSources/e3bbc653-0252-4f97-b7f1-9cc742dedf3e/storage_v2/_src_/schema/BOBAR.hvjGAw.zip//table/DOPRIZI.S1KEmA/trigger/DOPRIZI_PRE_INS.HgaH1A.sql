create trigger DOPRIZI_PRE_INS
  before insert
  on DOPRIZI
  for each row
  begin
select doprizi_id_seq.nextval into :new.id from dual;
end;



/

