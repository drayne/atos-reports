create FUNCTION PROVJERA_MATBR (p_matbr varchar )RETURN boolean AS

vrati boolean:=false;
dan     varchar(2);
mjesec  varchar(2);
godina  varchar(3);
maticni_broj varchar(13);
zbir		number;
BEGIN
for redn in (select * from komitent_pogresni where trim(matbr)= trim(p_matbr)) loop
    return true;
end loop;

for red in (select * from parametri where lower(naziv)='komitent_dozvoljen_unos') loop
if p_matbr = red.vrijednost then
  return true;
end if;
end loop;



if length(p_matbr)<>13 or substr(p_matbr,0,1)>'4' THEN
  return false;
end if;

maticni_broj:=trim(to_char(p_matbr));

dan:=substr(maticni_broj,0,2);
mjesec:=substr(maticni_broj,3,2);
godina:=substr(maticni_broj,5,3);

if substr(maticni_broj,0,1)<'4' then
  if mjesec in ('01', '03', '05', '07', '08', '10', '12')  then
    if dan not between '01' and '31' then
    	return false;
    end if;
  else
  	if dan not between '01' and '30' then
    	return false;
    end if;
  end if;  
  else
    if substr(maticni_broj,10,4)='0000' then
      return true;
    end if;
end if;

Zbir :=		7*(to_number(substr(p_matbr, 1, 1))	+ to_number(SubStr(p_matbr, 7, 1))) + 
					6*(to_number(SubStr(p_matbr, 2, 1))	+ to_number(SubStr(p_matbr, 8, 1))) +  
					5*(to_number(SubStr(p_matbr, 3, 1)) + to_number(SubStr(p_matbr, 9, 1)))  + 
					4*(to_number(SubStr(p_matbr, 4, 1)) + to_number(SubStr(p_matbr, 10, 1)))  + 
					3*(to_number(SubStr(p_matbr, 5, 1)) + to_number(SubStr(p_matbr, 11, 1)))  + 
		 			2*(to_number(SubStr(p_matbr, 6, 1)) + to_number(SubStr(p_matbr, 12, 1)));
		 			
if (mod(zbir,11)) = 1 then
	return false; 
end if;
if (mod(zbir,11))=0 and to_number(SubStr(p_matbr, 13, 1))=0 then
	return true;
end if;
/*
if (mod(zbir,11))=0 and to_number(SubStr(p_matbr, 13, 1))<>0 then
	return false;
end if;
*/
if 11-(mod(zbir,11))=to_number(SubStr(p_matbr, 13, 1)) then
	return true;
else
	return false;
end if;
  --return vrati;
END PROVJERA_MATBR;


/

