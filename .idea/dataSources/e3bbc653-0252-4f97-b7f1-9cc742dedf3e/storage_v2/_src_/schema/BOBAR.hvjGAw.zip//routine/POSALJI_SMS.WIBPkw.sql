create PROCEDURE POSALJI_SMS (broj in varchar,poruka in varchar) AS
BEGIN
  insert into tep.sms_slanje (RECEIVER,MSG,VRSTA,DATUM_SLANJA,operater) 
			values (broj,
			poruka,
			0,
			sysdate,
			'Oracle');
			commit;
END POSALJI_SMS;


/

