create FUNCTION OTKUPLJENA_STETA (pid number) RETURN VARCHAR2 AS 
  datum varchar2(10);
BEGIN
  for red in ( select to_char(datumobrade,'dd.mm.rrrr')  dat from knjigastao where prijstet_id=pid and (trim(mesto_opis) like '%OTKUPLJENA ŠTETA%' or  
  trim(mesto_opis) like '%NAPLAĆEN REGRES%' or trim(napomena) like '%OTKUPLJENA ŠTETA%' or trim(napomena) like '%NAPLAĆEN REGRES%') ) loop
    datum:=red.dat;
  end loop;  
     return datum;
END OTKUPLJENA_STETA;

/

