create trigger RATE_SEQ_1
  before insert
  on RATE
  for each row
  BEGIN
    SELECT RATE_SEQ_1.NEXTVAL INTO :NEW.RAT_BRSTAVKE FROM DUAL;
END;



/

