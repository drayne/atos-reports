create function povezano_lice (komitent in number) return number as 
broj number:=0;
begin
  select povezano_lice into broj from komitent where kom_sifra=komitent;
  return broj;
END POVEZANO_LICE;

/

