create PROCEDURE         "SESIJA" (poperater varchar,pip varchar,phost varchar,psid varchar,pprocess varchar) AS 
sesija_id number:=0;
BEGIN
  select teh_ses_seq.nextval into sesija_id from dual;
  insert into tehnicki_sesije ( OPERATER_NAZIV,TEHNICKI_SIFRA,POCETAK_KONEKCIJE,KRAJ_KONEKCIJE,IP_ADRESA_KLIJENTA,IME_RACUNARA_KLIJENTA,
  SID,PROCES,ID) values
  (poperater,null,sysdate,null,pip,phost,psid,pprocess,sesija_id);
  commit;
END SESIJA;

/

