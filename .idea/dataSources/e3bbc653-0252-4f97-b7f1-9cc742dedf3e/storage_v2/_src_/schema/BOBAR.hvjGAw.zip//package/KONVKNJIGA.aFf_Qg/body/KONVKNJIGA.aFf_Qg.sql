create PACKAGE BODY          "KONVKNJIGA"          is
    Function c_date(u_str varchar2, u_fm varchar2) return date is
 i date;
 u varchar2(1022);
begin
 greska := null;
 u :=ltrim(rtrim(u_str));
 if (length(u) is null) then
  return null;
 end if;
 i := to_date(u_str,u_fm);
 return i;
 exception when others then
  greska := sqlerrm;
  logit('>'||u_str||'< ' || greska);
  return null;
end;

Function c_numb(u_str varchar2) return number is
 i number;
 u varchar2(1022);
begin
 greska := null;
 u := ltrim(rtrim(u_str));
 if ((length(u) is null) or (u = '.')) then
  return null;
 end if;
 i := to_number(u_str);
 return i;
exception when others then
  greska := sqlerrm;
  logit('>'||u_str||'< ' || greska);
  return null;
end;

PROCEDURE logit(st number, en number) is
begin
 utl_file.put_line(logfl,to_char(linija,'09999')||':'||substr(komad,st,en) || ':');
 utl_file.put_line(logfl,greska);
end;

procedure logit(ms varchar2) is
begin
 utl_file.put_line(logfl,to_char(linija,'09999')||':'|| ms);
end;
------------------------------------------------------------------------------------------------
PROCEDURE konvertuj (put_do_fajla varchar2) IS
 pol knjigastao%ROWTYPE;
 nastavi boolean := TRUE;
 br_upisanih number;

BEGIN
 EOF:=FALSE;
 dbms_output.enable(100000);

 begin
  ulaz := utl_file.fopen(put_do_fajla,'steslova.dat','r');
  logfl:= utl_file.fopen(put_do_fajla,'steslova.log','w');
  logit('otvoren.');
 exception when utl_file.invalid_path then
  logit('FOPEN:invalid_path');
 when utl_file.invalid_mode then
  logit('FOPEN:invalid_mode');
 when utl_file.invalid_operation then
  logit('FOPEN:invalid_operation');
 end;


  if (utl_file.is_open(ulaz)) then
   logit('citam...');
   br_upisanih := 0;
   loop
     begin
       utl_file.get_line(ulaz,komad);
/*        
       pol.drz_sif := ltrim(rtrim(substr(komad,1,6))); 
       pol.koddr := ltrim(rtrim(substr(komad,10,9))); 
       pol.naziv := ltrim(rtrim(substr(komad,19,100))); 
*/       
       pol.prijstet_id := ltrim(rtrim(substr(komad,1,5))); 
       pol.nazivosi := ltrim(rtrim(substr(komad,81,50)));
       pol.adresaosi := ltrim(rtrim(substr(komad,131,35)));
       pol.nazivvozosi := ltrim(rtrim(substr(komad,166,50)));
       pol.adresavozosi := ltrim(rtrim(substr(komad,216,25)));
       pol.nazivostec := ltrim(rtrim(substr(komad,251,50)));
       pol.adresaostec := ltrim(rtrim(substr(komad,301,35)));
       pol.nazivvozostec := ltrim(rtrim(substr(komad,336,50)));
       pol.adresavozostec := ltrim(rtrim(substr(komad,386,35)));
       pol.mesto_opis := ltrim(rtrim(substr(komad,421,75)));
      pol.napomena := ltrim(rtrim(substr(komad,504,70)));

    update knjigastao set knjigastao.nazivosi = yu852lat(pol.nazivosi), 
                      	  knjigastao.adresaosi = yu852lat(pol.adresaosi),
                      	  knjigastao.nazivvozosi = yu852lat(pol.nazivvozosi),
                      	  knjigastao.adresavozosi = yu852lat(pol.adresavozosi),
                      	  knjigastao.nazivostec = yu852lat(pol.nazivostec),
                      	  knjigastao.adresaostec = yu852lat(pol.adresaostec),
                      	  knjigastao.nazivvozostec = yu852lat(pol.nazivvozostec),
                      	  knjigastao.adresavozostec = yu852lat(pol.adresavozostec), 
                      	  knjigastao.mesto_opis = yu852lat(pol.mesto_opis),
                      	  knjigastao.napomena = yu852lat(pol.napomena)
                  where knjigastao.prijstet_id = pol.prijstet_id;
 
/*
       pol.markaosi := ltrim(rtrim(substr(komad,6,10)));
       pol.tiposi := ltrim(rtrim(substr(komad,16,10)));
       pol.regbrosi := ltrim(rtrim(substr(komad,26,10)));
       pol.regbrostec := ltrim(rtrim(substr(komad,36,10)));
       pol.markaostec := ltrim(rtrim(substr(komad,46,10)));
       pol.tipostec := ltrim(rtrim(substr(komad,56,10)));
       pol.godproizvod := c_date(ltrim(rtrim(substr(komad,66,4))),'rrrr');

    update knjigastao set knjigastao.markaosi = yu852lat(pol.markaosi), 
                      	  knjigastao.tiposi = yu852lat(pol.tiposi),
                      	  knjigastao.regbrosi = yu852lat(pol.regbrosi),
                      	  knjigastao.markaostec = yu852lat(pol.markaostec),
                      	  knjigastao.tipostec = yu852lat(pol.tipostec),
                      	  knjigastao.regbrostec = yu852lat(pol.regbrostec),
                      	  knjigastao.godproizvod  = pol.godproizvod
                  where knjigastao.prijstet_id = pol.prijstet_id;
*/

/*    update osigkuce set osigkuce.naziv = yu852lat(pol.naziv)
                  where osigkuce.drz_sif = pol.drz_sif and
                        osigkuce.koddr = pol.koddr;
*/                 
    br_upisanih := br_upisanih + 1;

    if br_upisanih = 63 then
      commit;
      br_upisanih := 0;
    end if;  

    logit(greska || ' ' ||komad);

    exception when no_data_found then EOF := TRUE;
    when others then
      greska := sqlerrm;
      logit(greska || ' ' ||komad);
    end;
    exit when EOF;
   end loop;
  else
   logit('FGETLINE:Nije otvoren file');
  end if;

--finalize
 utl_file.fclose(ulaz);
 logit('zatvoren.');
-- logit('Insertovano: ' || to_char(br_upisanih) || ' zapisa!');
 utl_file.fclose(logfl);
exception when others then
 utl_file.fclose_all;
 raise;
END;

END;
/

