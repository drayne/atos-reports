create PROCEDURE SREDNJI_KURS
 (DATUM_IN IN DATE
 ,DEV_DUGUJE_IN IN NUMBER
 ,DEV_POTRAZUJE_IN IN NUMBER
 ,DUGUJE_OUT IN OUT NUMBER
 ,POTRAZUJE_OUT IN OUT NUMBER
 ,VALUTA_IN IN NUMBER
 )
 IS
BEGIN
DECLARE
  kursn NUMBER(38,6);
  jedinica NUMBER(5,0);
BEGIN
  BEGIN
     SELECT kurs2, za
       INTO kursn, jedinica
       FROM kurs
      WHERE valuta = valuta_in
        AND datum  = (SELECT MAX(datum)
                        FROM kurs
                       WHERE valuta = valuta_in
                         AND datum <= datum_in);
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
          raise_application_error( -20100,
          'Nema kursa za navedenu valutu i datum!');
     WHEN OTHERS THEN
          raise_application_error( -20101,SQLERRM);

  END;
  BEGIN
     SELECT ROUND(((NVL(dev_duguje_in,0)*kursn)/jedinica),2)
       INTO duguje_out
       FROM dual;
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
          raise_application_error( -20100,
          'Nije izra?unato duguje po srednjem kursu!');
     WHEN OTHERS THEN
          raise_application_error( -20101,SQLERRM);
  END;
 BEGIN
     SELECT ROUND(((NVL(dev_potrazuje_in,0)*kursn)/jedinica),2)
       INTO potrazuje_out
       FROM dual;
  EXCEPTION
     WHEN NO_DATA_FOUND THEN
          raise_application_error( -20100,
          'Nije izra?unato potra?uje po srednjem kursu!');
     WHEN OTHERS THEN
          raise_application_error( -20101,SQLERRM);
  END;
 END;
END SREDNJI_KURS;


/

