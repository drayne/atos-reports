create PACKAGE BODY prenos_rate IS
 procedure logit(ms varchar2) is
  begin
   utl_file.put_line(logfl,to_char(linija,'09999')||':'|| ms);
 end;

 PROCEDURE   PRENOS  (put_do_fajla varchar2) IS
 
 cursor pol_rate is select polisa.pol_brpol,
                           polao3.uk_prem_ao,
                           polao3.uk_prem_and
                      from polisa, polao3
                     where to_char ( polisa.datpoc, 'rrrrmmdd' ) >= '20030701' and
                           polisa.pol_brpol = polao3.ao3_brpol;
 nije_upisano number := 0;
 upisano number := 0;
 prva_rata boolean := true;

BEGIN

 EOF:=FALSE;
 dbms_output.enable(100000);
 logfl:= utl_file.fopen(put_do_fajla,'prenos_rate.log','w');
 logit( 'Uspešno otvoren log file ' );

 for cur_rec in pol_rate loop

  prva_rata := true;

	if cur_rec.uk_prem_ao is not null and cur_rec.uk_prem_ao <> 0 then
          begin
      	    insert into rate ( rat_brpol, rat_brstavke, vros,
                               datum, iznos, statusrate,
			       brfakture, datumfakture,
                               datumobrade, sifoperat )
	              values ( cur_rec.pol_brpol, 1, 800,
                               to_date ( '02072003', 'ddmmrrrr' ), cur_rec.uk_prem_ao, 0,
			       null, null,
                               to_date ( '03072003', 'ddmmrrrr' ), 'branot' );

             upisano := upisano + 1;
          exception when others then
           nije_upisano := nije_upisano + 1;
           logit ( cur_rec.pol_brpol );
           prva_rata := false;
        end;
  end if;

	if cur_rec.uk_prem_and is not null and cur_rec.uk_prem_and <> 0 then
          begin
      	    insert into rate ( rat_brpol, rat_brstavke, vros,
                               datum, iznos, statusrate,
			       brfakture, datumfakture,
                               datumobrade, sifoperat )
	              values ( cur_rec.pol_brpol, 2, 850,
                               to_date ( '02072003', 'ddmmrrrr' ), cur_rec.uk_prem_and, 0,
			       null, null,
                               to_date ( '03072003', 'ddmmrrrr' ), 'branot' );

            if not prva_rata then
            	upisano := upisano + 1;
            end if;
        exception when others then
          if prva_rata then
           nije_upisano := nije_upisano + 1;
           logit ( cur_rec.pol_brpol );
          end if;
        end;
  end if;

 end loop;

 logit( 'Uspešno obrađeno: ' || to_char( upisano ) || ' polisa!' );
 logit( 'Neuspešno obrađeno: ' || to_char ( nije_upisano ) || ' polisa!' );
 logit( 'Ukupno obrađeno: ' || to_char ( upisano + nije_upisano ) || ' polisa!' );

 utl_file.fclose(logfl);
exception when others then
 utl_file.fclose_all;
 raise;
END;

END;
/

