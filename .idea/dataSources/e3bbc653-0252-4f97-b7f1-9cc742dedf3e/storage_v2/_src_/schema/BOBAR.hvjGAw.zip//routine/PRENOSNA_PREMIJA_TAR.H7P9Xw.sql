create PROCEDURE PRENOSNA_PREMIJA_TAR ( p_tar number, 
                                                   p_targrupa number, 
                                                   p_godina_prosla number, 
                                                   p_datum_od date, 
                                                   p_datum_do date,
                                                   p_proba number default -1,
                                                   p_pren_sada out number,
                                                   p_prip_pre out number,
                                                   p_pren_pre out number ) is
begin
 select        sum(pren_sada),
               sum(prip_pre),
               sum(pren_pre)
  into         p_pren_sada,
               p_prip_pre,
               p_pren_pre
  from
  ( select     decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               sum(RATE.iznos * 
                       (polisa.datist - p_datum_do) / 
                       (polisa.datist - polisa.datpoc)) pren_sada,
               0 prip_pre,
               0 pren_pre
   from 
               polisa, RATE, polao3, polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
               POLISA.POL_BRPOL = RATE.RAT_BRPOL and
               polisa.vsdok = rate.vsdok and
               NVL(RATE.STATUSRATE, 0) > 0 and
               nvl(RATE.IZNOS, 0) != 0 and
               datprip between p_datum_od and p_datum_do and 
               polisa.datpoc < p_datum_do and 
               polisa.datist > p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               sum(RATE.iznos) PREN_SADA, 
               0 prip_pre,
               0 pren_pre
   from 
               polisa, RATE, polao3, polao2 
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
               POLISA.POL_BRPOL = RATE.RAT_BRPOL AND
               polisa.vsdok = rate.vsdok and
               NVL(RATE.STATUSRATE, 0) > 0 AND
               nvl(RATE.IZNOS, 0) != 0 and
               datprip between p_datum_od and p_datum_do and
               polisa.datpoc >= p_datum_do and
               polisa.datist > p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               0 PREN_SADA, 
               sum(RATE.iznos * 
                       (polisa.datist - p_datum_od) / 
                       (polisa.datist - polisa.datpoc)) prip_PRE,
               0 pren_pre
   from 
               polisa, RATE, polao3, polao2 
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
               POLISA.POL_BRPOL = RATE.RAT_BRPOL AND
               polisa.vsdok = rate.vsdok and
               NVL(RATE.STATUSRATE, 0) > 0 AND
               nvl(RATE.IZNOS, 0) != 0 and
               datprip < p_datum_od and
               POLISA.DATIST > P_DATUM_OD and
               polisa.datpoc < p_datum_od and
               polisa.datist <= p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               0 PREN_SADA, 
               sum(RATE.iznos * 
                       (p_datum_do - p_datum_od) / 
                       (polisa.datist - polisa.datpoc)) prip_PRE,
               0 pren_pre
   from 
               polisa, RATE, polao3, polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
               POLISA.POL_BRPOL = RATE.RAT_BRPOL AND
               polisa.vsdok = rate.vsdok and
               NVL(RATE.STATUSRATE, 0) > 0 AND
               nvl(RATE.IZNOS, 0) != 0 and
               datprip < p_datum_od and
               POLISA.DATIST > P_DATUM_OD and
               polisa.datpoc < p_datum_od and
               polisa.datist > p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               0 PREN_SADA, 
               sum(RATE.iznos) prip_PRE,
               0 pren_pre
   from 
               polisa, RATE, polao3, polao2 
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
               POLISA.POL_BRPOL = RATE.RAT_BRPOL AND
               polisa.vsdok = rate.vsdok and
               NVL(RATE.STATUSRATE, 0) > 0 AND
               nvl(RATE.IZNOS, 0) != 0 and
               datprip < p_datum_od and
               POLISA.DATIST > P_DATUM_OD and
               polisa.datpoc >= p_datum_od and
               polisa.datpoc < p_datum_do and
               polisa.datist <= p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               0 PREN_SADA, 
               sum(RATE.iznos * 
                       (p_datum_do - polisa.datpoc) / 
                       (polisa.datist - polisa.datpoc)) prip_PRE,
               0 pren_pre
   from 
               polisa, RATE, polao3, polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
               POLISA.POL_BRPOL = RATE.RAT_BRPOL AND
               polisa.vsdok = rate.vsdok and
               NVL(RATE.STATUSRATE, 0) > 0 AND
               nvl(RATE.IZNOS, 0) != 0 and
               datprip < p_datum_od and
               POLISA.DATIST > P_DATUM_OD and
               polisa.datpoc >= p_datum_od and
               polisa.datpoc < p_datum_do and
               polisa.datist > p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               0 PREN_SADA, 
               0 prip_pre,
               sum(RATE.iznos * 
                       (polisa.datist - p_datum_do) / 
                       (polisa.datist - polisa.datpoc)) PREN_PRE
   from 
               polisa, RATE, polao3, polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
               POLISA.POL_BRPOL = RATE.RAT_BRPOL AND
               polisa.vsdok = rate.vsdok and
               NVL(RATE.STATUSRATE, 0) > 0 AND
               nvl(RATE.IZNOS, 0) != 0 and
               datprip < p_datum_od and
               POLISA.DATIST > P_DATUM_OD and
               polisa.datpoc <= p_datum_do and
               polisa.datist > p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               0 PREN_SADA, 
               0 prip_pre,
               sum(RATE.iznos) PREN_PRE
   from 
               polisa, RATE, polao3, polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
               POLISA.POL_BRPOL = RATE.RAT_BRPOL AND
               polisa.vsdok = rate.vsdok and
               NVL(RATE.STATUSRATE, 0) > 0 AND
               nvl(RATE.IZNOS, 0) != 0 and
               datprip < p_datum_od and
               POLISA.DATIST >= P_DATUM_OD and
               polisa.datpoc > p_datum_do and
               polisa.datist > p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
 union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               sum(kpsnalog.iznospremije * 
                       (polisa.datist - p_datum_do) / 
                       (polisa.datist - polisa.datpoc)) pren_sada,
               0 prip_pre,
               0 pren_pre
   from 
               polisa, 
               kpsnalog,
--               OSK,
               polao3,
               polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
                  kpsnalog.kpsnal_vsdok = polisa.vsdok
           and kpsnalog.kpsnal_brojdok = polisa.pol_brpol
           and polisa.datprip between p_datum_od and p_datum_do
           and NVL(kpsnalog.iznospremije, 0) != 0 
           AND polisa.datpoc < p_datum_do
           and polisa.datist > p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               sum(kpsnalog.iznospremije) PREN_SADA, 
               0 prip_pre,
               0 pren_pre
   from 
               polisa, 
               kpsnalog,
--               OSK,
               polao3,
               polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
                  kpsnalog.kpsnal_vsdok = polisa.vsdok
           and kpsnalog.kpsnal_brojdok = polisa.pol_brpol
           and polisa.datprip between p_datum_od and p_datum_do
           and NVL(kpsnalog.iznospremije, 0) != 0 
           and polisa.datpoc > p_datum_do
           and polisa.datist > p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               0 pren_sada,
                              sum(kpsnalog.iznospremije * 
                       (polisa.datist - p_datum_od) / 
                       (polisa.datist - polisa.datpoc)) prip_PRE, 
               0 pren_pre
   from 
               polisa, 
               kpsnalog,
--               OSK,
               polao3,
               polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
                  kpsnalog.kpsnal_vsdok = polisa.vsdok
           and kpsnalog.kpsnal_brojdok = polisa.pol_brpol
           and to_char(datprip,'rrrr') = p_godina_prosla
--           and to_char(STORNODOK.datdok,'rrrr') = :p_dat_prosla
           AND POLISA.DATIST > P_DATUM_OD
           and NVL(kpsnalog.iznospremije, 0) != 0 
           and polisa.datpoc > p_datum_od
           and polisa.datist > p_datum_od
           and polisa.datist <= p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               0 pren_sada,
                              sum(kpsnalog.iznospremije * 
                       (p_datum_do - p_datum_od) / 
                       (polisa.datist - polisa.datpoc)) prip_PRE, 
               0 pren_pre
   from 
               polisa, 
               kpsnalog,
           --    OSK,
               polao3,
               polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
                  kpsnalog.kpsnal_vsdok = polisa.vsdok
           and kpsnalog.kpsnal_brojdok = polisa.pol_brpol
           and to_char(datprip,'rrrr') = p_godina_prosla
--           and to_char(STORNODOK.datdok,'rrrr') = :p_dat_prosla
           AND POLISA.DATIST > P_DATUM_OD
           and NVL(kpsnalog.iznospremije, 0) != 0 
           and polisa.datpoc < p_datum_od
           and polisa.datist > p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               0 pren_sada,
                              sum(kpsnalog.iznospremije) prip_PRE, 
               0 pren_pre
   from 
               polisa, 
               kpsnalog,
           --    OSK,
               polao3,
               polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
                  kpsnalog.kpsnal_vsdok = polisa.vsdok
           and kpsnalog.kpsnal_brojdok = polisa.pol_brpol
           and to_char(datprip,'rrrr') = p_godina_prosla
--           and to_char(STORNODOK.datdok,'rrrr') = :p_dat_prosla
           AND POLISA.DATIST > P_DATUM_OD
           and NVL(kpsnalog.iznospremije, 0) != 0 
           and polisa.datpoc >= p_datum_od
           and polisa.datpoc < p_datum_do
           and polisa.datist <= p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               0 pren_sada,
                              sum(kpsnalog.iznospremije * 
                       (p_datum_do - polisa.datpoc) / 
                       (polisa.datist - polisa.datpoc)) prip_PRE, 
               0 pren_pre
   from 
               polisa, 
               kpsnalog,
          --     OSK,
               polao3,
               polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
                  kpsnalog.kpsnal_vsdok = polisa.vsdok
           and kpsnalog.kpsnal_brojdok = polisa.pol_brpol
           and to_char(datprip,'rrrr') = p_godina_prosla
--           and to_char(STORNODOK.datdok,'rrrr') = :p_dat_prosla
           AND POLISA.DATIST > P_DATUM_OD
           and NVL(kpsnalog.iznospremije, 0) != 0 
           and polisa.datpoc >= p_datum_od
           and polisa.datpoc < p_datum_do
           and polisa.datist > p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               0 pren_sada,
               0 prip_pre,
                              sum(kpsnalog.iznospremije * 
                       (polisa.datist - p_datum_do) / 
                       (polisa.datist - polisa.datpoc)) pren_PRE 
   from
               polisa, 
               kpsnalog,
         --      OSK,
               polao3,
               polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
                  kpsnalog.kpsnal_vsdok = polisa.vsdok
           and kpsnalog.kpsnal_brojdok = polisa.pol_brpol
           and to_char(datprip,'rrrr') = p_godina_prosla
--           and to_char(STORNODOK.datdok,'rrrr') = :p_dat_prosla
           AND POLISA.DATIST >P_DATUM_OD
           and NVL(kpsnalog.iznospremije, 0) != 0 
           and polisa.datpoc <= p_datum_do
           and polisa.datist > p_datum_do
   group by
               polisa.tar,
               polao3.targrupa
union all
   select      decode ( p_proba, -1, polao3.targrupa, p_proba ) targrupa,
               polisa.tar tarifa, 
               0 pren_sada,
               0 prip_pre,
                              sum(kpsnalog.iznospremije) pren_PRE 
   from 
               polisa, 
               kpsnalog,
           --    OSK,
               polao3,
               polao2
   where       polisa.pol_brpol = polao3.ao3_brpol and
               polisa.vsdok = polao3.vsdok and
               polisa.tar = p_tar and
               polisa.pol_brpol = polao2.ao2_brpol and
               polisa.vsdok = polao2.vsdok and
               ( ( p_proba = -1 and polao3.targrupa = p_targrupa ) or
                 ( p_proba <> -1 and polao2.regbroj = 'PROBA' ) ) and
                  kpsnalog.kpsnal_vsdok = polisa.vsdok
           and kpsnalog.kpsnal_brojdok = polisa.pol_brpol
           and to_char(datprip,'rrrr') = p_godina_prosla
--           and to_char(STORNODOK.datdok,'rrrr') = :p_dat_prosla
           AND POLISA.DATIST > P_DATUM_OD 
           and NVL(kpsnalog.iznospremije, 0) != 0 
           and polisa.datpoc > p_datum_do
           and polisa.datist > p_datum_do
   group by
               polisa.tar,
               polao3.targrupa)
     group by
               tarifa,
               targrupa;
exception when others then
  null;
end;

/

