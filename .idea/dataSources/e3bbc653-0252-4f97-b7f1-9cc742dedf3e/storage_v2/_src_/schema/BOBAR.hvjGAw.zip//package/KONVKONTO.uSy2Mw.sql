create PACKAGE        konvkonto IS
  ulaz utl_file.FILE_TYPE;
  logfl utl_file.FILE_TYPE;
  komad varchar2(1022);
  EOF boolean;
  greska varchar2(1024);
  linija number;

  PROCEDURE logit(st number, en number);
  PROCEDURE logit(ms varchar2);
  Function c_numb(u_str varchar2) return number;
  Function c_date(u_str varchar2, u_fm varchar2) return date;
  procedure konvertuj (put_do_fajla varchar2);
  
END;

/

