create trigger PRIVREMENI_SUMA_INVALID_POLAO3
  before insert or update
  on POLAO3
  for each row
  begin
  -- Zbog problema sa formom fpolao
  if (:new.sumainvalid is null)
  then
    :new.sumainvalid :=  :new.sumasmrti*2;
  end if;
end;


/

