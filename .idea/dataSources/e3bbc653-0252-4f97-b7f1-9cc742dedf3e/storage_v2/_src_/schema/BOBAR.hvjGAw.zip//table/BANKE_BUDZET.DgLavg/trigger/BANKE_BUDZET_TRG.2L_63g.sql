create trigger BANKE_BUDZET_TRG
  before insert
  on BANKE_BUDZET
  for each row
  DECLARE
  N NUMBER;
BEGIN
-- For Toad:  Highlight column ID
  Select BANKE_BUDZET_SEQ.nextval into n from dual;
  :new.ID := N;
END BANKE_BUDZET_TRG;


/

