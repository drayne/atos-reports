create PROCEDURE JOB_NEPOSLATE_PORUKE AS 
   broj number:=0;
begin --dodata provjera da se ne tretiraju poruke sa statusom 'kvar' (03.04.2014)
   select count(*) into broj from tep.sms_slanje where trim(status)<>'transmitted' and trim(status)<>'kvar' and vrsta=2;
       if broj>0 then
           bobar.posalji_sms('066903255','Broj neuspjesno poslatih poruka je '||to_char(broj));
       end if;
end JOB_NEPOSLATE_PORUKE;

/

