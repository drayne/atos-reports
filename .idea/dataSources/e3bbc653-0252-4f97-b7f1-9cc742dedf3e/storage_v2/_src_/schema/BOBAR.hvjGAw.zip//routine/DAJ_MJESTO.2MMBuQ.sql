create FUNCTION DAJ_MJESTO (p_ptt number) RETURN VARCHAR2 AS 
r_mjesto varchar(200):='';
BEGIN
  select mesto into r_mjesto from mesto where mes_sifra = p_ptt ;
  return r_mjesto;
END DAJ_MJESTO;

/

