create FUNCTION NAZIV_KONTA (p_konto in varchar, p_preduzece in number) RETURN VARCHAR2 AS 
pom varchar(2000):='';
BEGIN
  if p_preduzece = 1 then
	  		/* 
	  			Uzmi konsolidovani konto, 
	  			a ako on nije napunjen uzmi prvi obican konto 
	  		*/
				begin
			  	select naziv
			  	  into pom
--->			  	  from konsolidovani_konto
--    		  	 where sifra = p_vrednost;
			  	  from konto
			  	 where kon_sifra = p_konto;
-- <--			  	 
				exception
					when no_data_found then
				  	select naziv
				  	  into pom
				  	  from konto
				  	 where kon_sifra = p_konto
				  	   and rownum = 1;
				end;
	  	else
	  		/* Uzmi redovan konto */
		  	select naziv
		  	  into pom
		  	  from konto
		  	 where kon_sifra = p_konto
		  	   and ( (p_preduzece = 2 and kon_oj = 2) or
		  	         (p_preduzece != 2 and kon_oj = 1) );
	  	end if;
  return pom;
END NAZIV_KONTA;

/

