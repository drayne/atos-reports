create view KOM_ST_TEMP_VIEW_0126132729 as
  select komitent, anl_nalog, anl_vsdok, datnal, datdok, datval, brdok, pol_brpol, opis, zatvoren, dev_duguje duguje, dev_potrazuje potrazuje from anlanl where komitent between 382 and 382 and anl_vlasnik between 1 and 1 and anl_radnja between 2 and 2 and trunc(datnal) between to_date('01.01.11') and to_date('31.12.11') and konto between '46420' and '49999'

/

