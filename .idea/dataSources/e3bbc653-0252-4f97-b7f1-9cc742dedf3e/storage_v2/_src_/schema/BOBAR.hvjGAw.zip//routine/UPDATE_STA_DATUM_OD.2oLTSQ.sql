create PROCEDURE update_sta_datum_od IS

  cursor c_st is
       select * from statstet where sta_datum_od is null
       order by prijstet_id,sta_rednibroj;
  red_st statstet%rowtype;

BEGIN

  open c_st;
  loop
   fetch c_st into red_st;
   exit when c_st%notfound;
    if red_st.sta_rednibroj = 1 then
       UPDATE statstet set sta_datum_od = (select datumprijave
                                           from prijstet
                                           where id = red_st.prijstet_id)
      where prijstet_id = red_st.prijstet_id;
    else

   UPDATE statstet set sta_datum_od = (select sta_datum from statstet s
      where s.prijstet_id = red_st.prijstet_id
            and s.sta_rednibroj = red_st.sta_rednibroj- 1)
      where prijstet_id = red_st.prijstet_id
            and sta_rednibroj = red_st.sta_rednibroj;
   end if;

  END LOOP;
  close c_st;
  commit;

END;

/

