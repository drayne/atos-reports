create PROCEDURE premesti IS
wvrsta varchar2(25);
brojac number;
  cursor c_polisa is
       select targrupa, tarpodgrupa, tip, ao2_brpol
       from polao3, polao2
       where ao2_brpol = ao3_brpol;
BEGIN
	brojac := 0;
	for i in c_polisa loop
		if i.targrupa = 8 THEN
			if i.tarpodgrupa = 1 THEN
				wvrsta := 'PUTNIČKA VOZILA';
			ELSIF
			i.tarpodgrupa = 2 THEN
				wvrsta := 'TERETNA VOZILA';
			ELSIF
			i.tarpodgrupa = 3 THEN
				wvrsta := 'AUTOBUSI';
			ELSIF
			i.tarpodgrupa = 4 THEN
				wvrsta := 'VUČNA VOZILA';
			ELSIF
			i.tarpodgrupa = 5 THEN
				wvrsta := 'SPECIJALNA VOZILA';
			ELSIF
			i.tarpodgrupa = 6 THEN
				wvrsta := 'MOTOCIKLI';
			ELSIF
			 i.tarpodgrupa = 7 THEN
				wvrsta := 'PRIKLJUČNA VOZILA';
			ELSIF
			 i.tarpodgrupa = 10 THEN
				wvrsta := 'RADNA VOZILA';
			ELSIF
			 i.tarpodgrupa = 11 THEN
				wvrsta := 'ŠINSKA VOZILA';
			ELSE
				wvrsta := 'OSTALO';
			END IF;
			ELSIF
				i.targrupa = 1 THEN
				wvrsta := 'PUTNIČKA VOZILA';
			ELSIF
			i.targrupa = 2 THEN
				wvrsta := 'TERETNA VOZILA';
			ELSIF
			i.targrupa = 3 THEN
				wvrsta := 'AUTOBUSI';
			ELSIF
			i.targrupa = 4 THEN
				wvrsta := 'VUČNA VOZILA';
			ELSIF
			i.tarpodgrupa = 5 THEN
				wvrsta := 'SPECIJALNA VOZILA';
			ELSIF
			i.targrupa = 6 THEN
				wvrsta := 'MOTOCIKLI';
			ELSIF
			 i.tarpodgrupa = 7 THEN
				wvrsta := 'PRIKLJUČNA VOZILA';
			ELSIF
			 i.targrupa = 10 THEN
				wvrsta := 'RADNA VOZILA';
			ELSIF
			 i.targrupa = 11 THEN
				wvrsta := 'ŠINSKA VOZILA';
			ELSE
				wvrsta := 'OSTALO';
			END IF;
			UPDATE POLAO2 set 
			                  model = i.tip,
			                  tip = wvrsta
			            where polao2.ao2_brpol = i.ao2_brpol;
			 brojac := brojac + 1;
			 if brojac > 5000 then 
			 	  commit;
			 	  brojac := 0;
			 end if;
		END LOOP;
END;


/

