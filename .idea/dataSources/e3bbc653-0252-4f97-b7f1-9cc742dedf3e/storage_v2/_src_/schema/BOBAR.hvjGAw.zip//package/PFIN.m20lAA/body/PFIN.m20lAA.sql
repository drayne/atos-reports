create PACKAGE BODY PFIN IS
do_l		date	:=	NULL;
	od_l		date	:=	NULL;
	do_per_c	pls_integer;
	za_per_c	pls_integer;
	br_do_per	pls_integer;
	br_za_per	pls_integer;
	slog_do_per	pfin.stavka_tp;
	slog_za_per	pfin.stavka_tp;
-- PL/SQL Block
END PFIN;
/

