create trigger BDR_TOSNSREDSTVO
  before delete
  on TOSNSREDSTVO
  for each row
  BEGIN
delete TOsnKartica
 where vlasnik         = :old.vlasnik
   and lokacija        = :old.lokacija
   and inventarskibroj = :old.inventarskibroj;

delete TOsnObracunAmor
 where vlasnik         = :old.vlasnik
   and lokacija        = :old.lokacija
   and inventarskibroj = :old.inventarskibroj;

delete TOsnObracunReval
 where vlasnik         = :old.vlasnik
   and lokacija        = :old.lokacija
   and inventarskibroj = :old.inventarskibroj;

delete TOsnRevAmortizacije
 where vlasnik         = :old.vlasnik
   and lokacija        = :old.lokacija
   and inventarskibroj = :old.inventarskibroj;

delete TOsnOstvareniUcinak
 where sred_vlasnik         = :old.vlasnik
   and sred_lokacija        = :old.lokacija
   and sred_inventarskibroj = :old.inventarskibroj;
END;



/

